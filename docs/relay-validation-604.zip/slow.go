package main

import (
	"encoding/json"
	"io"
	"log"
	"os"
	"time"
)

func slow() {
	var sessions []session
	for i := 0; i < *pool; i++ {
		s, e := dial(*proto)
		if e != nil {
			log.Fatal(e)
		}
		sessions = append(sessions, s)
	}
	idx := len(sessions) - 1
	c, e := sessions[idx].Open()
	if e != nil {
		log.Fatal(e)
	}
	c.SetDeadline(time.Now().Add(10 * time.Second))
	if e = header(c, 2, 1024*1024*1024); e != nil {
		log.Fatal(e)
	}
	var b [1024]byte
	if _, e = io.ReadFull(c, b[:]); e != nil {
		log.Fatal(e)
	}
	c.SetDeadline(time.Time{})
	activeBulk.Store(1)
	start := time.Now()
	samples := echo(sessions[0], "stopped-reader", time.Duration(*seconds)*time.Second)
	activeBulk.Store(0)
	closeStart := time.Now()
	done := make(chan struct{})
	go func() {
		c.Close()
		for _, s := range sessions {
			s.Close()
		}
		close(done)
	}()
	closed := false
	select {
	case <-done:
		closed = true
	case <-time.After(8 * time.Second):
	}
	json.NewEncoder(os.Stdout).Encode(map[string]any{"proto": *proto, "pool": *pool, "start": start.UTC().Format(time.RFC3339Nano), "stopped_read_s": time.Since(start).Seconds(), "close_ms": float64(time.Since(closeStart).Microseconds()) / 1000, "closed_within_8s": closed, "samples": samples})
}
