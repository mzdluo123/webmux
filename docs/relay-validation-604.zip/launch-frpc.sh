#!/bin/bash
set -eu
cd /tmp/webmux-relay-604
if test -s frpc.pid; then kill "$(cat frpc.pid)" 2>/dev/null || true; sleep 2; fi
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY PI_PROXY http_proxy https_proxy all_proxy
export NO_PROXY='*' no_proxy='*'
: > frpc.log
nohup ./frpc -c "frpc-$1.toml" > frpc.log 2>&1 < /dev/null &
echo $! > frpc.pid
for i in $(seq 1 120); do
  if grep -q 'start proxy success' frpc.log; then echo 'frpc ready'; exit 0; fi
  if ! kill -0 "$(cat frpc.pid)" 2>/dev/null; then cat frpc.log; exit 1; fi
  sleep 0.2
done
cat frpc.log
exit 1
