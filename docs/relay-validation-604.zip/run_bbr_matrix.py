from suite_helpers import *
profile('clean')
matrix('bbr-current','wss-smux,quic,kcp,kcp-fec',pools='1,2',size=16*1024*1024,seconds=12,tuned=True,wsl=True)
for damage in ['loss1','loss3','burst','asym','rtt500','mtu1280']:
    print('BBR PROFILE',damage,flush=True);profile(damage);probe('bbr-'+damage)
    protos='wss-smux,quic,kcp,kcp-fec' if damage in ['loss1','loss3','burst'] else 'wss-smux,quic'
    matrix('bbr-'+damage,protos,size=8*1024*1024,seconds=12,tuned=True,wsl=True)
    out=remote('tc -s qdisc show dev r604-host\nip netns exec relay604 tc -s qdisc show dev r604-peer',f'bbr-stats-{damage}')
    (ROOT/'results'/f'netem-bbr-{damage}-after.txt').write_text(out)
profile('clean')
print('BBR matrix complete',flush=True)
