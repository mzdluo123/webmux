import pathlib,secrets,json
r=pathlib.Path(__file__).resolve().parent
f=r/'secrets.json'
secret=json.loads(f.read_text()) if f.exists() else {k:secrets.token_hex(32) for k in ['webmux','frp','hysteria']}
f.write_text(json.dumps(secret),encoding='utf-8')
for label,base in [('remote','/root/relay-validation'),('local','/tmp/webmux-relay-604')]:
    (r/f'webmux-{label}.toml').write_text(f'''listen = "127.0.0.1:17681"
token = "{secret['webmux']}"
state_dir = "{base}/state"
default_cwd = "/tmp"
allowed_origins = ["https://172.233.136.221:18451", "https://172.233.136.221:18452", "https://172.233.136.221:18455", "https://172.233.136.221:18456", "http://127.0.0.1:17681"]
''')
(r/'frps.toml').write_text(f'''bindPort = 19000
kcpBindPort = 19001
quicBindPort = 19002
proxyBindAddr = "127.0.0.1"
allowPorts = [{{start = 19010, end = 19010}}]
auth.method = "token"
auth.token = "{secret['frp']}"
transport.tls.force = true
transport.tls.certFile = "cert.pem"
transport.tls.keyFile = "key.pem"
transport.tls.trustedCaFile = "cert.pem"
''')
(r/'hysteria-server.yaml').write_text(f'''listen: :19003
tls:
  cert: cert.pem
  key: key.pem
auth:
  type: password
  password: {secret['hysteria']}
congestion:
  type: bbr
  bbrProfile: standard
quic:
  initStreamReceiveWindow: 1048576
  maxStreamReceiveWindow: 1048576
  initConnReceiveWindow: 4194304
  maxConnReceiveWindow: 4194304
  maxIdleTimeout: 60s
  keepAlivePeriod: 10s
acl:
  inline:
    - direct(127.0.0.1, tcp/18454)
    - reject(all)
''')
for variant,bw in [('bbr',None),('5mbps',5),('20mbps',20),('50mbps',50)]:
    (r/f'hysteria-{variant}.yaml').write_text(f'''server: 172.233.136.221:19003
auth: {secret['hysteria']}
tls:
  sni: relay-bench
  ca: cert.pem
congestion:
  type: bbr
  bbrProfile: standard
quic:
  initStreamReceiveWindow: 1048576
  maxStreamReceiveWindow: 1048576
  initConnReceiveWindow: 4194304
  maxConnReceiveWindow: 4194304
  maxIdleTimeout: 60s
  keepAlivePeriod: 10s
  disableChromeParrot: true
tcpForwarding:
  - listen: 127.0.0.1:19443
    remote: 127.0.0.1:18454
'''+(f'bandwidth:\n  up: {bw} mbps\n  down: {bw} mbps\n' if bw else ''))
for proto,port in [('tcp',19000),('websocket',19000),('wss',19000),('quic',19002),('kcp',19001)]:
    (r/f'frpc-{proto}.toml').write_text(f'''serverAddr = "172.233.136.221"
serverPort = {port}
user = "relay604"
auth.method = "token"
auth.token = "{secret['frp']}"
transport.protocol = "{proto}"
transport.tcpMux = true
transport.poolCount = 0
transport.tls.enable = true
transport.tls.serverName = "relay-bench"
transport.tls.certFile = "cert.pem"
transport.tls.keyFile = "key.pem"
transport.tls.trustedCaFile = "cert.pem"
[[proxies]]
name = "webmux-fixture"
type = "tcp"
localIP = "127.0.0.1"
localPort = 17681
remotePort = 19010
''')
