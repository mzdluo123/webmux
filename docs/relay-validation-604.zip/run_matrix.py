"""Sequential direct-path benchmark. Setup/downloads must finish before running."""
import os, subprocess, json, time, pathlib, datetime, argparse, random,psutil

p=argparse.ArgumentParser()
p.add_argument('--rounds',type=int,default=3)
p.add_argument('--seconds',type=int,default=12)
p.add_argument('--bytes',type=int,default=16*1024*1024)
p.add_argument('--label',default='screen')
p.add_argument('--protocols',default='tls-yamux,tls-smux,wss-yamux,wss-smux,quic,kcp,kcp-fec')
p.add_argument('--pools',default='1,2')
p.add_argument('--binary',default='relay-current.exe')
p.add_argument('--addr',default='172.233.136.221')
p.add_argument('--port',type=int,default=0)
p.add_argument('--kcp-no-cc',type=int,default=0)
p.add_argument('--kcp-window',type=int,default=256)
p.add_argument('--observe-pid',type=int,default=0)
p.add_argument('--wsl',action='store_true')
a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent
env={k:v for k,v in os.environ.items() if 'proxy' not in k.lower()}
env.update(NO_PROXY='*',no_proxy='*')
out=root/'results';out.mkdir(exist_ok=True)
plans=[(p,int(n)) for p in a.protocols.split(',') for n in a.pools.split(',')]
for r in range(1,a.rounds+1):
    order=plans[r-1:]+plans[:r-1]
    if r%2==0:order.reverse()
    for proto,pool in order:
        while (root/'pause.flag').exists():
            time.sleep(1)
        name=f'{a.label}-r{r}-{proto}-p{pool}'
        target=out/(name+'.json')
        if target.exists() and target.stat().st_size:
            continue
        start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        print(start,name,flush=True)
        cmd=[str(root/a.binary),'-addr',a.addr,'-port',str(a.port),'-proto',proto,'-pool',str(pool),'-seconds',str(a.seconds),'-bytes',str(a.bytes),'-kcp-no-cc',str(a.kcp_no_cc),'-kcp-window',str(a.kcp_window)]
        if a.wsl:
            cmd=['wsl.exe','-d','Debian','-u','root','--cd','/tmp/webmux-relay-604','--','env','-u','HTTP_PROXY','-u','HTTPS_PROXY','-u','ALL_PROXY','-u','PI_PROXY','-u','http_proxy','-u','https_proxy','-u','all_proxy','NO_PROXY=*','./bench-client']+cmd[1:]
        t=time.monotonic()
        peak_rss=0;cpu_seconds=0
        side_rss=0;side_cpu=0;side_start=0
        side=psutil.Process(a.observe_pid) if a.observe_pid else None
        if side:
            ct=side.cpu_times();side_start=ct.user+ct.system
        with target.open('w',encoding='utf-8') as f, (out/(name+'.log')).open('w',encoding='utf-8') as err:
            try:
                proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=err)
                observed=psutil.Process(proc.pid)
                while proc.poll() is None:
                    try:
                        peak_rss=max(peak_rss,observed.memory_info().rss)
                        ct=observed.cpu_times();cpu_seconds=ct.user+ct.system
                    except psutil.Error:pass
                    if side:
                        try:
                            side_rss=max(side_rss,side.memory_info().rss);ct=side.cpu_times();side_cpu=ct.user+ct.system-side_start
                        except psutil.Error:pass
                    if time.monotonic()-t>1600:proc.kill();raise subprocess.TimeoutExpired(cmd,1600)
                    time.sleep(.2)
                code=proc.returncode
            except subprocess.TimeoutExpired:
                code='timeout'
        meta={'start':start,'elapsed_s':time.monotonic()-t,'exit_code':code,'command':cmd,'proxy_disabled':True,'client_peak_rss':peak_rss,'client_cpu_seconds':cpu_seconds}
        if a.wsl:
            meta['client_platform']='WSL Linux; TCP socket BBR'
            try:
                stats=json.loads(target.read_text()).get('self',{});meta['client_peak_rss']=stats.get('peak_rss',0);meta['client_cpu_seconds']=stats.get('cpu_seconds',0)
            except ValueError:pass
        if side:meta.update(sidecar_pid=a.observe_pid,sidecar_peak_rss=side_rss,sidecar_cpu_seconds=side_cpu)
        (out/(name+'.meta.json')).write_text(json.dumps(meta,indent=2),encoding='utf-8')
        print(name,code,round(meta['elapsed_s'],2),flush=True)
        time.sleep(2)
