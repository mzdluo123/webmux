from suite_helpers import *
import traceback
while not (ROOT/'results/business-forward-1GiB.meta.json').exists():time.sleep(2)
def run(label,args,timeout=300):
 start=time.time()
 with (ROOT/'results'/f'{label}.json').open('w') as f,(ROOT/'results'/f'{label}.log').open('w') as err:r=subprocess.run([str(ROOT/'relay-business-v2.exe')]+args,env=ENV,cwd=ROOT,stdout=f,stderr=err,timeout=timeout)
 (ROOT/'results'/f'{label}.meta.json').write_text(json.dumps({'start':start,'seconds':time.time()-start,'exit_code':r.returncode,'proxy_disabled':True}))
 print(label,r.returncode,flush=True)
try:
 run('security-current',['-mode','security'])
 for pool in [1,2,4]:
  run(f'slow-wss-smux-p{pool}',['-mode','slow','-proto','wss-smux','-pool',str(pool),'-seconds','20'])
 profile('clean')
 matrix('bbr-pool4','wss-smux',pools='4',size=8*1024*1024,seconds=10,wsl=True)
 print(remote('ip netns exec relay604 nft add table inet blackhole604\nip netns exec relay604 nft add chain inet blackhole604 input \'{ type filter hook input priority 0; policy accept; }\'\nip netns exec relay604 nft add rule inet blackhole604 input udp dport 18447 drop','udp-blackhole'),flush=True)
 try:
  matrix('udp-blackhole','quic,wss-smux',pools='1',size=1048576,seconds=2)
 finally:remote('ip netns exec relay604 nft delete table inet blackhole604','udp-restore')
 p=ROOT/'fault_restart.py';p.write_text(p.read_text().replace('./relay-business-server-linux','./relay-business-server-v2-linux'),encoding='utf-8',newline='\n')
 run('business-restart',['-mode','business','-port','18452','-bytes','1048576','-seconds','3','-fault-hook',str(p)],timeout=300)
 for protocol in ['tcp','wss','quic','kcp']:
  subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','/mnt/d/604/relay-validation/launch-frpc.sh',protocol],env=ENV,check=True)
  business('frp-'+protocol,port=18455,size=8*1024*1024,seconds=10)
 subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','-c','cd /tmp/webmux-relay-604; kill "$(cat frpc.pid)"'],env=ENV,check=True)
 sshbase=[r'C:\Windows\System32\OpenSSH\ssh.exe','-N','-T','-p','19004','-i',str(ROOT/'ssh-client-key'),'-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(ROOT/'ssh-known-hosts'),'-o','ExitOnForwardFailure=yes','-o','ProxyCommand=none','-o','ProxyJump=none','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=3']
 processes=[]
 try:
  for listen in ['19011','19012']:
   p=subprocess.Popen(sshbase+['-R',f'127.0.0.1:{listen}:127.0.0.1:17681','relay604@172.233.136.221'],env=ENV,stdout=subprocess.DEVNULL,stderr=(ROOT/'results'/f'ssh-{listen}.log').open('w'));processes.append(p);time.sleep(3)
   if p.poll() is not None:raise RuntimeError('SSH forward failed')
  business('ssh-p2',port=18456,size=8*1024*1024,seconds=10)
 finally:
  for p in processes:p.terminate()
except Exception:traceback.print_exc()
finally:
 profile('clean')
 (ROOT/'results/final-checks-done.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
