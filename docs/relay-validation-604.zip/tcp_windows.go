package main

import "syscall"

// Windows uses its configured congestion provider. No BBR claim is made here.
func tcpControl(network, address string, raw syscall.RawConn) error { return nil }
func platformMetrics() map[string]any                               { return map[string]any{} }
