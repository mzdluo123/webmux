import json,pathlib,math,collections,csv,datetime,re
r=pathlib.Path(__file__).resolve().parent
groups=collections.defaultdict(list)
for p in (r/'results').glob('*.json'):
    if p.name.startswith(('pilot-','smoke-','screen-','business-','final-smoke')) or '.meta.' in p.name:continue
    try:d=json.loads(p.read_text(encoding='utf-8-sig'))
    except (ValueError,OSError):continue
    if not isinstance(d,dict) or 'proto' not in d or 'pool' not in d or 'bulk' not in d:continue
    label=re.sub(r'-r\d+-.*$','',p.stem)
    groups[(label,d['proto'],d['pool'])].append((p,d))
rows=[]
for (label,proto,pool),runs in sorted(groups.items()):
    row={'profile':label,'proto':proto,'pool':pool,'runs':len(runs),'hash_ok':True,'client_peak_mib':0,'client_cpu_seconds':0}
    for phase in ('idle','download','upload'):
        samples=[s for _,d in runs for s in d['samples'] if s['phase']==phase and (phase=='idle' or s.get('bulk_active'))]
        good=sorted(s['ms'] for s in samples if s['ok'])
        row[phase+'_n']=len(good);row[phase+'_failures']=sum(not s['ok'] for s in samples)
        for q in (50,95,99):row[f'{phase}_p{q}']=round(good[int((len(good)-1)*q/100)],2) if good else None
        if phase!='idle':
            throughput=[]
            for _,d in runs:
                b=[b for b in d['bulk'] if b['direction']==phase]
                row['hash_ok'] &= all(b['hash_ok'] for b in b)
                if b and all(x['hash_ok'] for x in b) and max(x['seconds'] for x in b)>0:throughput.append(sum(x['bytes'] for x in b)*8/max(x['seconds'] for x in b)/1e6)
            row[phase+'_mbps']=round(sum(throughput)/len(throughput),3) if throughput else None
    for path,d in runs:
        meta=path.with_name(path.stem+'.meta.json')
        if meta.exists():
            m=json.loads(meta.read_text());row['client_peak_mib']=max(row['client_peak_mib'],round(m.get('client_peak_rss',0)/1024**2,2));row['client_cpu_seconds']+=m.get('client_cpu_seconds',0)
    rows.append(row)
(r/'summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
if rows:
    with (r/'summary.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('| profile | protocol/pool | runs | idle p95 | down p95 | up p95 | down/up Mbps | hash |')
print('|---|---|---:|---:|---:|---:|---:|---|')
for x in rows:print(f"| {x['profile']} | {x['proto']}/{x['pool']} | {x['runs']} | {x['idle_p95']} | {x['download_p95']} | {x['upload_p95']} | {x['download_mbps']}/{x['upload_mbps']} | {x['hash_ok']} |")
