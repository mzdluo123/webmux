# issue #604 实验证据包

这是独立实验程序与无正文统计，不是 WebMux 的生产 Relay 实现。报告见仓库 docs/relay-validation-604.md。
MANIFEST.json 记录每个文件的 SHA-256；results 保存原始成功、失败和校准样本，summary.csv/json 保存组件汇总。

## 先准备环境

- 管理机为 Windows，使用 C:\Windows\System32\OpenSSH\ssh.exe/scp.exe；Python 3 + psutil、Go 1.26.3、可用的 Debian WSL。
- 远程使用独立 Debian/Linux，root、iproute2/nftables、BBR、Python；仅在可清空的专用环境复现。
- 全部依赖和发布包下载在测量之前完成。Go 依赖由 go.mod/go.sum 固定；产品版本在报告及 build-info.json 中。
- 若沿用批处理脚本，目录布局为 D:\604\relay-validation、WSL /tmp/webmux-relay-604、远程 /root/relay-validation。
- 更换服务器时，将夹具中 172.233.136.221、eth0 和路径改为实际环境；证书校验名仍为 relay-bench，不能使用 skipVerify。
- 生成新的随机凭据，不复用他人测试证书/Token；证据包故意不含这些材料。

## 构建与启动最小矩阵

```powershell
$ssh = "$env:WINDIR\System32\OpenSSH\ssh.exe"
$scp = "$env:WINDIR\System32\OpenSSH\scp.exe"
$server = '172.233.136.221'
$env:CGO_ENABLED = '0'
go build -o relay-current.exe .
./relay-current.exe -mode cert
python prepare.py
$env:GOOS = 'linux'
go build -o relay-server-linux .
Remove-Item Env:GOOS
& $ssh -o ProxyCommand=none -o ProxyJump=none "root@$server" 'mkdir -p /root/relay-validation; chmod 700 /root/relay-validation'
& $scp @('relay-server-linux','cert.pem','key.pem','webmux-remote.toml','reproduce-server.sh','set-profile.sh','monitor.py') "root@${server}:/root/relay-validation/"
```

将 WebMux 固定到 488ba406，按其 make build 流程在 Linux 构建 CGO_ENABLED=0 的 webmux-linux，复制到远程上述目录。
该构建可包含正常前端；本轮报告只验收后端业务，不声称运行过浏览器 UI。
通过 Windows SSH 执行 `bash /root/relay-validation/reproduce-server.sh`，确认仅测试 namespace/端口被创建，保留初始化输出。
脚本仅用于新实验环境；若 relay604 已存在会拒绝，不能把旧 pid 文件当作当前服务归属。

清除测量子进程所有 proxy 环境变量并设置 NO_PROXY=*，再运行：

```powershell
python run_matrix.py --label current --protocols tls-yamux,tls-smux,wss-yamux,wss-smux,wss-frpyamux,quic,kcp,kcp-fec --pools 1,2 --rounds 1 --bytes 16777216 --seconds 12 --kcp-no-cc 1 --kcp-window 1024
```

run_matrix.py 会自行构造无代理环境；Linux 测试程序的 TCP socket 显式要求 BBR，不支持时失败而非静默冒充。
WSL 先 modprobe tcp_bbr，再将 Linux 实验二进制复制为 /tmp/webmux-relay-604/bench-client；证书也复制到该私有目录，运行 run_matrix.py --wsl。
远程通过 set-profile.sh 选择 clean/loss1/loss3/burst/asym/rtt500/mtu1280；记录 tc -s 输出，在真实 WAN 之上叠加损伤。
udp_probe.py 的服务端必须显式指定 --allowed-peer，不保存或发布该值；最终往返损伤以实际探测为准。

## 真实业务与补充实验

真实 A：WebMux 在远程 namespace 的 127.0.0.1:17681，客户端 `-mode business -port 18451`。
真实 A+B：本机 WSL 启动独立 WebMux 127.0.0.1:17681，使用 webmux-local.toml；运行 `-mode host -proto wss-smux -pool 2` 主动连接远程。
Windows 业务客户端运行 `-mode business -port 18452 -bytes 104857600 -seconds 20 -echo-entire-bulk`，检查 JSON 中布尔值、状态码和接收哈希，不能只看退出码。
100 MiB 下载必须使用 code/node 文件接口，附件预览有 10 MiB 上限；保存失败校准样本，不能混作成功。
构建 cmd/httpfixture，在 WSL 回环 17683 启动后，业务客户端添加 `-forward-bytes 1073741824`，通过 WebMux 转发测试真实 1 GiB 流式 PUT/GET。
此路径检查转发 ticket 单次兑换、Cookie/XFF 剥离、未注入 Authorization 和 Trailer 哈希；不会把原生附件 API 的大小上限改成 1 GiB。

`-mode security`、`-mode halfclose`、`-mode slow`、`-mode compete` 对应证书/取消、半关闭、停止读取和相邻流实验。
UDP 黑洞只对 namespace 的被测 UDP 端口 DROP，结束后删除规则；不要对管理 SSH 或公网接口加损伤。
恢复脚本仅编排测试服务和宿主连接器重启，属于手工实验，不是生产自动重连实现。
frp/Hysteria/SSH 需另装报告所列固定发布版本；prepare.py 生成其私有配置，限制回源/端口，不对公网提供任意代理。
frp WSS 补测的 TLS 前置程序仅转发到固定回环 19006；额外进程和不同默认窗口在报告中单列。

## 复核与收尾

```powershell
go vet ./...
go test ./...
python summarize.py
```

实验模块没有单元测试；验收证据来自真实网络运行，不把 go test 的 no test files 说成协议测试通过。
统计仅保存随机标记是否出现、时间、字节、哈希结果和资源，不保存终端正文、Token/Cookie 或 packet payload。
使用自己的 pid 文件和 /proc/pid/cwd 核实归属后停止实验进程，删除专用 namespace、nft 表和测试账户；保留 BBR 设置可按运营需要决定。
不要删除或停止 WSL 中其他开发服务；私钥/生成配置应留在私有目录或销毁，不上传到 issue/PR。
