#!/bin/bash
set -eu
cd /tmp/webmux-relay-604
if test -s host.pid; then kill "$(cat host.pid)" 2>/dev/null || true; fi
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY PI_PROXY http_proxy https_proxy all_proxy
export NO_PROXY='*' no_proxy='*'
: > host.log
nohup ./bench-business -mode host -proto "$1" -pool "$2" -kcp-no-cc 1 -kcp-window 1024 > host.log 2>&1 < /dev/null &
echo $! > host.pid
for i in $(seq 1 60); do
  if grep -q 'authenticated reverse host ready' host.log; then echo 'host ready'; exit 0; fi
  if ! kill -0 "$(cat host.pid)" 2>/dev/null; then cat host.log; exit 1; fi
  sleep 0.2
done
cat host.log
exit 1
