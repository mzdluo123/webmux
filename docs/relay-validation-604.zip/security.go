package main

import (
	"context"
	"crypto/ecdsa"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"io"
	"net"
	"os"
	"time"

	quic "github.com/quic-go/quic-go"
)

func security() {
	result := map[string]any{}
	for _, name := range []string{"valid", "missing_client", "wrong_ca", "wrong_hostname", "tls12"} {
		cfg := credentials(false)
		switch name {
		case "missing_client":
			cfg.Certificates = nil
		case "wrong_ca":
			cfg.RootCAs = x509.NewCertPool()
		case "wrong_hostname":
			cfg.ServerName = "wrong.invalid"
		case "tls12":
			cfg.MinVersion = tls.VersionTLS12
			cfg.MaxVersion = tls.VersionTLS12
		}
		start := time.Now()
		c, e := tls.DialWithDialer(&net.Dialer{Timeout: 5 * time.Second}, "tcp", net.JoinHostPort(*addr, "18443"), cfg)
		accepted := false
		if e == nil {
			c.SetDeadline(time.Now().Add(5 * time.Second))
			s, err := mux(c, "tls-yamux", false)
			if err == nil {
				st, err := s.Open()
				if err == nil {
					header(st, 1, 0)
					st.Write(make([]byte, 32))
					var b [32]byte
					_, err = io.ReadFull(st, b[:])
					accepted = err == nil
					st.Close()
				}
				s.Close()
			}
			c.Close()
		}
		result[name] = map[string]any{"application_accepted": accepted, "elapsed_ms": float64(time.Since(start).Microseconds()) / 1000}
	}
	cfg := credentials(false)
	cert, _ := x509.ParseCertificate(cfg.Certificates[0].Certificate[0])
	key, ok := cert.PublicKey.(*ecdsa.PublicKey)
	result["ecdsa_p256"] = ok && key.Curve.Params().BitSize == 256
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	c, e := quic.DialAddr(ctx, net.JoinHostPort(*addr, "18447"), cfg, nil)
	if e == nil {
		defer c.CloseWithError(0, "done")
		s, e := c.OpenStreamSync(ctx)
		if e == nil {
			header(s, 2, 16*1024*1024)
			var b [32]byte
			_, e = io.ReadFull(s, b[:])
			s.CancelRead(604)
			s.CancelWrite(604)
			result["cancel_bulk_stream"] = e == nil
		}
		s, e = c.OpenStreamSync(ctx)
		if e == nil {
			header(s, 1, 0)
			start := time.Now()
			s.SetDeadline(time.Now().Add(5 * time.Second))
			s.Write(make([]byte, 32))
			var b [32]byte
			_, e = io.ReadFull(s, b[:])
			result["sibling_after_cancel_ok"] = e == nil
			result["sibling_after_cancel_ms"] = float64(time.Since(start).Microseconds()) / 1000
			s.Close()
		}
	}
	json.NewEncoder(os.Stdout).Encode(result)
}
