import json,pathlib
root=pathlib.Path(__file__).resolve().parent
r=root/'results'
def render():
 a=json.loads((root/'resource-analysis.json').read_text());b=['## 资源、流量与相邻流','', '同机 WSL、自然链路、pool=2 的实验客户端资源如下。CPU 为进程累计秒数，RSS 为采样/自报峰值，不包含全部内核软中断成本。','', '| 组合 | 客户端 RSS MiB | CPU s |','| --- | ---: | ---: |']
 for x in a['component_clients']:b.append(f"| {x['proto']}/2 | {x['client_peak_mib']:.2f} | {x['client_cpu_seconds']:.3f} |")
 b+=['','1 GiB 整次业务中，远程 Relay 采样 RSS 峰值约 20.37 MiB、进程 CPU 约 38.23 s；Windows 客户端观测峰值约 17.10 MiB、CPU 约 20.33 s。',
 'Windows 资源观察在进程启动后才附着，未捕捉全部启动瞬间；这些是观测值，不能作为形式化内存上限。']
 p=r/'host-final-snapshot.json'
 if p.exists():
  d=json.loads(p.read_text());b+=['','WSL 无历史监控数据，以下是测试结束后 `/proc` 的生命周期内存峰值，窗口与上述单次采样不同：','', '| 宿主进程 | 生命周期 VmHWM MiB |','| --- | ---: |']
  for x in d['processes']:b.append(f"| {x['label']} | {x['lifetime_peak_rss']/1048576:.2f} |")
 b+=['','### 聚合 IP 字节成本','', '以下是服务器 eth0 在试验起止附近的端口计数增量 / 已确认双向有效字节；包含 ACK、握手、心跳、重传和 FEC，不能拆成纯 FEC 冗余率。',
 '1 Hz 采样、约 0.26 s 时钟偏移及 GSO/GRO 会影响边界；netem 位于 veth，因此这也不是精确线上计费或全路径丢包率。','', '| 档位 | WSS/smux 2 | QUIC 2 | KCP 2 | KCP/FEC 2 |','| --- | ---: | ---: | ---: | ---: |']
 for profile in ['bbr-current','bbr-loss1','bbr-loss3']:
  vals=[]
  for proto in ['wss-smux','quic','kcp','kcp-fec']:
   x=next((x for x in a['wire'] if x['case']==profile+'-r1-'+proto+'-p2'),None);v=x.get('ip_to_payload_ratio') if x else None;vals.append(f'{v:.2f}x' if v else '未取得')
  b.append('| '+profile+' | '+' | '.join(vals)+' |')
 b+=['','所测 FEC 组合在自然链路与弱网下的总 IP 成本更高；这与有限吞吐收益共同支持“不默认开启”，不把全部差额归因于 10+3 的理论 30%。',
 '', '### 同路径相邻 TCP 流','', '人为每方向限速 20 Mbps，一条普通 TLS/TCP 下载持续约 60 s，与候选交替运行；接收内容前缀逐字节校验。各候选仅一轮。',
 '| 候选 | 候选下载 Mbps | 同时段相邻 TCP Mbps | 重叠整秒数 |','| --- | ---: | ---: | ---: |']
 for x in a['fairness']:
  if x['candidate']=='baseline':continue
  n=x.get('neighbor_overlap_mean_mbps');v=x.get('candidate_download_mbps')
  b.append(f"| {x['candidate']} | {v:.2f} | {n:.2f} | {x.get('neighbor_overlap_n')} |")
 b+=['','独立相邻流基线全程仅约 4.78 Mbps，中段约 5.06 Mbps；共存时反而可达到 5–6 Mbps，说明时变路径/启动过程影响明显。',
 '这轮没有观察到相邻流完全饿死，但不能据此推出侵占倍率、Jain 公平指数或长期公平性保证；稳定瓶颈、相同总预算和多轮重复仍待补测。','']
 return '\n'.join(b)
