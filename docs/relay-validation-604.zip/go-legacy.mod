module relay-validation

go 1.26

require (
	github.com/coder/websocket v1.8.12
	github.com/hashicorp/yamux v0.1.2
	github.com/quic-go/quic-go v0.59.1
	github.com/xtaci/kcp-go/v5 v5.6.72
	github.com/xtaci/smux v1.5.24
)

require (
	github.com/klauspost/cpuid/v2 v2.2.6 // indirect
	github.com/klauspost/reedsolomon v1.12.0 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/tjfoc/gmsm v1.4.1 // indirect
	golang.org/x/crypto v0.45.0 // indirect
	golang.org/x/net v0.47.0 // indirect
	golang.org/x/sys v0.38.0 // indirect
	golang.org/x/time v0.14.0 // indirect
)
