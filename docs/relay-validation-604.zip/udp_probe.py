import socket,time,threading,json,statistics,argparse,os
p=argparse.ArgumentParser();p.add_argument('--server',action='store_true');p.add_argument('--count',type=int,default=200);p.add_argument('--allowed-peer',default=os.environ.get('R604_ALLOWED_PEER',''));a=p.parse_args()
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
if a.server:
    if not a.allowed_peer:raise ValueError('server requires an explicit allowed peer address')
    s.bind(('0.0.0.0',18459))
    while True:
        b,peer=s.recvfrom(1024)
        if peer[0]==a.allowed_peer and len(b)==64 and b[:4]==b'R604':s.sendto(b,peer)
else:
    s.settimeout(.2);received={};sent={};done=False
    def reader():
        while not done:
            try:
                b,_=s.recvfrom(1024);seq=int.from_bytes(b[4:8],'big')
                if seq in sent:received[seq]=(time.perf_counter()-sent[seq])*1000
            except socket.timeout:pass
    threading.Thread(target=reader,daemon=True).start()
    for seq in range(a.count):
        b=b'R604'+seq.to_bytes(4,'big')+bytes(56);sent[seq]=time.perf_counter();s.sendto(b,('172.233.136.221',18459));time.sleep(.02)
    time.sleep(3);done=True;v=sorted(received.values())
    print(json.dumps({'time':time.time(),'sent':len(sent),'received':len(v),'round_trip_loss_pct':(len(sent)-len(v))*100/len(sent),'rtt_p50_ms':statistics.median(v) if v else None,'rtt_p95_ms':v[int((len(v)-1)*.95)] if v else None,'rtt_p99_ms':v[int((len(v)-1)*.99)] if v else None}))
