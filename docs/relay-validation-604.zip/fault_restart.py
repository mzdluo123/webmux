"""Operator-orchestrated Relay restart; never described as automatic reconnect."""
from suite_helpers import *
import sys,urllib.request,uuid,socket
sid,marker=sys.argv[1:3]
start=time.monotonic()
remote('cd /root/relay-validation\nkill "$(cat ns-server.pid)"','fault-stop-relay')
unavailable=False
try:s=socket.create_connection(('172.233.136.221',18452),timeout=2);s.close()
except OSError:unavailable=True
detected=time.monotonic()-start
secret=json.loads((ROOT/'secrets.json').read_text())['webmux']
payload=json.dumps({'clientRequestId':uuid.uuid4().hex,'text':marker}).encode()
req=urllib.request.Request(f'http://127.0.0.1:17681/api/sessions/{sid}/input',data=payload,headers={'Authorization':'Bearer '+secret,'Origin':'http://127.0.0.1:17681','Content-Type':'application/json'})
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open(req,timeout=10) as resp:written=resp.status==200;resp.read()
time.sleep(2)
remote('cd /root/relay-validation\nnohup ip netns exec relay604 ./relay-business-server-v2-linux -mode server -kcp-no-cc 1 -kcp-window 1024 > server-business.log 2>&1 < /dev/null &\necho $! > ns-server.pid\nsleep 1','fault-start-relay')
subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','/mnt/d/604/relay-validation/launch-host.sh','wss-smux','2'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
print(json.dumps({'manual_orchestrated':True,'unavailable_observed':unavailable,'unavailable_observed_s':detected,'offline_input_acknowledged':written,'host_ready_s':time.monotonic()-start}))
