from pathlib import Path
import json,gzip,bisect,datetime,statistics
root=Path(__file__).resolve().parent
r=root/'results'
def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def lines(path):
 out=[]
 if path.exists():
  with gzip.open(path,'rt',encoding='utf-8') as f:
   for s in f:
    try:out.append(json.loads(s))
    except ValueError:pass
 return out
server=lines(r/'metrics.jsonl.gz');host=lines(r/'metrics-host.jsonl.gz')
resource=[]
for d in load(root/'summary.json'):
 if d['profile']=='bbr-current' and d['pool']==2:
  resource.append({k:d[k] for k in ['proto','pool','client_peak_mib','client_cpu_seconds']})
gib={}
if server:
 meta=load(r/'business-forward-1GiB.meta.json');a=meta['start'];b=a+meta['seconds']
 for name,records,field,accept in [('relay',server,'name',lambda x:x.startswith('relay-business')),('host',host,'label',lambda x:x=='host'),('webmux',host,'label',lambda x:x=='webmux'),('fixture',host,'label',lambda x:x=='httpfixture')]:
  chosen=[(x['time'],p) for x in records if a<=x['time']<=b for p in x['processes'] if accept(p[field])]
  if not chosen:continue
  pids={p['pid'] for _,p in chosen};cpu=0
  for pid in pids:
   points=[(t,p['cpu_ticks']) for t,p in chosen if p['pid']==pid]
   cpu+=(points[-1][1]-points[0][1])/100
  gib[name]={'peak_rss_mib':max(p['rss'] for _,p in chosen)/1048576,'cpu_seconds_observed':cpu,'wall_s':b-a,'samples':len(chosen)}
 windows=r/'business-forward-1GiB-client-resource.json'
 if windows.exists():
  v=load(windows);gib['windows']={'peak_rss_mib':v['peak_rss']/1048576,'cpu_seconds_observed':v['cpu_seconds'],'wall_s':v['observed_s'],'samples':v['samples'],'attached_after_start':True}
ports={'tls-yamux':18443,'tls-smux':18444,'wss-yamux':18445,'wss-smux':18446,'quic':18447,'kcp':18448,'kcp-fec':18449,'wss-frpyamux':18458,'quic1200':18460,'sidecar':19003}
wire=[]
if server:
 times=[x['time'] for x in server]
 for p in sorted(r.glob('*.meta.json')):
  data=p.with_name(p.name.replace('.meta.json','.json'))
  if not data.exists() or not data.stat().st_size:continue
  try:d=load(data);m=load(p)
  except ValueError:continue
  if not isinstance(d,dict) or 'bulk' not in d or d.get('proto') not in ports:continue
  a=m.get('start')
  if isinstance(a,str):
   try:a=datetime.datetime.fromisoformat(a.replace('Z','+00:00')).timestamp()
   except ValueError:continue
  if not isinstance(a,(int,float)):continue
  b=a+m.get('elapsed_s',0)
  if a<times[0] or b>times[-1]:continue
  x=server[max(0,bisect.bisect_right(times,a)-1)];y=server[min(len(server)-1,bisect.bisect_left(times,b))];port=ports[d['proto']]
  def total(v):return sum(n[1] for key,n in v['counts'].items() if key.startswith(str(port)+'/'))
  size=sum(t['bytes'] for t in d['bulk']);ok=all(t.get('hash_ok') for t in d['bulk'])
  n=total(y)-total(x)
  wire.append({'case':data.stem,'ip_bytes_estimate':n,'acknowledged_payload_bytes':size,'ip_to_payload_ratio':n/size if size and ok else None,'hash_ok':ok,'sample_span_s':y['time']-x['time']})
fairness=[]
for p in r.glob('fairness-*-neighbor.json'):
 if not p.stat().st_size:continue
 d=load(p);label=p.stem.removeprefix('fairness-').removesuffix('-neighbor')
 vals=[x['Bytes'] if 'Bytes' in x else x['bytes'] for x in []]
 baseline=[x['bytes']*8/1e6 for x in d['intervals'][5:-3]]
 row={'candidate':label,'neighbor_full_mbps':d['mbps'],'prefix_verified':d['prefix_verified'],'interval_n':len(baseline),'neighbor_middle_mean_mbps':statistics.mean(baseline) if baseline else None}
 if label!='baseline':
  candidates=list(r.glob('fairness-'+label+'-r*-*.json'));candidates=[q for q in candidates if '.meta.' not in q.name]
  if candidates:
   c=load(candidates[0]);samples=[x for x in c['samples'] if x['phase']=='download' and x.get('bulk_active')]
   if samples:
    def stamp(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
    start=min(stamp(x['at']) for x in samples);end=max(stamp(x['at'])+x['ms']/1000 for x in samples)
    rates=[x['bytes']*8/1e6 for x in d['intervals'] if start+1<=stamp(x['at'])<=end]
    row.update(neighbor_overlap_n=len(rates),neighbor_overlap_mean_mbps=statistics.mean(rates) if rates else None)
   down=[x for x in c['bulk'] if x['direction']=='download'];row['candidate_download_mbps']=sum(x['bytes'] for x in down)*8/max(x['seconds'] for x in down)/1e6 if down else None
 fairness.append(row)
(root/'resource-analysis.json').write_text(json.dumps({'component_clients':resource,'gib':gib,'wire':wire,'fairness':fairness},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'gib':gib,'fairness':fairness},ensure_ascii=False,indent=2))
