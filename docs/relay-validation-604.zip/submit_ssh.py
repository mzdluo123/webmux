import pathlib,base64,time,argparse,textwrap,uuid
r=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--upload',nargs='*',default=[]);p.add_argument('--run');p.add_argument('--name',default='job');a=p.parse_args()
lines=['set -e','cd /root/relay-validation']
for file in a.upload:
    path=r/file
    assert all(c.isalnum() or c in '.-_' for c in path.name)
    data=path.read_text().encode() if path.suffix in ('.sh','.py','.toml','.yaml') else path.read_bytes()
    marker='FILE_'+uuid.uuid4().hex
    encoded=base64.b64encode(data).decode()
    lines.append(f"base64 -d > {path.name} <<'{marker}'\n"+'\n'.join(encoded[i:i+76] for i in range(0,len(encoded),76))+f'\n{marker}')
if a.run:lines.append((r/a.run).read_text())
job=r/'ssh-jobs'/f'{time.time_ns()}-{a.name}.sh';temp=job.with_suffix('.tmp');temp.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n');temp.replace(job);print(job.name)
