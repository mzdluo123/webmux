#!/bin/bash
# Fresh dedicated test server only. No package downloads or benchmark starts outside this directory.
set -euo pipefail
cd /root/relay-validation
if ip netns list | grep -q '^relay604 '; then echo 'relay604 already exists; inspect/clean the previous experiment first' >&2; exit 1; fi
modprobe tcp_bbr
sysctl -w net.ipv4.tcp_congestion_control=bbr net.core.default_qdisc=fq net.ipv4.ip_forward=1
ip netns add relay604
ip link add r604-host type veth peer name r604-peer
ip link set r604-peer netns relay604
ip addr add 10.60.4.1/24 dev r604-host
ip link set r604-host up
ip netns exec relay604 ip addr add 10.60.4.2/24 dev r604-peer
ip netns exec relay604 ip link set r604-peer up
ip netns exec relay604 ip link set lo up
ip netns exec relay604 ip route add default via 10.60.4.1
ip netns exec relay604 sysctl -w net.ipv4.tcp_congestion_control=bbr
nft add table ip relay604
nft 'add chain ip relay604 prerouting { type nat hook prerouting priority dstnat; policy accept; }'
nft 'add chain ip relay604 postrouting { type nat hook postrouting priority srcnat; policy accept; }'
nft 'add rule ip relay604 prerouting iifname "eth0" tcp dport { 18443-18452, 18457, 18458 } dnat to 10.60.4.2'
nft 'add rule ip relay604 prerouting iifname "eth0" udp dport { 18447-18449, 18459, 18460, 19003 } dnat to 10.60.4.2'
nft 'add rule ip relay604 postrouting ip saddr 10.60.4.0/24 oifname "eth0" masquerade'
chmod 700 relay-server-linux webmux-linux
chmod 600 key.pem webmux-remote.toml
nohup ip netns exec relay604 ./relay-server-linux -mode server -kcp-no-cc 1 -kcp-window 1024 > server-business.log 2>&1 < /dev/null &
echo $! > ns-server.pid
nohup ip netns exec relay604 ./webmux-linux -config webmux-remote.toml > webmux-ns.log 2>&1 < /dev/null &
echo $! > ns-webmux.pid
nohup python3 monitor.py > metrics.jsonl 2> metrics.err < /dev/null &
echo $! > monitor.pid
sleep 1
ip netns exec relay604 ss -lntup
