import socket,ssl,json,http.client,pathlib
r=pathlib.Path(__file__).resolve().parent
secret=json.loads((r/'secrets.json').read_text())['webmux']
ctx=ssl.create_default_context(cafile=str(r/'cert.pem'));ctx.load_cert_chain(str(r/'cert.pem'),str(r/'key.pem'));ctx.minimum_version=ssl.TLSVersion.TLSv1_3
host='172.233.136.221';port=18451;origin=f'https://{host}:{port}'
def conn():
    c=http.client.HTTPConnection(host,port,timeout=15);c.sock=ctx.wrap_socket(socket.create_connection((host,port),timeout=15),server_hostname='relay-bench');return c
c=conn();payload=json.dumps({'cmd':['/bin/cat'],'cwd':'/tmp','name':'relay604-limits'})
headers={'Authorization':'Bearer '+secret,'Origin':origin,'Content-Type':'application/json'}
c.request('POST','/api/sessions',payload,headers);resp=c.getresponse();assert resp.status==201;sid=json.loads(resp.read())['session']['id'];c.close()
try:
    c=conn();c.putrequest('POST',f'/api/sessions/{sid}/upload');c.putheader('Authorization','Bearer '+secret);c.putheader('Origin',origin);c.putheader('Content-Type','multipart/form-data; boundary=r604');c.putheader('Content-Length',str(1024**3+1000));c.endheaders();resp=c.getresponse();status=resp.status;resp.read();c.close()
    print(json.dumps({'oversize_content_length':1024**3+1000,'body_sent_bytes':0,'status':status,'rejected_without_sending_1GiB':status==413}))
finally:
    c=conn();c.request('DELETE',f'/api/sessions/{sid}',headers=headers);resp=c.getresponse();resp.read();c.close()
