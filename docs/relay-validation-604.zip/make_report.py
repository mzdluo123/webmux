from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parent
subprocess.run(['python','summarize.py'],cwd=root,stdout=subprocess.DEVNULL,check=True)
rows=json.loads((root/'summary.json').read_text())
s=(root/'REPORT.template.md').read_text(encoding='utf-8-sig')
def table(selected):
 text=['| 档位 / 组合 | 轮数 | 并发下载/上传 p95 ms | 下载/上传 Mbps |','| --- | ---: | ---: | ---: |']
 for x in selected:
  text.append(f"| {x['profile']} {x['proto']}/{x['pool']} | {x['runs']} | {x['download_p95']}/{x['upload_p95']} | {x['download_mbps']}/{x['upload_mbps']} |")
 return '\n'.join(text)
s=s.replace('<!-- CORE_TABLE -->',table(x for x in rows if x['profile'] in ['current','bbr-current','bbr-pool4']))
s=s.replace('<!-- WEAK_TABLE -->',table(x for x in rows if x['profile'] in ['bbr-loss1','bbr-loss3','bbr-burst','bbr-asym','bbr-rtt500']))
s=s.replace('<!-- HYSTERIA_TABLE -->',table(x for x in rows if x['profile'].startswith('hysteria-')))
b=['上传后由下载或流式接收端校验 SHA-256；实际操作期间持续发送 PTY 输入，以下时间为整次传输墙钟秒数。','',
 '| 路径 / 请求大小 | 上传 s（状态） | 下载 s（状态） | 空闲 PTY p50 ms | 上传/下载期间 PTY p95 ms |',
 '| --- | ---: | ---: | ---: | ---: |']
names=['A-100MiB-corrected','AB-wss-smux-p2-100MiB-corrected','AB-wss-smux-p1','AB-quic-p1','AB-quic-p2','AB-kcp-p1','AB-kcp-p2','frp-tcp','frp-wss','frp-quic','frp-kcp','ssh-p2']
for name in names:
 p=root/'results'/f'business-{name}.json'
 if not p.exists() or not p.stat().st_size:continue
 d=json.loads(p.read_text());t={x['direction']:x for x in d.get('transfers',[])};u=t.get('upload',{});v=t.get('download',{})
 sm=d.get('summary',{});size=u.get('bytes',0)/1048576
 down=f"{v['seconds']:.2f}（{v.get('status')}）" if v else '未执行'
 b.append(f"| {name} / {size:g} MiB | {u.get('seconds',0):.2f}（{u.get('status')}） | {down} | {sm.get('idle',{}).get('p50')} | {sm.get('upload',{}).get('p95')}/{sm.get('download',{}).get('p95')} |")
b+=['','A 的空闲 PTY 中位数约 317 ms，A+B 约 585 ms；这说明 A 本身有真实 RTT 成本，两段绕行会叠加，不能将组件小回显当作端到端 PTY。','100 MiB 实际文件节点下载和上传通过；8 MiB 组合用于可行性筛选，不与 100 MiB 作严格吞吐排名。',
 '最初误用附件预览接口导致 100 MiB 下载返回 413，原始失败保留；修正为 `/code/node` 后复测通过。','中断一次转发测试留下注册记录曾使后续注册失败；校准文件保留且不计作 1 GiB 成功，修复清理与断言后再测。',
 'frp QUIC 默认配置的 8 MiB 上传返回 502，未执行后续下载，不能计作成功吞吐。其原始 upload bytes 是请求量，不证明接收成功；502 根因尚未定位。',
 'frp 的直接 WSS 接入曾 unexpected EOF；补测使用 mTLS 前置 19005 → 回环 frps 19006，后者只监听回环，不为连通而关闭公网身份验证。',
 'frp 使用 tcpMux=true、poolCount=0，内置 yamux stream 窗口 6 MiB 等默认值，与组件矩阵的窗口和双连接不同；仅作为完整产品集成对照。','']
p=root/'results/business-forward-1GiB.json'
if p.exists() and p.stat().st_size:
 d=json.loads(p.read_text());b+=['### 1 GiB 流式转发与持续终端','', '| 方向 | 实收 MiB | 秒 / Mbps | PTY n / p50 / p95 / p99 ms | SHA-256 |','| --- | ---: | ---: | --- | --- |']
 for t in d['transfers']:
  if not t['direction'].startswith('forward-'):continue
  sm=d['summary'][t['direction']];secs=t.get('seconds',0);n=t.get('bytes',0)
  b.append(f"| {t['direction']} | {n/1048576:g} | {secs:.2f} / {n*8/max(secs,.001)/1e6:.2f} | {sm.get('n')} / {sm.get('p50')} / {sm.get('p95')} / {sm.get('p99')} | {t.get('hash_ok')} |")
 b+=['','1 GiB 通过真实 WebMux `/forward/*` 到回环流式夹具，使用 PUT 与 GET/Trailer 校验；不是声称原生附件 API 支持 1 GiB。',
 '一次性转发 ticket 兑换与重放拒绝、转发 Cookie/伪造 XFF 剥离及未注入 Authorization 均按原始布尔检查记录；未保存正文或凭据。',
 '本轮转发请求没有携带 Authorization，因此 authorization_absent 只验证未注入 Token，不证明剥离调用者显式提供的上游认证头。','']
else:b+=['1 GiB 流式转发仍在执行，最终结果尚未填入。','']
b+=['### 关闭、取消、黑洞与恢复','',
 '- TLS 有效证书通过；缺失客户端证书、错误 CA、错误主机名、TLS 1.2 的应用接入均拒绝。测试 ECDSA P-256 检查通过。',
 '- 8 种 TLS/WSS/QUIC/KCP 组合的 half-close 对照均能发送后半关闭并收到接收端 SHA-256 响应。',
 '- QUIC 取消批量 stream 后，兄弟回显 stream 继续成功（约 300 ms）；此优势不等同于连接拥塞预算完全隔离。',
 '- UDP 黑洞下 QUIC 建连约 5.23 s 失败，WSS 直接成功；未实现也未声称完成生产自动回退。',
 '- MTU 1280 下 QUIC 默认初始包握手失败；双方 InitialPacketSize=1200 后 pool 1/2 均连通并通过哈希。WSS 同档也通过。',
 '- Relay/宿主连接器由脚本编排重启，观测到入口不可用约 2.63 s，host ready 约 8.84 s、恢复操作约 10.16 s；离线输入确认、同代际 offset append 与标记恰好一次通过。',
 '- 停止读取批量流 20 s 时，WSS/smux pool 1/2/4 均能回收连接（关闭约 0.4–3.8 ms）；这只是短时背压检查，不能证明任意慢端/任意宿主数量的内存上限。','']
s=s.replace('<!-- BUSINESS_RESULTS -->','\n'.join(b))
from render_resources import render
s=s.replace('<!-- RESOURCE_RESULTS -->',render())
evidence='可下载 [源码与原始统计证据包](relay-validation-604.zip)，内含 README、MANIFEST、固定依赖、复现脚本、summary.csv/json 与逐次结果。'
if (root/'bundle-info.json').exists():
 info=json.loads((root/'bundle-info.json').read_text())
 evidence+=f"\n\n证据包包含 {info['files']} 个文件（不等于独立试验次数），共 {info['bytes']} bytes。\n\nSHA-256：`{info['sha256']}`。"
evidence+='\n\n源码为最终实验夹具，历史阶段的依赖和参数以构建信息、每次命令及报告标注为准；自然网络不会复现完全相同的数值。'
s=s.replace('<!-- EVIDENCE -->',evidence)
(root/'REPORT.md').write_text(s,encoding='utf-8',newline='\n')
for repo in ['webmux-validation','webmux-planning']:
 p=root.parent/repo/'docs/relay-validation-604.md';p.write_text(s,encoding='utf-8',newline='\n')
 p=p.parent/'README.md';idx=p.read_text(encoding='utf-8');line='- [Relay 真实公网验证](relay-validation-604.md)：issue #604 的传输筛选、BBR、业务与证据边界。\n'
 if '](relay-validation-604.md)' not in idx:idx=idx.replace('## 性能与质量\n','## 性能与质量\n\n'+line)
 p.write_text(idx,encoding='utf-8',newline='\n')
print('report lines',len(s.splitlines()))
