"""Linux AF_PACKET header-only counters and test-process CPU/RSS, no payload storage."""
import socket,struct,time,json,pathlib,select,os
ports=set(range(18443,18461))|{19000,19001,19002,19003,19004,19005,19006,19007,19008,19009}
s=socket.socket(socket.AF_PACKET,socket.SOCK_RAW,socket.htons(3))
s.bind(('eth0',0));s.setblocking(False)
counts={};last=time.monotonic()
# Continue cumulative counters when adding resource targets between suites.
history=pathlib.Path('/root/relay-validation/metrics.jsonl')
if history.exists():
    with history.open('rb') as f:
        f.seek(max(0,history.stat().st_size-131072));lines=f.read().splitlines()
    for line in reversed(lines):
        try:counts=json.loads(line)['counts'];break
        except (ValueError,KeyError):pass
while True:
    ready,_,_=select.select([s],[],[],max(0,1-(time.monotonic()-last)))
    if ready:
        frame,info=s.recvfrom(65535)
        if len(frame)<38 or frame[12:14]!=b'\x08\x00':continue
        ihl=(frame[14]&15)*4;proto=frame[23]
        if proto not in (6,17):continue
        sport,dport=struct.unpack('!HH',frame[14+ihl:18+ihl])
        port=sport if sport in ports else dport if dport in ports else None
        if port is None:continue
        length=struct.unpack('!H',frame[16:18])[0]
        direction='tx' if info[2]==socket.PACKET_OUTGOING else 'rx'
        key=f'{port}/{proto}/{direction}'
        v=counts.setdefault(key,[0,0]);v[0]+=1;v[1]+=length
    if time.monotonic()-last>=1:
        processes=[]
        for d in pathlib.Path('/proc').iterdir():
            if not d.name.isdigit():continue
            try:
                name=(d/'comm').read_text().strip()
                if not any(x in name for x in ('relay-','gateway','webmux','frps','hysteria')):continue
                stat=(d/'stat').read_text().split()
                processes.append({'pid':int(d.name),'name':name,'cpu_ticks':int(stat[13])+int(stat[14]),'rss':int(stat[23])*os.sysconf('SC_PAGE_SIZE')})
            except (OSError,ValueError):pass
        print(json.dumps({'time':time.time(),'counts':counts,'processes':processes,'load':os.getloadavg()[0]}),flush=True)
        last=time.monotonic()
