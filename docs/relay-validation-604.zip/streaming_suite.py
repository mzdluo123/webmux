from suite_helpers import *
while not (ROOT/'results/final-checks-done.txt').exists():time.sleep(2)
for n,label in [(1048576,'smoke'),(1073741824,'1GiB')]:
 cmd=[str(ROOT/'relay-streaming-v3.exe'),'-mode','business','-port','18452','-bytes','1048576','-seconds','10','-echo-entire-bulk','-forward-bytes',str(n)]
 start=time.time()
 with (ROOT/'results'/f'business-forward-{label}.json').open('w') as f,(ROOT/'results'/f'business-forward-{label}.log').open('w') as err:
  r=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=f,stderr=err,timeout=4000)
 (ROOT/'results'/f'business-forward-{label}.meta.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.time()-start,'start':start,'proxy_disabled':True}))
 print(label,r.returncode,flush=True)
 d=json.loads((ROOT/'results'/f'business-forward-{label}.json').read_text())
 if r.returncode or not d.get('checks',{}).get('forward_registered') or not all(t.get('hash_ok',True) for t in d.get('transfers',[])):raise RuntimeError('business checks failed: '+label)
