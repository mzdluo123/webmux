from suite_helpers import *
print('Business A',flush=True)
business('A-100MiB',port=18451,size=100*1024*1024,seconds=20)
for proto in ['wss-smux','quic','kcp']:
    for pool in [1,2]:
        label=f'AB-{proto}-p{pool}';print(label,flush=True)
        remote('cd /root/relay-validation\nkill "$(cat ns-server.pid)"\nnohup ip netns exec relay604 ./relay-business-server-linux -mode server -kcp-no-cc 1 -kcp-window 1024 > server-business.log 2>&1 < /dev/null &\necho $! > ns-server.pid\nsleep 1','business-reset')
        subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','/mnt/d/604/relay-validation/launch-host.sh',proto,str(pool)],check=True)
        size=100*1024*1024 if proto=='wss-smux' and pool==2 else 8*1024*1024
        business(label,size=size,seconds=20)
remote('cd /root/relay-validation\nkill "$(cat ns-server.pid)"\nnohup ip netns exec relay604 ./relay-business-server-linux -mode server -kcp-no-cc 1 -kcp-window 1024 > server-business.log 2>&1 < /dev/null &\necho $! > ns-server.pid\nsleep 1','business-final-reset')
print('Business matrix complete',flush=True)
