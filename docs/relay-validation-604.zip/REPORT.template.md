# Relay 真实公网验证报告：issue #604

本轮建议 MVP 采用 **WSS + smux v2、控制/交互与批量两条有界连接、嵌入 Go 库**，A 段保持 HTTPS/WebSocket。
服务器 TCP 使用 BBR；不在 MVP 引入 QUIC 优先探测、UDP 回退或 FEC。此决定针对下述实测路径与工程成本，不能概括所有网络或所有 QUIC 实现。
关联：[issue #604](https://github.com/mzdluo123/webmux/issues/604)、[规划 PR #558](https://github.com/mzdluo123/webmux/pull/558)。

## 验证对象与环境

测试于 2026-11-14 执行，统计时间以 UTC 保存。客户端始终位于当前这台电脑，目标为用户提供的 `172.233.136.221`。
正式流量走本机以太网默认路由；没有用服务器内部回环成绩代替公网成绩，也没有通过本机环境代理转发测试流量。

| 项目 | 实际环境 |
| --- | --- |
| Windows | Windows 11 Pro 10.0.26300；Core Ultra 7 270K Plus，24 逻辑核，31.4 GiB RAM |
| 管理通道 | Windows OpenSSH；不使用 WSL ssh 管理服务器 |
| 原生 TCP | 连接 AppliedSetting=Internet，对应 CTCP；不是 Windows BBR |
| 同机 Linux | Debian WSL，6.18.54.1-microsoft-standard-WSL2；测试 socket 指定 BBR |
| 服务器 | Debian 13，Linux 6.12.113+deb13-amd64，1 vCPU，967 MiB RAM |
| 服务端 TCP | 拥塞控制 bbr，由 ss -tin 核实；default_qdisc=fq，现存 eth0 实际为 mq/fq_codel |
| 工具链 | 实验 Go 1.26.3；真实 WebMux 488ba406，Go 1.27.4，CGO_ENABLED=0 |
| 浏览器 | 本轮用真实 WebMux 后端和协议客户端；未验收浏览器 UI/H3/WebTransport |

测量子进程清除所有名称含 proxy 的环境变量，设置 `NO_PROXY=*`；Go HTTP Transport 显式 `Proxy:nil`，SSH 显式禁用 ProxyCommand/ProxyJump。
依赖和发布包下载属于准备阶段，不计入正式吞吐。Hysteria 是被测的显式受管转发器，与环境代理分开记录。
WSL 仅加载 BBR 模块并按测试 socket 设置，不更改用户 WSL 全局默认 CUBIC；其他开发服务不接入本实验。
设置 default_qdisc 不会替换既有网卡队列。本轮保留 eth0 的 mq/fq_codel，不能宣称已经测过物理接口 fq；MVP 的 fq 部署建议仍需核实实际队列。
frpc 未逐 socket 改 BBR，使用 WSL 默认 TCP 策略；Windows OpenSSH 使用原生 TCP 策略。它们是完整产品对照，不混作双端 BBR 组件成绩。
地区、运营商和机房地理位置未独立确认；不发布客户端公网 IP，不把此单出口结果称为全国多运营商验证。

## A、B 与组合路径

```text
A：当前电脑客户端 → 公网 → 远程 HTTPS 入口 → 远程回环 WebMux
B：当前电脑 WSL 宿主 → 公网 → 远程 Relay，宿主主动出站建立反向通道
A+B：当前电脑客户端 → 公网 → 远程入口 → B 反向通道 → 当前电脑 WSL WebMux
```

组件矩阵在同一真实公网路径上测 B 候选的字节流与并发小回显；随后用真实 WebMux 做 A 和 A+B 的 PTY、REST、文件及转发验证。
A 与 B 都跨同一 WAN 时，输入到真正 PTY 输出会经历两段路径；仅优化 B 无法消除 A 的往返时间。
真实 PTY 运行 `stty -echo -icanon min 1 time 0; exec cat`，收到当次随机标记才停止计时；不用本地回显或库 Write 返回替代远端确认。
后端构建嵌入明确标注的测试静态夹具，没有将其描述为完整前端构建或浏览器验收。

## 固定版本、安全与参数

| 组件 | 固定版本 | 许可证 / 集成判断 |
| --- | --- | --- |
| coder/websocket | v1.8.15 | ISC；复用已有 WebSocket 库 |
| xtaci/smux | v1.5.58，协议 Version=2 | MIT；双向建流、流级窗口，MVP 选用 |
| hashicorp/yamux | v0.1.2 | MPL-2.0；该 tag 发布较早，单列维护与关闭行为风险 |
| fatedier/yamux | v0.3.0 | MPL-2.0；frp 维护分支，单独对照，不混作 hashicorp 版本 |
| quic-go | v0.65.0 | MIT；当前实现使用 Reno，不是内核 BBR |
| kcp-go/v5 | v5.7.3 | MIT；可靠 UDP + TLS + smux，FEC 开关分测 |
| Hysteria | v2.13.0 | MIT；完整产品对照，BBR 与固定带宽分开 |
| frp | v0.72.0 | Apache-2.0；受管进程对照，不把内部多协议差异混作库结论 |
| OpenSSH | Windows 9.5p2 客户端 | 服务器独立限制账户；SSH host key 信任，不能冒充 TLS pin |

版本以 go.mod/go.sum、构建信息及发布 tag 固定；许可证对照固定源码，不据“有新 tag”直接推断长期维护承诺。
旧 `direct`/`kcp-fast` 数据使用 coder v1.8.12、smux v1.5.24、quic-go v0.59.1、kcp-go v5.6.72，保留作调参历史，不与 current 合并统计。

- TLS 使用测试 ECDSA P-256 证书、正常根/主机名校验及测试 mTLS，TLS 1.3；没有 skipVerify，没有开放 0-RTT。
- 测试 mTLS 共用夹具证书，不等于生产逐宿主 Ed25519 nonce、GitHub 授权、SPKI pin、轮换和撤销已经实现；这些生产任务继续待验收。
- smux 每连接接收缓冲 4 MiB、每 stream 1 MiB；yamux stream 窗口 1 MiB。QUIC stream 1 MiB、connection 4 MiB，保活 10 s、idle 60 s。
- smux 保活间隔 10 s、失活 30 s、最大 frame 32 KiB；yamux 沿用保活 30 s、连接写超时 10 s 等固定版本默认值，不声称所有 mux 的心跳与窗口完全等价。
- pool=1 共用连接；pool=2 将交互与批量分开；pool=4 追加筛选。连接数扩大总 cwnd/窗口/内存预算，不能声称各 pool 具有相同总资源。
- KCP MTU=1350，nodelay=1、interval=20 ms、fastresend=2、ACKNoDelay；nc=0/window=256 为保守对照，nc=1/window=1024 为激进对照。
- nc=1 关闭 KCP 自身拥塞窗口，不能称为 BBR；FEC 使用 10 data + 3 parity，理论满组冗余 30%，实际损耗另外测量。
- quic-go v0.59.1 与 v0.65.0 的默认发送器实际启用 Reno；构造器名称含 Cubic 不代表启用了 CUBIC，更不能把结果归因于 BBR。
- Hysteria 自动模式用其用户态 BBR；固定 5/20/50 Mbps 使用 Brutal。内核 BBR 不会改变 QUIC/KCP/Brutal 的算法。
- Hysteria 使用 TLS 服务身份、随机密码与固定目标 ACL，frp 使用 mTLS + Token；SSH 使用独立 host key。产品对照不等同于完全相同身份流程的封装开销实验。

## 网络损伤与统计口径

服务端为被测服务建立专用 relay604 network namespace、veth 与 DNAT；netem 只作用于测试 veth，不修改管理 SSH 路径或公网接口队列。
损伤在真实 WAN 之上叠加，clean 表示无人工注入，不表示物理路径零丢包。

| 档位 | 双向配置 / 实测边界 |
| --- | --- |
| clean | 自然 RTT 约 300 ms；UDP 中位数约 307 ms |
| loss1 | 每方向随机丢包 1%，每方向 20 Mbps；200 次 UDP 探测往返丢包 1.5% |
| loss3 | 每方向随机丢包 3%，每方向 5 Mbps；不是端到端仅 3% 丢包的承诺 |
| burst | gemodel 1% / 25% / 80% / 0.1%，每方向 5 Mbps |
| asym | 客户端上传 1 Mbps、下载 20 Mbps |
| rtt500 | 每方向额外 100 ms、20 ms 正态抖动、1% 丢包、20 Mbps；实测 RTT 中位数 509 ms、p95 555 ms |
| mtu1280 | 测试 veth MTU 1280；QUIC 默认参数与初始包 1200 字节分测 |

netem seeds=604/605，队列 limit=1000；未显式开启 duplicate/reorder，但 delay 抖动可能隐式重排，因此 rtt500 不是纯 RTT 单变量实验。
50/150 ms 不能在当前约 300 ms 公网链路上凭空实现；本轮不伪造这两个真实公网档位，也未穷举 0.5/5% 丢包与 50 ms 抖动。

组件每阶段一般 12 s 小回显，clean 双向各 16 MiB、弱网各 8 MiB；个别故障/MTU 样本更小，以原始命令为准。
AES-256-CTR 固定测试流不可压缩，接收方 SHA-256 确认；速度以已确认有效字节/墙钟时间计算，hash 失败不作为有效吞吐。
只将 bulk 仍活动时开始的交互样本纳入并发统计；p50/p95/p99 使用排序后 floor((n-1)*q)，失败数另列。
多数协议/档位只有一次串行筛选，Hysteria 有两轮；数十次回显的 p99 不代表总体极端尾部，不能据此建立置信区间或微小优势排名。
测试顺序轮换/反转，未在同一物理链路并行跑多个测速器；不同操作系统和时间段的波动仍是混杂因素。

## 组件筛选结果

以下 p95 为“下载期间 / 上传期间”小回显，单位 ms；吞吐为下载 / 上传有效 Mbps。
current 为 Windows CTCP 客户端、BBR 服务端；bbr-current 为同机 WSL 测试 TCP socket BBR，UDP 协议仍使用各自算法。
完整 p50/p95/p99、样本数、失败、建连耗时与原始命令在证据包中。

<!-- CORE_TABLE -->

同平台 WSS/smux 从单连接到双连接，Windows 下载 p95 740→324 ms、WSL 538→302 ms；吞吐没有同幅度跃升，主要收益是隔离批量排队。
裸 TLS 与 WSS 在同连接数下没有出现足以推翻 TCP 443 兼容价值的稳定差距；不能把一次差值当作 WSS 固定封装开销。
QUIC 双连接曾在 Windows 单次达到 22.15/20.38 Mbps，同机 WSL 另一次只有 9.87/3.50 Mbps；保留波动，不用最快一次代表稳定性能。
4 连接追加样本使用 8 MiB，下载 p95 约 809 ms，没有证明比两连接更好；不因隔离有效就无限增加物理连接。
选择 smux 还考虑 MIT 许可、固定版本维护及流级背压；本轮数据不足以证明它在所有场景显著优于 yamux。

### 弱网结果：同机 WSL，TCP 双端 BBR，pool=2

<!-- WEAK_TABLE -->

在本轮 3% 随机丢包和突发损伤下，WSS/smux 的吞吐及交互尾部优于所测激进 KCP；QUIC 的小回显通常较好，但有效吞吐较低。
MVP 优先可达性、透明业务、文件有效吞吐及集成成本，接受部分弱网档位中 QUIC 小流尾部更好的事实；没有制造综合总分。
FEC 在 loss1 带来一定吞吐收益，同时尾延迟/冗余更高；loss3 与 burst 没有稳定收益，因此不作为 MVP 默认。
保守 KCP nc=0/window=256 的 16 MiB 双向样本约 12 分钟、仅 0.36/0.38 Mbps；调为 nc=1/window=1024 后自然链路可到十几至二十多 Mbps，不能据保守默认否决全部 KCP。
Windows loss1 的 WSS/yamux 上传在约 6.3 MiB 后 stream closed，校验失败；保留失败，不伪装为零丢包成功或推断唯一根因。

### Hysteria 产品对照

<!-- HYSTERIA_TABLE -->

这证明所测 Hysteria BBR 在自然路径上有竞争力，不能用 quic-go Reno 的弱网成绩否决它。
固定 50 Mbps 没有获得接近 50 Mbps 的有效吞吐；低估为 5 Mbps 会直接限制速度。
本轮 Hysteria 为固定目标正向 TCP 转发，不具有已验证的多租户反向注册；弱网、共享瓶颈公平性及高估带宽的排队影响仍需另验，不据峰值推荐激进配置。

## 真实 WebMux 业务与故障

<!-- BUSINESS_RESULTS -->

<!-- RESOURCE_RESULTS -->

## 候选逐项处置

| 候选 | 本轮处理与 MVP 判断 |
| --- | --- |
| T1 TLS/TCP + mux | 已测 yamux/smux；保留为基线，裸 TLS 不作为默认公开接入 |
| T2 WSS + mux | 已测原版/维护分支 yamux 与 smux；选择 smux v2 + 双连接 |
| T3 HTTP/2 CONNECT | 本轮工程淘汰；仍需反向建流/控制映射，单 TCP 不消除底层丢包等待，未实测性能 |
| T4 gRPC | 本轮工程淘汰；消息/RPC 映射与现有透明 HTTP/WS 业务不匹配，未实测性能 |
| T5 原生 QUIC | 已测 v0.65.0 Reno/窗口/MTU/取消；保留研究，MVP 不优先探测 |
| T6 H3/WebTransport | 本轮工程淘汰；B 需要隧道协议，A 需要浏览器/前端适配；没有浏览器性能结论 |
| T7 KCP/TLS/smux/FEC | 已测保守/激进参数及 FEC 开关；MVP 不引入，kcptun 成品未另跑 |
| T8 Hysteria | 已测 BBR/Brutal 带宽设置；成绩好但反向注册、安全映射/进程管理另需工作 |
| T9 SSH | 限制账户、固定反向监听与 host key 机制对照；见业务结果，不能替代 TLS/SPKI 模型 |
| T10 WebRTC/TURN | 本轮工程淘汰；额外 ICE/DTLS/SCTP/TURN 成本，未修改现有 P2P 直连候选限制 |
| T11 VPN | 本轮工程淘汰；路由/TUN/权限/UDP 依赖超出单一宿主反向入口，未实测 VPN 性能 |
| T12 frp/GOST | frp 完整产品对照；GOST 未另实测，因还需相同账号/Host/撤销包装而不进入 MVP |

“工程淘汰”指不进入本次 MVP，不代表这些项目性能差或不能满足其他用途。
HTTP/2 单 TCP 的前提见 [RFC 9113](https://www.rfc-editor.org/rfc/rfc9113.html)；QUIC 原生 stream 与共享连接控制见 [RFC 9000](https://www.rfc-editor.org/rfc/rfc9000.html)。
Hysteria 配置与带宽语义见 [官方配置](https://v2.hysteria.network/docs/advanced/Full-Client-Config/)；frp 接入范围见 [官方配置](https://github.com/fatedier/frp/blob/v0.72.0/conf/frpc_full_example.toml)。

## 组件嵌入与完整产品成本

MVP 嵌入 coder/websocket、smux 和标准库 ReverseProxy，保持 CGO_ENABLED=0，减少分发二进制、子进程监督、配置/密钥文件及跨进程 readiness。
仍需实现 GitHub 数字账号映射、每账号一机、固定随机 Host、逐宿主认证、角色/代际、总配额、精确回源与撤销；成熟传输库不会自动提供这些控制面语义。
frp 可以减少通用转发开发，但必须封装身份映射/授权插件、限制任意代理和端口、监管进程/版本/凭据，并补交互/批量隔离；直接复用不是“只写登录页面”。
Hysteria 需额外实现反向通道或改造角色；SSH 需维护独立主机密钥信任和限制账户，不能静默复用 TLS pin。此工程差异是选型依据之一。

## issue 完成条件与未覆盖边界

| issue 条件 | 本轮交付 |
| --- | --- |
| 候选完成或有理由淘汰 | 上述 T1–T12 逐项列证据或工程理由；未实测项明确标注 |
| A/B 瓶颈与端到端 | 组件 B、真实 A、A+B 分列；证明两段 RTT 叠加，不宣称仅换 B 消除地理延迟 |
| B/CC/FEC/隔离/回退/A | WSS/smux v2；服务器 BBR；宿主按实际 OS；两连接；无 FEC/UDP 回退；A 保持 HTTPS/WS |
| 嵌入或完整程序 | 选择嵌入库；版本、许可证和控制面/运维差额已列 |
| 维护者确认 | 本报告提供可审阅决定，人工确认不能由测试脚本代签 |
| 更新 PR #558 制品 | proposal、design、四份 spec、tasks 同步修订；生产实现任务保持未勾选 |

未覆盖：多 ISP/蜂窝/地区与高峰切换、NAT rebinding、Wi-Fi 切换、50/150 ms 实网、5% 丢包、长时间空闲及 8–24 小时稳定性、多宿主容量/账号隔离、稳定瓶颈下重复公平性。
未完成生产 GitHub/Ed25519 重放/SPKI pin/换钥/注销撤销，以及完整浏览器聊天、语音、P2P/推送 UI；这些不因原型的 Token/mTLS 检查通过而被勾选。
服务端早期 CPU/RSS 监控漏匹配改名后的实验进程，后段已修复；不能用残缺采样给所有候选建立精确服务端资源排名。
WSL 持续监控文件为空，未取得宿主历史资源曲线；结束时另取进程生命周期 VmHWM/CPU 快照，不将它冒充每次试验的资源序列。
AF_PACKET 仅保存端口聚合计数，不保存包正文；受 GSO/GRO 和采样边界影响，IP 字节不是精确物理链路计费，也不能直接拆出 TCP/QUIC 重传与 FEC 字节。
原型手工启动连接器不等于已实现生产自动重连；性能筛选也不等于提供容量或内存上限保证。
原型为 pool=1 对照允许 bulk 使用交互连接；正式双角色方案规定 bulk 离线返回 503，此降级策略尚未生产实现或验收。
100 MiB 文件下载客户端为了校验会读取完整响应，该项 RSS 不作为隧道缓冲上限证据；1 GiB 转发夹具则逐块计算哈希，不整包缓存。

## 证据与复现

<!-- EVIDENCE -->

证据包通过允许清单生成，仅包含源码、版本锁定、无正文统计和复现说明；不含证书私钥、Token、Cookie、SSH 私钥、生成后的凭据配置或管理命令队列。
只在独立测试实例运行；按说明生成新的随机凭据。服务器管理命令使用 Windows OpenSSH，测量流量始终直连。
验证报告/规划为研究交付，不修改用户可见产品行为，本轮无已实现 User Story 变更。
