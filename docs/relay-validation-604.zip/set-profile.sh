set -eu
profile=${1:-clean}
tc qdisc del dev r604-host root 2>/dev/null || true
ip netns exec relay604 tc qdisc del dev r604-peer root 2>/dev/null || true
ip link set r604-host mtu 1500
ip netns exec relay604 ip link set r604-peer mtu 1500
case "$profile" in
  clean) ;;
  rate20) tc qdisc add dev r604-host root netem limit 1000 rate 20mbit
    ip netns exec relay604 tc qdisc add dev r604-peer root netem limit 1000 rate 20mbit ;;
  loss1) tc qdisc add dev r604-host root netem limit 1000 loss random 1% rate 20mbit seed 604
    ip netns exec relay604 tc qdisc add dev r604-peer root netem limit 1000 loss random 1% rate 20mbit seed 605 ;;
  loss3) tc qdisc add dev r604-host root netem limit 1000 loss random 3% rate 5mbit seed 604
    ip netns exec relay604 tc qdisc add dev r604-peer root netem limit 1000 loss random 3% rate 5mbit seed 605 ;;
  burst) tc qdisc add dev r604-host root netem limit 1000 loss gemodel 1% 25% 80% 0.1% rate 5mbit seed 604
    ip netns exec relay604 tc qdisc add dev r604-peer root netem limit 1000 loss gemodel 1% 25% 80% 0.1% rate 5mbit seed 605 ;;
  asym) tc qdisc add dev r604-host root netem limit 1000 rate 1mbit
    ip netns exec relay604 tc qdisc add dev r604-peer root netem limit 1000 rate 20mbit ;;
  rtt500) tc qdisc add dev r604-host root netem limit 1000 delay 100ms 20ms distribution normal loss random 1% rate 20mbit seed 604
    ip netns exec relay604 tc qdisc add dev r604-peer root netem limit 1000 delay 100ms 20ms distribution normal loss random 1% rate 20mbit seed 605 ;;
  mtu1280) ip link set r604-host mtu 1280
    ip netns exec relay604 ip link set r604-peer mtu 1280 ;;
  *) echo "unknown profile" >&2; exit 1 ;;
esac
date -u
echo "PROFILE $profile"
tc -s qdisc show dev r604-host
ip netns exec relay604 tc -s qdisc show dev r604-peer
