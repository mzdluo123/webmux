package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

type httpCall func(string, string, io.Reader, string, string, string) (int, []byte, error)

func forwardBusiness(hc *http.Client, request httpCall, origin, token string, echoPTY func(string, time.Duration)) ([]map[string]any, map[string]any) {
	checks := map[string]any{}
	var out []map[string]any
	// This port belongs to the isolated test fixture; clear a prior interrupted run.
	request("DELETE", "/api/forwards/17683", nil, "", token, origin)
	status, b, e := request("POST", "/api/forwards", strings.NewReader(`{"port":17683,"label":"relay604-stream-fixture","options":{"prefix":"strip","rewriteHost":false,"rewriteOrigin":false,"forwardedHeaders":false,"rewriteResponse":false}}`), "application/json", token, origin)
	checks["forward_registration_status"] = status
	checks["forward_registered"] = e == nil && status == 201
	if e != nil || status != 201 {
		return out, checks
	}
	defer request("DELETE", "/api/forwards/17683", nil, "", token, origin)
	var f struct {
		Path string `json:"path"`
	}
	json.Unmarshal(b, &f)
	if !strings.HasPrefix(f.Path, "/forward/17683/") {
		f.Path = "/forward/17683/"
	}
	status, b, e = request("POST", "/api/forwards/tickets", strings.NewReader("{}"), "application/json", token, origin)
	if e != nil || status != 201 {
		checks["forward_ticket_issued"] = false
		return out, checks
	}
	var ticket struct {
		Code string `json:"code"`
	}
	json.Unmarshal(b, &ticket)
	form := url.Values{"code": {ticket.Code}, "next": {f.Path}}.Encode()
	redeemer := *hc
	redeemer.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	redeem := func() (int, error) {
		req, _ := http.NewRequest("POST", origin+"/forward/_auth", strings.NewReader(form))
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		req.Header.Set("Origin", origin)
		resp, e := redeemer.Do(req)
		if e != nil {
			return 0, e
		}
		defer resp.Body.Close()
		io.Copy(io.Discard, resp.Body)
		return resp.StatusCode, nil
	}
	status, e = redeem()
	checks["forward_ticket_redeemed"] = e == nil && status == 303
	if e != nil || status != 303 {
		return out, checks
	}
	status, e = redeem()
	checks["forward_ticket_replay_rejected"] = e == nil && status == 401
	for _, dir := range []string{"upload", "download"} {
		activeBulk.Store(1)
		done := make(chan map[string]any, 1)
		go func(dir string) {
			defer activeBulk.Store(0)
			start := time.Now()
			h := sha256.New()
			method := "GET"
			var body io.Reader
			if dir == "upload" {
				method = "PUT"
				body = io.TeeReader(io.LimitReader(payload(), *forwardBytes), h)
			}
			req, _ := http.NewRequestWithContext(context.Background(), method, origin+f.Path+"bulk/"+dir+"?bytes="+strconv.FormatInt(*forwardBytes, 10), body)
			req.Header.Set("Origin", origin)
			req.Header.Set("Content-Type", "application/octet-stream")
			req.Header.Set("X-Forwarded-For", "198.51.100.60")
			r := map[string]any{"direction": "forward-" + dir, "requested_bytes": *forwardBytes, "start": start.UTC().Format(time.RFC3339Nano)}
			resp, e := hc.Do(req)
			if e != nil {
				r["error"] = e.Error()
				r["hash_ok"] = false
				done <- r
				return
			}
			defer resp.Body.Close()
			r["status"] = resp.StatusCode
			r["forward_cookie_stripped"] = resp.Header.Get("X-Fixture-Forward-Cookie-Present") == "false"
			r["authorization_absent"] = resp.Header.Get("X-Fixture-Authorization-Present") == "false"
			r["spoofed_xff_stripped"] = resp.Header.Get("X-Fixture-XFF-Present") == "false"
			if dir == "download" {
				n, e := io.Copy(h, resp.Body)
				r["bytes"] = n
				r["trailer_present"] = resp.Trailer.Get("X-Checksum-Sha256") != ""
				r["hash_ok"] = e == nil && n == *forwardBytes && hex.EncodeToString(h.Sum(nil)) == resp.Trailer.Get("X-Checksum-Sha256")
				if e != nil {
					r["error"] = e.Error()
				}
			} else {
				b, e := io.ReadAll(resp.Body)
				var ack struct {
					Bytes int64  `json:"bytes"`
					SHA   string `json:"sha256"`
				}
				json.Unmarshal(b, &ack)
				r["bytes"] = ack.Bytes
				r["hash_ok"] = e == nil && ack.Bytes == *forwardBytes && ack.SHA == hex.EncodeToString(h.Sum(nil))
				if e != nil {
					r["error"] = e.Error()
				}
			}
			r["seconds"] = time.Since(start).Seconds()
			done <- r
		}(dir)
		echoPTY("forward-"+dir, time.Duration(*seconds)*time.Second)
		out = append(out, <-done)
	}
	return out, checks
}
