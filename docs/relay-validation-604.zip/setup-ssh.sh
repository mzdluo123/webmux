set -eu
cd /root/relay-validation
id relay604 >/dev/null 2>&1 || useradd -M -s /usr/sbin/nologin relay604
usermod -p '*' relay604
test -f ssh-host-key || ssh-keygen -q -t ed25519 -N '' -f ssh-host-key
printf 'restrict,port-forwarding,permitlisten="127.0.0.1:19011",permitlisten="127.0.0.1:19012" ' > /etc/ssh/relay604-authorized_keys
cat ssh-client-key.pub >> /etc/ssh/relay604-authorized_keys
chmod 644 /etc/ssh/relay604-authorized_keys
cat > sshd-test.conf <<'EOF'
Port 19004
ListenAddress 0.0.0.0
HostKey /root/relay-validation/ssh-host-key
PidFile /root/relay-validation/sshd-test.pid
AuthorizedKeysFile /etc/ssh/relay604-authorized_keys
AllowUsers relay604
AuthenticationMethods publickey
PubkeyAuthentication yes
PasswordAuthentication no
KbdInteractiveAuthentication no
UsePAM no
PermitRootLogin no
AllowTcpForwarding remote
AllowAgentForwarding no
X11Forwarding no
PermitTunnel no
GatewayPorts no
PermitListen 127.0.0.1:19011 127.0.0.1:19012
MaxSessions 0
ClientAliveInterval 15
ClientAliveCountMax 2
LogLevel ERROR
EOF
/usr/sbin/sshd -t -f /root/relay-validation/sshd-test.conf
/usr/sbin/sshd -f /root/relay-validation/sshd-test.conf -E /root/relay-validation/sshd-test.log
cat ssh-host-key.pub
/usr/sbin/sshd -V 2>&1
