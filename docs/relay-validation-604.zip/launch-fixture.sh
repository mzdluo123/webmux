#!/bin/bash
set -eu
cd /tmp/webmux-relay-604
chmod 700 httpfixture
nohup ./httpfixture > httpfixture.log 2>&1 < /dev/null &
echo $! > httpfixture.pid
sleep 1
kill -0 "$(cat httpfixture.pid)"
head -2 httpfixture.log
