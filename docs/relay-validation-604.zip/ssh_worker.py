"""Persistent Windows OpenSSH session for administration; benchmark sockets are separate."""
import subprocess,pathlib,time,threading,queue,base64,uuid,textwrap
root=pathlib.Path(__file__).resolve().parent
jobs=root/'ssh-jobs';jobs.mkdir(exist_ok=True)
while True:
    p=subprocess.Popen([r'C:\Windows\System32\OpenSSH\ssh.exe','-T','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3','root@172.233.136.221','bash --noprofile --norc'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,bufsize=0)
    q=queue.Queue()
    def reader():
        for line in p.stdout:q.put(line.decode('utf-8',errors='replace'))
        q.put(None)
    threading.Thread(target=reader,daemon=True).start()
    token='READY_'+uuid.uuid4().hex
    try:
        p.stdin.write(f'echo {token}\n'.encode());p.stdin.flush()
        while True:
            line=q.get(timeout=20)
            if line is None:raise ConnectionError('SSH closed before ready')
            if token in line:break
        print('Windows OpenSSH persistent session ready',flush=True)
        (jobs/'ready').write_text(str(time.time()))
        while p.poll() is None:
            pending=sorted(jobs.glob('*.sh'))
            if not pending:time.sleep(.2);continue
            job=pending[0];payload=base64.b64encode(job.read_bytes()).decode()
            marker='END_'+uuid.uuid4().hex
            delimiter='DATA_'+uuid.uuid4().hex
            p.stdin.write((f"base64 -d > /root/relay-validation/admin-job.sh <<'{delimiter}'\n"+'\n'.join(payload[i:i+76] for i in range(0,len(payload),76))+f"\n{delimiter}\nbash /root/relay-validation/admin-job.sh; printf '\\n{marker}:%s\\n' $?\n").encode());p.stdin.flush()
            lines=[]
            while True:
                line=q.get(timeout=300)
                if line is None:raise ConnectionError('SSH closed during job')
                if marker+':' in line:
                    code=line.split(marker+':',1)[1].strip();break
                lines.append(line)
            job.with_suffix('.out').write_text(''.join(lines),encoding='utf-8')
            job.with_suffix('.exit').write_text(code)
            job.rename(job.with_suffix('.done'))
            print(job.name,'exit='+code,flush=True)
    except Exception as e:
        print(type(e).__name__,str(e),flush=True)
    finally:
        p.kill()
        (jobs/'ready').unlink(missing_ok=True)
    time.sleep(3)
