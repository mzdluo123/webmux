// Test-only TLS termination for frp's documented WSS reverse-proxy topology.
package main

import (
	"crypto/tls"
	"crypto/x509"
	"io"
	"log"
	"net"
	"os"
)

func main() {
	cert, err := tls.LoadX509KeyPair("cert.pem", "key.pem")
	if err != nil {
		log.Fatal(err)
	}
	pem, err := os.ReadFile("cert.pem")
	if err != nil {
		log.Fatal(err)
	}
	ca := x509.NewCertPool()
	if !ca.AppendCertsFromPEM(pem) {
		log.Fatal("invalid test CA")
	}
	l, err := tls.Listen("tcp", ":19005", &tls.Config{MinVersion: tls.VersionTLS13, Certificates: []tls.Certificate{cert}, ClientCAs: ca, ClientAuth: tls.RequireAndVerifyClientCert})
	if err != nil {
		log.Fatal(err)
	}
	for {
		c, err := l.Accept()
		if err != nil {
			log.Fatal(err)
		}
		go func(c net.Conn) {
			defer c.Close()
			d, err := net.Dial("tcp", "127.0.0.1:19006")
			if err != nil {
				return
			}
			defer d.Close()
			done := make(chan struct{}, 2)
			go func() { io.Copy(d, c); done <- struct{}{} }()
			go func() { io.Copy(c, d); done <- struct{}{} }()
			<-done
			c.Close()
			d.Close()
			<-done
		}(c)
	}
}
