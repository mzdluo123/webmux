// Standalone authenticated test gateway for the frp/OpenSSH sidecar comparisons.
package main

import (
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"strings"
	"time"
)

func main() {
	port := flag.Int("port", 18455, "public test port")
	target := flag.String("target", "127.0.0.1:19010", "fixed loopback sidecar target")
	bulk := flag.String("bulk-target", "", "optional isolated bulk target")
	flag.Parse()
	cert, e := tls.LoadX509KeyPair("cert.pem", "key.pem")
	if e != nil {
		log.Fatal(e)
	}
	pem, e := os.ReadFile("cert.pem")
	if e != nil {
		log.Fatal(e)
	}
	ca := x509.NewCertPool()
	ca.AppendCertsFromPEM(pem)
	makeProxy := func(addr string) *httputil.ReverseProxy {
		host, _, e := net.SplitHostPort(addr)
		if e != nil || net.ParseIP(host) == nil || !net.ParseIP(host).IsLoopback() {
			log.Fatal("test target must be a fixed numeric loopback address")
		}
		u, _ := url.Parse("http://" + addr)
		return &httputil.ReverseProxy{Rewrite: func(p *httputil.ProxyRequest) { p.SetURL(u); p.Out.Host = p.In.Host; p.SetXForwarded() }, Transport: &http.Transport{Proxy: nil, MaxIdleConnsPerHost: 32, ResponseHeaderTimeout: 30 * time.Second}, FlushInterval: -1}
	}
	mainProxy := makeProxy(*target)
	bulkProxy := mainProxy
	if *bulk != "" {
		bulkProxy = makeProxy(*bulk)
	}
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != fmt.Sprint("172.233.136.221:", *port) {
			http.Error(w, "unknown test host", 421)
			return
		}
		path := r.URL.Path
		if strings.Contains(path, "upload") || strings.Contains(path, "/bulk") || (strings.Contains(path, "/code/") && (strings.HasSuffix(path, "/node") || strings.HasSuffix(path, "/archive") || strings.HasSuffix(path, "/raw"))) {
			bulkProxy.ServeHTTP(w, r)
		} else {
			mainProxy.ServeHTTP(w, r)
		}
	})
	server := &http.Server{Addr: fmt.Sprint(":", *port), Handler: handler, ReadHeaderTimeout: 10 * time.Second, TLSConfig: &tls.Config{MinVersion: tls.VersionTLS13, Certificates: []tls.Certificate{cert}, ClientCAs: ca, ClientAuth: tls.RequireAndVerifyClientCert, NextProtos: []string{"http/1.1"}}}
	log.Fatal(server.ListenAndServeTLS("cert.pem", "key.pem"))
}
