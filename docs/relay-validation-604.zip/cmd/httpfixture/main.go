// A loopback-only streaming HTTP target for WebMux /forward/* validation.
package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strconv"
	"strings"
)

type zeros struct{}

func (zeros) Read(p []byte) (int, error) { clear(p); return len(p), nil }
func payload() io.Reader {
	b, _ := aes.NewCipher(make([]byte, 32))
	return &cipher.StreamReader{S: cipher.NewCTR(b, make([]byte, 16)), R: zeros{}}
}
func main() {
	h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n, e := strconv.ParseInt(r.URL.Query().Get("bytes"), 10, 64)
		if e != nil || n < 0 || n > 2*1024*1024*1024 {
			http.Error(w, "invalid test size", 400)
			return
		}
		auth := r.Header.Get("Authorization") != ""
		cookie := strings.Contains(r.Header.Get("Cookie"), "webmux_forward=")
		xff := r.Header.Get("X-Forwarded-For") != ""
		w.Header().Set("X-Fixture-Authorization-Present", strconv.FormatBool(auth))
		w.Header().Set("X-Fixture-Forward-Cookie-Present", strconv.FormatBool(cookie))
		w.Header().Set("X-Fixture-XFF-Present", strconv.FormatBool(xff))
		hash := sha256.New()
		if strings.HasSuffix(r.URL.Path, "/bulk/download") && r.Method == "GET" {
			w.Header().Set("Content-Type", "application/octet-stream")
			w.Header().Set("Trailer", "X-Checksum-Sha256")
			w.WriteHeader(200)
			written, e := io.CopyN(io.MultiWriter(w, hash), payload(), n)
			if e == nil && written == n {
				w.Header().Set("X-Checksum-Sha256", hex.EncodeToString(hash.Sum(nil)))
			}
			return
		}
		if strings.HasSuffix(r.URL.Path, "/bulk/upload") && r.Method == "PUT" {
			got, e := io.CopyN(hash, r.Body, n)
			if e != nil {
				http.Error(w, "incomplete test body", 400)
				return
			}
			var extra [1]byte
			count, err := r.Body.Read(extra[:])
			if count != 0 || err != io.EOF {
				http.Error(w, "extra test body", 400)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]any{"bytes": got, "sha256": hex.EncodeToString(hash.Sum(nil)), "authorization_present": auth, "forward_cookie_present": cookie, "xff_present": xff})
			return
		}
		http.NotFound(w, r)
	})
	fmt.Println("streaming fixture ready on loopback 17683")
	log.Fatal(http.ListenAndServe("127.0.0.1:17683", h))
}
