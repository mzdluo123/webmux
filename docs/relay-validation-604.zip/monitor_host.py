import pathlib,time,json,os
root=pathlib.Path('/tmp/webmux-relay-604')
while True:
    rows=[]
    for label in ['webmux','host','frpc','httpfixture','ssh']:
        try:
            pid=int((root/(label+'.pid')).read_text());d=pathlib.Path('/proc')/str(pid);stat=(d/'stat').read_text().split();rows.append({'label':label,'pid':pid,'cpu_ticks':int(stat[13])+int(stat[14]),'rss':int(stat[23])*os.sysconf('SC_PAGE_SIZE')})
        except (OSError,ValueError):pass
    print(json.dumps({'time':time.time(),'clock_ticks':os.sysconf('SC_CLK_TCK'),'processes':rows}),flush=True)
    time.sleep(1)
