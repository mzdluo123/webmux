module relay-validation

go 1.26.0

require (
	github.com/coder/websocket v1.8.15
	github.com/fatedier/yamux v0.3.0
	github.com/hashicorp/yamux v0.1.2
	github.com/quic-go/quic-go v0.65.0
	github.com/xtaci/kcp-go/v5 v5.7.3
	github.com/xtaci/smux v1.5.58
	golang.org/x/sys v0.49.0
)

require (
	github.com/klauspost/cpuid/v2 v2.4.1 // indirect
	github.com/klauspost/reedsolomon v1.14.2 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/tjfoc/gmsm v1.4.1 // indirect
	golang.org/x/crypto v0.58.0 // indirect
	golang.org/x/net v0.61.0 // indirect
	golang.org/x/time v0.16.0 // indirect
)
