from suite_helpers import *
import traceback,psutil
while not (ROOT/'results/business-forward-1GiB.meta.json').exists():time.sleep(2)
for i in range(20):
 r=subprocess.run([r'C:\Windows\System32\OpenSSH\scp.exe','tlsterminator-linux','frps-wss.toml','root@172.233.136.221:/root/relay-validation/'],env=ENV)
 if r.returncode==0:break
 time.sleep(2)
else:raise RuntimeError('WSS setup scp failed')
print(remote('''cd /root/relay-validation
chmod 700 tlsterminator-linux
chmod 600 frps-wss.toml
nohup ./frp_0.72.0_linux_amd64/frps -c frps-wss.toml > frps-wss.log 2>&1 < /dev/null &
echo $! > frps-wss.pid
nohup ./tlsterminator-linux > tlsterminator.log 2>&1 < /dev/null &
echo $! > tlsterminator.pid
sleep 1
ss -lnt sport = :19005''','start-frp-wss'),flush=True)
subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','-c','cp /mnt/d/604/relay-validation/frpc-wss.toml /tmp/webmux-relay-604/frpc-wss.toml; chmod 600 /tmp/webmux-relay-604/frpc-wss.toml'],env=ENV,check=True)
status={}
for protocol in ['wss','quic','kcp']:
 try:
  subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','/mnt/d/604/relay-validation/launch-frpc.sh',protocol],env=ENV,check=True)
  business('frp-'+protocol,port=18455,size=8*1024*1024,seconds=10)
  status[protocol]='completed'
 except Exception as ex:status[protocol]=str(ex);print(protocol,ex,flush=True)
subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','-c','cd /tmp/webmux-relay-604; test ! -s frpc.pid || kill "$(cat frpc.pid)" 2>/dev/null || true'],env=ENV)
sshbase=[r'C:\Windows\System32\OpenSSH\ssh.exe','-N','-T','-p','19004','-i',str(ROOT/'ssh-client-key'),'-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(ROOT/'ssh-known-hosts'),'-o','ExitOnForwardFailure=yes','-o','ProxyCommand=none','-o','ProxyJump=none','-o','ServerAliveInterval=10','-o','ServerAliveCountMax=3']
processes=[]
try:
 for listen in ['19011','19012']:
  p=subprocess.Popen(sshbase+['-R',f'127.0.0.1:{listen}:127.0.0.1:17681','relay604@172.233.136.221'],env=ENV,stdout=subprocess.DEVNULL,stderr=(ROOT/'results'/f'ssh-{listen}.log').open('w'));processes.append(p);time.sleep(3)
  if p.poll() is not None:raise RuntimeError('SSH forward failed')
 business('ssh-p2',port=18456,size=8*1024*1024,seconds=10)
 status['ssh']='completed'
except Exception as ex:status['ssh']=str(ex);print(ex,flush=True)
finally:
 for p in processes:p.terminate()
(ROOT/'results/sidecar-status.json').write_text(json.dumps(status))
# Shared 20 Mbps bottleneck: one ordinary TLS/TCP receive flow alongside each candidate.
profile('rate20')
for candidate in ['baseline','wss-smux','kcp','hysteria-bbr','hysteria-20mbps']:
 print('FAIRNESS',candidate,flush=True)
 hy=None
 try:
  if candidate.startswith('hysteria'):
   hy=subprocess.Popen([str(ROOT/'tools/hysteria.exe'),'client','-c',candidate+'.yaml'],cwd=ROOT,env=ENV,stdout=(ROOT/'results'/f'fairness-{candidate}-sidecar.log').open('w'),stderr=subprocess.STDOUT);time.sleep(3)
  with (ROOT/'results'/f'fairness-{candidate}-neighbor.json').open('w') as f,(ROOT/'results'/f'fairness-{candidate}-neighbor.log').open('w') as err:
   neighbor=subprocess.Popen([str(ROOT/'relay-business-v2.exe'),'-mode','compete','-proto','tls-smux','-seconds','60'],cwd=ROOT,env=ENV,stdout=f,stderr=err)
   time.sleep(3)
   if candidate!='baseline':
    if hy:matrix('fairness-'+candidate,'sidecar',pools='1',size=16*1024*1024,seconds=8,addr='127.0.0.1',port=19443,observe_pid=hy.pid)
    else:matrix('fairness-'+candidate,candidate,pools='2',size=16*1024*1024,seconds=8,tuned=True)
   neighbor.wait(timeout=90)
 finally:
  if hy:hy.terminate();hy.wait(timeout=10)
profile('clean')
(ROOT/'results/supplement-done.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
