package main

import (
	"bytes"
	"encoding/json"
	"io"
	"log"
	"os"
	"sync/atomic"
	"time"
)

func compete() {
	s, e := dial(*proto)
	if e != nil {
		log.Fatal(e)
	}
	defer s.Close()
	c, e := s.Open()
	if e != nil {
		log.Fatal(e)
	}
	defer c.Close()
	header(c, 2, 1024*1024*1024)
	start := time.Now()
	c.SetDeadline(start.Add(time.Duration(*seconds) * time.Second))
	var total atomic.Int64
	done := make(chan struct{})
	type tick struct {
		At    string `json:"at"`
		Bytes int64  `json:"bytes"`
	}
	var ticks []tick
	tickDone := make(chan struct{})
	go func() {
		defer close(tickDone)
		ticker := time.NewTicker(time.Second)
		defer ticker.Stop()
		var previous int64
		for {
			select {
			case now := <-ticker.C:
				n := total.Load()
				ticks = append(ticks, tick{now.UTC().Format(time.RFC3339Nano), n - previous})
				previous = n
			case <-done:
				return
			}
		}
	}()
	expected := payload()
	good := true
	buf := make([]byte, 32768)
	want := make([]byte, len(buf))
	for {
		n, err := c.Read(buf)
		if n > 0 {
			if _, e := io.ReadFull(expected, want[:n]); e != nil || !bytes.Equal(buf[:n], want[:n]) {
				good = false
			}
			total.Add(int64(n))
		}
		if err != nil {
			break
		}
	}
	close(done)
	<-tickDone
	elapsed := time.Since(start).Seconds()
	json.NewEncoder(os.Stdout).Encode(map[string]any{"proto": *proto, "start": start.UTC().Format(time.RFC3339Nano), "seconds": elapsed, "received_bytes": total.Load(), "mbps": float64(total.Load()) * 8 / elapsed / 1e6, "prefix_verified": good, "intervals": ticks})
}
