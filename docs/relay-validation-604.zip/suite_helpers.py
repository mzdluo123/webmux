import pathlib,time,subprocess,os,json
ROOT=pathlib.Path(__file__).resolve().parent
ENV={k:v for k,v in os.environ.items() if 'proxy' not in k.lower()};ENV.update(NO_PROXY='*',no_proxy='*')
def remote(script,name):
    job=ROOT/'ssh-jobs'/f'{time.time_ns()}-{name}.sh';tmp=job.with_suffix('.tmp');tmp.write_text(script+'\n',encoding='utf-8',newline='\n');tmp.replace(job)
    deadline=time.monotonic()+180
    while not job.with_suffix('.exit').exists():
        if time.monotonic()>deadline:raise TimeoutError(name)
        time.sleep(.2)
    out=job.with_suffix('.out').read_text();code=job.with_suffix('.exit').read_text().strip()
    if code!='0':raise RuntimeError(name+' '+code+' '+out)
    return out
def profile(name):
    out=remote(f'cd /root/relay-validation\nbash set-profile.sh {name}',f'profile-{name}')
    (ROOT/'results'/f'profile-{name}-{time.time_ns()}.txt').write_text(out)
    time.sleep(2)
def matrix(label,protocols,pools='2',rounds=1,size=8*1024*1024,seconds=12,addr=None,port=None,tuned=False,observe_pid=None,wsl=False):
    cmd=['python',str(ROOT/'run_matrix.py'),'--label',label,'--rounds',str(rounds),'--seconds',str(seconds),'--bytes',str(size),'--protocols',protocols,'--pools',pools]
    if addr:cmd+=['--addr',addr]
    if port:cmd+=['--port',str(port)]
    if tuned:cmd+=['--binary','relay-current.exe','--kcp-no-cc','1','--kcp-window','1024']
    if observe_pid:cmd+=['--observe-pid',str(observe_pid)]
    if wsl:cmd+=['--wsl']
    subprocess.run(cmd,cwd=ROOT,check=True,env=ENV)
def probe(label):
    with (ROOT/'results'/f'probe-{label}.json').open('w') as f:subprocess.run(['python','udp_probe.py'],cwd=ROOT,env=ENV,stdout=f,check=True)
def business(label,port=18452,size=100*1024*1024,seconds=30):
    start=time.time()
    cmd=[str(ROOT/'relay-business-v2.exe'),'-mode','business','-port',str(port),'-bytes',str(size),'-seconds',str(seconds),'-echo-entire-bulk']
    with (ROOT/'results'/f'business-{label}.json').open('w') as f,(ROOT/'results'/f'business-{label}.log').open('w') as err:
        result=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=f,stderr=err,timeout=1500)
    (ROOT/'results'/f'business-{label}.meta.json').write_text(json.dumps({'start':start,'seconds':time.time()-start,'command':cmd,'exit_code':result.returncode,'proxy_disabled':True}))
    if result.returncode:raise RuntimeError('business failed '+label)
