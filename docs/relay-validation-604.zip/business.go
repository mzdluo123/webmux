package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"net"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"os/exec"
	"sort"
	"strings"
	"time"

	"github.com/coder/websocket"
)

func business() {
	origin := fmt.Sprintf("https://%s:%d", *addr, *portOverride)
	if *portOverride == 0 {
		origin = "https://" + *addr + ":18451"
	}
	if *endpoint != "" {
		origin = *endpoint
	}
	b, e := os.ReadFile("secrets.json")
	if e != nil {
		log.Fatal(e)
	}
	var secrets map[string]string
	json.Unmarshal(b, &secrets)
	cfg := credentials(false)
	cfg.NextProtos = []string{"http/1.1"}
	tr := &http.Transport{Proxy: nil, TLSClientConfig: cfg, MaxIdleConnsPerHost: 8, DialContext: (&net.Dialer{Timeout: 10 * time.Second, Control: tcpControl}).DialContext}
	jar, _ := cookiejar.New(nil)
	hc := &http.Client{Transport: tr, Timeout: 30 * time.Minute, Jar: jar}
	request := func(method, path string, body io.Reader, ctype, token, ori string) (int, []byte, error) {
		r, e := http.NewRequest(method, origin+path, body)
		if e != nil {
			return 0, nil, e
		}
		if token != "" {
			r.Header.Set("Authorization", "Bearer "+token)
		}
		if ori != "" {
			r.Header.Set("Origin", ori)
		}
		if ctype != "" {
			r.Header.Set("Content-Type", ctype)
		}
		resp, e := hc.Do(r)
		if e != nil {
			return 0, nil, e
		}
		defer resp.Body.Close()
		b, e := io.ReadAll(resp.Body)
		return resp.StatusCode, b, e
	}
	var checks = map[string]any{}
	status, _, e := request("GET", "/api/sessions", nil, "", "wrong", origin)
	checks["wrong_token_rejected"] = e == nil && status == 401
	status, _, e = request("POST", "/api/sessions", strings.NewReader("{}"), "application/json", secrets["webmux"], "https://wrong-origin.invalid")
	checks["wrong_origin_rejected"] = e == nil && status == 403
	createPayload := `{"cmd":["/bin/sh","-c","stty -echo -icanon min 1 time 0; exec cat"],"cwd":"/tmp","name":"relay-604-fixture","cols":80,"rows":24}`
	start := time.Now()
	status, b, e = request("POST", "/api/sessions", strings.NewReader(createPayload), "application/json", secrets["webmux"], origin)
	if e != nil || status != 201 {
		log.Fatalf("create session status=%d error=%v", status, e)
	}
	var created struct {
		Session struct {
			ID string `json:"id"`
		} `json:"session"`
	}
	if e = json.Unmarshal(b, &created); e != nil {
		log.Fatal(e)
	}
	id := created.Session.ID
	defer request("DELETE", "/api/sessions/"+id, nil, "", secrets["webmux"], origin)
	checks["create_session_ms"] = float64(time.Since(start).Microseconds()) / 1000
	open := func(query string) (*websocket.Conn, error) {
		headers := http.Header{}
		headers.Set("Authorization", "Bearer "+secrets["webmux"])
		headers.Set("Origin", origin)
		wsbase := strings.Replace(strings.Replace(origin, "https://", "wss://", 1), "http://", "ws://", 1)
		c, _, e := websocket.Dial(context.Background(), wsbase+"/ws/s/"+id+"?client=relay604client&label=benchmark"+query, &websocket.DialOptions{HTTPClient: hc, HTTPHeader: headers})
		return c, e
	}
	c, e := open("")
	if e != nil {
		log.Fatal(e)
	}
	defer c.CloseNow()
	c.SetReadLimit(8 * 1024 * 1024)
	type position struct {
		Generation string `json:"generation"`
		End        uint64 `json:"end"`
		Start      uint64 `json:"start"`
		Mode       string `json:"mode"`
	}
	var pos position
	var received uint64
	// Wait for initial position and control frames before sending test input.
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	for {
		_, p, e := c.Read(ctx)
		if e != nil {
			log.Fatal(e)
		}
		if len(p) > 0 && p[0] == 4 {
			json.Unmarshal(p[1:], &pos)
			received = pos.Start
		}
		if len(p) > 0 && (p[0] == 0 || p[0] == 1) {
			received += uint64(len(p) - 1)
		}
		if len(p) > 0 && p[0] == 2 {
			break
		}
	}
	cancel()
	time.Sleep(300 * time.Millisecond)
	var samples []sample
	var transfers []map[string]any
	echoPTY := func(phase string, duration time.Duration) {
		end := time.Now().Add(duration)
		for time.Now().Before(end) || (*echoBulkAll && phase != "idle" && activeBulk.Load() > 0) {
			marker := []byte(fmt.Sprintf("r604-%016x", time.Now().UnixNano()))
			start := time.Now()
			wasActive := activeBulk.Load() > 0
			ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
			e := c.Write(ctx, websocket.MessageBinary, append([]byte{0}, marker...))
			var output []byte
			for e == nil && !bytes.Contains(output, marker) {
				_, p, err := c.Read(ctx)
				if err != nil {
					e = err
					break
				}
				if len(p) > 0 && (p[0] == 0 || p[0] == 1) {
					output = append(output, p[1:]...)
					received += uint64(len(p) - 1)
				}
			}
			cancel()
			samples = append(samples, sample{phase, float64(time.Since(start).Microseconds()) / 1000, e == nil && bytes.Contains(output, marker), start.UTC().Format(time.RFC3339Nano), wasActive})
			if e != nil {
				break
			}
			time.Sleep(50 * time.Millisecond)
		}
	}
	echoPTY("idle", time.Duration(*seconds)*time.Second)
	uploadDone := make(chan map[string]any, 1)
	activeBulk.Store(1)
	go func() {
		defer activeBulk.Store(0)
		pr, pw := io.Pipe()
		mw := multipart.NewWriter(pw)
		contentType := mw.FormDataContentType()
		h := sha256.New()
		go func() {
			part, e := mw.CreateFormFile("file", "relay604.bin")
			if e == nil {
				_, e = io.CopyN(io.MultiWriter(part, h), payload(), *size)
			}
			mw.Close()
			pw.CloseWithError(e)
		}()
		start := time.Now()
		status, b, e := request("POST", "/api/sessions/"+id+"/upload", pr, contentType, secrets["webmux"], origin)
		r := map[string]any{"direction": "upload", "status": status, "seconds": time.Since(start).Seconds(), "bytes": *size}
		if e != nil {
			r["error"] = e.Error()
		}
		var uploaded struct {
			Path string `json:"path"`
		}
		json.Unmarshal(b, &uploaded)
		r["path"] = uploaded.Path
		r["hash"] = hex.EncodeToString(h.Sum(nil))
		uploadDone <- r
	}()
	echoPTY("upload", time.Duration(*seconds)*time.Second)
	up := <-uploadDone
	transfers = append(transfers, up)
	if path, ok := up["path"].(string); ok && path != "" {
		// Attachment previews are capped at 10 MiB. File downloads use the
		// code-view artifacts root and its streaming node endpoint (100 MiB).
		status, b, e = request("GET", "/api/sessions/"+id+"/code/context?root=artifacts", nil, "", secrets["webmux"], origin)
		var contextInfo struct {
			ID string `json:"contextId"`
		}
		if e == nil && status == 200 {
			json.Unmarshal(b, &contextInfo)
		}
		var node struct {
			ID string `json:"nodeId"`
		}
		if contextInfo.ID != "" {
			status, b, e = request("GET", "/api/sessions/"+id+"/code/locate?contextId="+url.QueryEscape(contextInfo.ID)+"&path="+url.QueryEscape(path), nil, "", secrets["webmux"], origin)
			if e == nil && status == 200 {
				json.Unmarshal(b, &node)
			}
		}
		checks["file_node_download_resolved"] = contextInfo.ID != "" && node.ID != ""
		downloadPath := "/api/sessions/" + id + "/code/node?contextId=" + url.QueryEscape(contextInfo.ID) + "&nodeId=" + url.QueryEscape(node.ID)
		activeBulk.Store(1)
		downloadDone := make(chan map[string]any, 1)
		go func() {
			defer activeBulk.Store(0)
			start := time.Now()
			status, b, e := request("GET", downloadPath, nil, "", secrets["webmux"], origin)
			h := sha256.Sum256(b)
			r := map[string]any{"direction": "download", "status": status, "seconds": time.Since(start).Seconds(), "bytes": len(b), "hash_ok": hex.EncodeToString(h[:]) == up["hash"]}
			if e != nil {
				r["error"] = e.Error()
			}
			downloadDone <- r
		}()
		echoPTY("download", time.Duration(*seconds)*time.Second)
		transfers = append(transfers, <-downloadDone)
	}
	if *forwardBytes > 0 {
		extra, ck := forwardBusiness(hc, request, origin, secrets["webmux"], echoPTY)
		transfers = append(transfers, extra...)
		for k, v := range ck {
			checks[k] = v
		}
	}
	// Offset reattachment requests exactly the already received output boundary.
	c.Close(websocket.StatusNormalClosure, "resume test")
	offlineMarker := []byte(fmt.Sprintf("offline-r604-%016x", time.Now().UnixNano()))
	offlineBody, _ := json.Marshal(map[string]any{"clientRequestId": fmt.Sprintf("r604%016x", time.Now().UnixNano()), "text": string(offlineMarker)})
	var faultStart time.Time
	if *faultHook != "" {
		faultStart = time.Now()
		b, err := exec.Command("python", *faultHook, id, string(offlineMarker)).Output()
		if err != nil {
			checks["fault_error"] = err.Error()
		} else {
			var details map[string]any
			json.Unmarshal(b, &details)
			checks["fault_details"] = details
			checks["offline_input_acknowledged"] = details["offline_input_acknowledged"]
		}
		tr.CloseIdleConnections()
	} else {
		status, _, e = request("POST", "/api/sessions/"+id+"/input", bytes.NewReader(offlineBody), "application/json", secrets["webmux"], origin)
		checks["offline_input_acknowledged"] = e == nil && status == 200
	}
	resumed, e := open(fmt.Sprintf("&generation=%s&offset=%d", pos.Generation, received))
	checks["resume_open"] = e == nil
	if e == nil {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		var tail []byte
		for {
			_, p, e := resumed.Read(ctx)
			if e != nil {
				checks["resume_error"] = e.Error()
				break
			}
			if len(p) > 0 && p[0] == 4 {
				var rp position
				json.Unmarshal(p[1:], &rp)
				checks["resume_append"] = rp.Mode == "append"
				checks["resume_offset_equal"] = rp.Start == received
			}
			if len(p) > 0 && (p[0] == 0 || p[0] == 1) {
				tail = append(tail, p[1:]...)
			}
			if bytes.Contains(tail, offlineMarker) {
				break
			}
		}
		checks["resume_marker_once"] = bytes.Count(tail, offlineMarker) == 1 && len(tail) == len(offlineMarker)
		checks["resume_tail_bytes"] = len(tail)
		if !faultStart.IsZero() {
			checks["restart_to_operable_ms"] = float64(time.Since(faultStart).Microseconds()) / 1000
		}
		cancel()
		resumed.Close(websocket.StatusNormalClosure, "done")
	}
	summary := map[string]any{}
	for _, phase := range []string{"idle", "upload", "download", "forward-upload", "forward-download"} {
		var v []float64
		fails := 0
		for _, s := range samples {
			if s.Phase == phase && (phase == "idle" || s.BulkActive) {
				if s.OK {
					v = append(v, s.MS)
				} else {
					fails++
				}
			}
		}
		sort.Float64s(v)
		m := map[string]any{"n": len(v), "failures": fails}
		if len(v) > 0 {
			m["p50"] = v[(len(v)-1)/2]
			m["p95"] = v[int(float64(len(v)-1)*.95)]
			m["p99"] = v[int(float64(len(v)-1)*.99)]
		}
		summary[phase] = m
	}
	// Persist only statistics, never bearer token, terminal markers, or upload path.
	for _, r := range transfers {
		delete(r, "path")
		delete(r, "hash")
	}
	json.NewEncoder(os.Stdout).Encode(map[string]any{"time": time.Now().UTC().Format(time.RFC3339), "origin": origin, "checks": checks, "summary": summary, "samples": samples, "transfers": transfers})
}
