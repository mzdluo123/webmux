package main

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"flag"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/coder/websocket"
	fryamux "github.com/fatedier/yamux"
	"github.com/hashicorp/yamux"
	quic "github.com/quic-go/quic-go"
	kcp "github.com/xtaci/kcp-go/v5"
	"github.com/xtaci/smux"
)

type stream interface {
	io.ReadWriteCloser
	SetDeadline(time.Time) error
}
type session interface {
	Open() (stream, error)
	Accept() (stream, error)
	Close() error
}
type ym struct{ *yamux.Session }
type fym struct{ *fryamux.Session }

func (s fym) Open() (stream, error)   { return s.OpenStream() }
func (s fym) Accept() (stream, error) { return s.AcceptStream() }

func (s ym) Open() (stream, error)   { return s.OpenStream() }
func (s ym) Accept() (stream, error) { return s.AcceptStream() }

type sm struct{ *smux.Session }

func (s sm) Open() (stream, error)   { return s.OpenStream() }
func (s sm) Accept() (stream, error) { return s.AcceptStream() }

type qm struct{ c *quic.Conn }
type directSession struct{ address string }

func (s directSession) Open() (stream, error) {
	return net.DialTimeout("tcp", s.address, 10*time.Second)
}
func (s directSession) Accept() (stream, error) {
	return nil, fmt.Errorf("client-only sidecar adapter")
}
func (s directSession) Close() error { return nil }

func (s qm) Open() (stream, error) {
	ctx, c := context.WithTimeout(context.Background(), 15*time.Second)
	defer c()
	return s.c.OpenStreamSync(ctx)
}
func (s qm) Accept() (stream, error) { return s.c.AcceptStream(context.Background()) }
func (s qm) Close() error            { return s.c.CloseWithError(0, "done") }

var mode = flag.String("mode", "client", "cert/server/client")
var addr = flag.String("addr", "172.233.136.221", "server IP")
var proto = flag.String("proto", "tls-yamux", "tls-yamux/tls-smux/wss-yamux/wss-smux/quic/kcp/kcp-fec")
var pool = flag.Int("pool", 1, "1/2/4 authenticated connections; interactive connection isolated for pool>1")
var portOverride = flag.Int("port", 0, "override target port for sidecar comparison")
var seconds = flag.Int("seconds", 20, "duration of each interactive phase")
var size = flag.Int64("bytes", 100*1024*1024, "bulk bytes")
var certDir = flag.String("cert-dir", ".", "test credentials directory")
var backend = flag.String("backend", "127.0.0.1:17681", "fixed loopback backend only")
var direction = flag.String("direction", "download", "bulk-only direction")
var endpoint = flag.String("endpoint", "", "business base URL override for loopback control")
var kcpNoCC = flag.Int("kcp-no-cc", 0, "KCP nc parameter: 0 enabled, 1 disables its congestion window")
var kcpWindow = flag.Int("kcp-window", 256, "KCP send and receive window packets")
var echoBulkAll = flag.Bool("echo-entire-bulk", false, "continue interactive sampling until all bulk data is acknowledged")
var forwardBytes = flag.Int64("forward-bytes", 0, "optional streaming /forward fixture payload bytes")
var faultHook = flag.String("fault-hook", "", "optional local operator script for the selected connector restart experiment")
var hostSessions sync.Map
var ports = map[string]int{"tls-yamux": 18443, "tls-smux": 18444, "wss-yamux": 18445, "wss-smux": 18446, "quic": 18447, "kcp": 18448, "kcp-fec": 18449, "tls-frpyamux": 18457, "wss-frpyamux": 18458, "quic1200": 18460}

func credentials(server bool) *tls.Config {
	cert, e := tls.LoadX509KeyPair(*certDir+"/cert.pem", *certDir+"/key.pem")
	if e != nil {
		log.Fatal(e)
	}
	b, e := os.ReadFile(*certDir + "/cert.pem")
	if e != nil {
		log.Fatal(e)
	}
	roots := x509.NewCertPool()
	roots.AppendCertsFromPEM(b)
	c := &tls.Config{Certificates: []tls.Certificate{cert}, RootCAs: roots, ClientCAs: roots, ServerName: "relay-bench", MinVersion: tls.VersionTLS13, NextProtos: []string{"relay-bench-v1"}}
	if server {
		c.ClientAuth = tls.RequireAndVerifyClientCert
	}
	return c
}
func makeCert() {
	key, e := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if e != nil {
		log.Fatal(e)
	}
	t := &x509.Certificate{SerialNumber: big.NewInt(604), Subject: pkix.Name{CommonName: "relay-bench"}, DNSNames: []string{"relay-bench"}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(72 * time.Hour), KeyUsage: x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth, x509.ExtKeyUsageClientAuth}, IsCA: true, BasicConstraintsValid: true}
	der, e := x509.CreateCertificate(rand.Reader, t, t, &key.PublicKey, key)
	if e != nil {
		log.Fatal(e)
	}
	kb, _ := x509.MarshalECPrivateKey(key)
	if e = os.WriteFile(*certDir+"/cert.pem", pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0600); e != nil {
		log.Fatal(e)
	}
	if e = os.WriteFile(*certDir+"/key.pem", pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: kb}), 0600); e != nil {
		log.Fatal(e)
	}
	h := sha256.Sum256(der)
	fmt.Printf("test certificate SHA256 %x\n", h)
}
func mux(c net.Conn, p string, server bool) (session, error) {
	if strings.Contains(p, "frpyamux") {
		cfg := fryamux.DefaultConfig()
		cfg.MaxStreamWindowSize = 1024 * 1024
		cfg.LogOutput = io.Discard
		if server {
			s, e := fryamux.Server(c, cfg)
			return fym{s}, e
		}
		s, e := fryamux.Client(c, cfg)
		return fym{s}, e
	}
	if strings.Contains(p, "yamux") {
		cfg := yamux.DefaultConfig()
		cfg.MaxStreamWindowSize = 1024 * 1024
		cfg.LogOutput = io.Discard
		if server {
			s, e := yamux.Server(c, cfg)
			return ym{s}, e
		}
		s, e := yamux.Client(c, cfg)
		return ym{s}, e
	}
	cfg := smux.DefaultConfig()
	cfg.Version = 2
	cfg.MaxReceiveBuffer = 4 * 1024 * 1024
	cfg.MaxStreamBuffer = 1024 * 1024
	if server {
		s, e := smux.Server(c, cfg)
		return sm{s}, e
	}
	s, e := smux.Client(c, cfg)
	return sm{s}, e
}
func kconfig(c *kcp.UDPSession) {
	c.SetNoDelay(1, 20, 2, *kcpNoCC)
	c.SetWindowSize(*kcpWindow, *kcpWindow)
	c.SetMtu(1350)
	c.SetACKNoDelay(true)
}
func fec(p string) (int, int) {
	if p == "kcp-fec" {
		return 10, 3
	}
	return 0, 0
}
func dial(p string) (session, error) {
	port := ports[p]
	if *portOverride != 0 {
		port = *portOverride
	}
	a := net.JoinHostPort(*addr, fmt.Sprint(port))
	if p == "sidecar" {
		return directSession{a}, nil
	}
	cfg := credentials(false)
	if strings.HasPrefix(p, "quic") {
		ctx, c := context.WithTimeout(context.Background(), 10*time.Second)
		defer c()
		qc := &quic.Config{MaxIdleTimeout: 60 * time.Second, KeepAlivePeriod: 10 * time.Second, InitialStreamReceiveWindow: 1024 * 1024, MaxStreamReceiveWindow: 1024 * 1024, InitialConnectionReceiveWindow: 4 * 1024 * 1024, MaxConnectionReceiveWindow: 4 * 1024 * 1024}
		if p == "quic1200" {
			qc.InitialPacketSize = 1200
		}
		q, e := quic.DialAddr(ctx, a, cfg, qc)
		return qm{q}, e
	}
	var c net.Conn
	var e error
	if strings.HasPrefix(p, "wss") {
		cfg.NextProtos = nil
		hc := &http.Client{Transport: &http.Transport{Proxy: nil, TLSClientConfig: cfg, DialContext: (&net.Dialer{Timeout: 10 * time.Second, Control: tcpControl}).DialContext}, Timeout: 15 * time.Second}
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		w, _, err := websocket.Dial(ctx, "wss://"+a+"/bench", &websocket.DialOptions{HTTPClient: hc})
		if err != nil {
			return nil, err
		}
		w.SetReadLimit(-1)
		c = websocket.NetConn(context.Background(), w, websocket.MessageBinary)
	} else if strings.HasPrefix(p, "kcp") {
		d, r := fec(p)
		u, err := kcp.DialWithOptions(a, nil, d, r)
		if err != nil {
			return nil, err
		}
		kconfig(u)
		c = tls.Client(u, cfg)
	} else {
		c, e = (&net.Dialer{Timeout: 10 * time.Second, Control: tcpControl}).DialContext(context.Background(), "tcp", a)
		if e != nil {
			return nil, e
		}
		c = tls.Client(c, cfg)
	}
	if t, ok := c.(*tls.Conn); ok {
		t.SetDeadline(time.Now().Add(15 * time.Second))
		if e = t.Handshake(); e != nil {
			c.Close()
			return nil, e
		}
		t.SetDeadline(time.Time{})
	}
	s, e := mux(c, p, false)
	if e != nil {
		c.Close()
	}
	return s, e
}
func serve(p string) {
	a := fmt.Sprintf(":%d", ports[p])
	cfg := credentials(true)
	if strings.HasPrefix(p, "quic") {
		qc := &quic.Config{MaxIdleTimeout: 60 * time.Second, KeepAlivePeriod: 10 * time.Second, MaxIncomingStreams: 128, InitialStreamReceiveWindow: 1024 * 1024, MaxStreamReceiveWindow: 1024 * 1024, InitialConnectionReceiveWindow: 4 * 1024 * 1024, MaxConnectionReceiveWindow: 4 * 1024 * 1024}
		if p == "quic1200" {
			qc.InitialPacketSize = 1200
		}
		l, e := quic.ListenAddr(a, cfg, qc)
		if e != nil {
			log.Fatal(e)
		}
		for {
			c, e := l.Accept(context.Background())
			if e != nil {
				log.Print(e)
				continue
			}
			go runSession(qm{c})
		}
	}
	if strings.HasPrefix(p, "wss") {
		cfg.NextProtos = nil
		h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			c, e := websocket.Accept(w, r, nil)
			if e != nil {
				return
			}
			c.SetReadLimit(-1)
			s, e := mux(websocket.NetConn(context.Background(), c, websocket.MessageBinary), p, true)
			if e != nil {
				return
			}
			runSession(s)
		})
		srv := &http.Server{Addr: a, Handler: h, TLSConfig: cfg, ReadHeaderTimeout: 10 * time.Second}
		log.Fatal(srv.ListenAndServeTLS(*certDir+"/cert.pem", *certDir+"/key.pem"))
		return
	}
	var l net.Listener
	var e error
	if strings.HasPrefix(p, "kcp") {
		d, r := fec(p)
		l, e = kcp.ListenWithOptions(a, nil, d, r)
	} else {
		l, e = net.Listen("tcp", a)
	}
	if e != nil {
		log.Fatal(e)
	}
	for {
		c, e := l.Accept()
		if e != nil {
			continue
		}
		if u, ok := c.(*kcp.UDPSession); ok {
			kconfig(u)
		}
		go func(c net.Conn) {
			t := tls.Server(c, cfg)
			t.SetDeadline(time.Now().Add(15 * time.Second))
			if e := t.Handshake(); e != nil {
				log.Print(e)
				c.Close()
				return
			}
			t.SetDeadline(time.Time{})
			s, e := mux(t, p, true)
			if e != nil {
				c.Close()
				return
			}
			runSession(s)
		}(c)
	}
}
func runSession(s session) {
	defer s.Close()
	for {
		c, e := s.Accept()
		if e != nil {
			return
		}
		go handle(s, c)
	}
}

type zeros struct{}

// Deterministic, incompressible test data; the fixed key is not an identity secret.
func payload() io.Reader {
	b, e := aes.NewCipher(make([]byte, 32))
	if e != nil {
		panic(e)
	}
	return &cipher.StreamReader{S: cipher.NewCTR(b, make([]byte, 16)), R: zeros{}}
}

func (zeros) Read(p []byte) (int, error) { clear(p); return len(p), nil }
func handle(sess session, c stream) {
	defer c.Close()
	c.SetDeadline(time.Now().Add(15 * time.Minute))
	var h [9]byte
	if _, e := io.ReadFull(c, h[:]); e != nil {
		return
	}
	n := int64(binary.BigEndian.Uint64(h[1:]))
	if n < 0 || n > 2*1024*1024*1024 {
		return
	}
	switch h[0] {
	case 4:
		// A tunneled WebSocket can outlive a file request. The caller and
		// session keepalive own its cancellation, not a fixed HTTP lifetime.
		c.SetDeadline(time.Time{})
		up, e := net.DialTimeout("tcp", *backend, 5*time.Second)
		if e != nil {
			return
		}
		defer up.Close()
		done := make(chan struct{})
		go func() {
			io.Copy(up, c)
			if t, ok := up.(*net.TCPConn); ok {
				t.CloseWrite()
			}
			close(done)
		}()
		io.Copy(c, up)
		c.Close()
		<-done
	case 5:
		c.SetDeadline(time.Time{})
		hostSessions.Store(int(n), sess)
		defer hostSessions.CompareAndDelete(int(n), sess)
		c.Write([]byte{1})
		io.Copy(io.Discard, c)
	case 6:
		h := sha256.New()
		if _, e := io.Copy(h, c); e == nil {
			c.Write(h.Sum(nil))
		}
	case 1:
		var b [32]byte
		for {
			if _, e := io.ReadFull(c, b[:]); e != nil {
				return
			}
			if _, e := c.Write(b[:]); e != nil {
				return
			}
		}
	case 2:
		hash := sha256.New()
		_, e := io.CopyN(io.MultiWriter(c, hash), payload(), n)
		if e == nil {
			c.Write(hash.Sum(nil))
		}
	case 3:
		hash := sha256.New()
		_, e := io.CopyN(hash, c, n)
		if e == nil {
			c.Write(hash.Sum(nil))
		}
	}
}

type tunnelConn struct{ stream }

func (t tunnelConn) Close() error {
	if q, ok := t.stream.(*quic.Stream); ok {
		q.CancelRead(604)
		return q.Close()
	}
	return t.stream.Close()
}

func (t tunnelConn) LocalAddr() net.Addr                { return &net.TCPAddr{} }
func (t tunnelConn) RemoteAddr() net.Addr               { return &net.TCPAddr{} }
func (t tunnelConn) SetReadDeadline(v time.Time) error  { return t.SetDeadline(v) }
func (t tunnelConn) SetWriteDeadline(v time.Time) error { return t.SetDeadline(v) }
func gateway(port int, reverse bool) {
	target, _ := url.Parse("http://" + *backend)
	transports := map[int]*http.Transport{}
	for i := 0; i < 4; i++ {
		idx := i
		tr := &http.Transport{Proxy: nil, MaxIdleConnsPerHost: 32, ResponseHeaderTimeout: 30 * time.Second}
		if reverse {
			tr.DialContext = func(ctx context.Context, network, address string) (net.Conn, error) {
				v, ok := hostSessions.Load(idx)
				if !ok {
					v, ok = hostSessions.Load(0)
				}
				if !ok {
					return nil, fmt.Errorf("host offline")
				}
				s, e := v.(session).Open()
				if e != nil {
					return nil, e
				}
				if e = header(s, 4, 0); e != nil {
					s.Close()
					return nil, e
				}
				return tunnelConn{s}, nil
			}
		}
		transports[i] = tr
	}
	proxies := map[int]*httputil.ReverseProxy{}
	for i, t := range transports {
		p := httputil.NewSingleHostReverseProxy(target)
		p.Transport = t
		p.FlushInterval = -1
		proxies[i] = p
	}
	h := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		idx := 0
		if bulkPath(r.URL.Path) {
			idx = 1
		}
		proxies[idx].ServeHTTP(w, r)
	})
	cfg := credentials(true)
	cfg.NextProtos = []string{"http/1.1"}
	srv := &http.Server{Addr: fmt.Sprint(":", port), Handler: h, TLSConfig: cfg, ReadHeaderTimeout: 10 * time.Second}
	log.Print(srv.ListenAndServeTLS(*certDir+"/cert.pem", *certDir+"/key.pem"))
}
func bulkPath(path string) bool {
	return strings.Contains(path, "upload") || strings.Contains(path, "/bulk") || (strings.Contains(path, "/code/") && (strings.HasSuffix(path, "/node") || strings.HasSuffix(path, "/archive") || strings.HasSuffix(path, "/raw")))
}
func header(c stream, m byte, n int64) error {
	var b [9]byte
	b[0] = m
	binary.BigEndian.PutUint64(b[1:], uint64(n))
	_, e := c.Write(b[:])
	return e
}

type sample struct {
	Phase      string  `json:"phase"`
	MS         float64 `json:"ms"`
	OK         bool    `json:"ok"`
	At         string  `json:"at"`
	BulkActive bool    `json:"bulk_active"`
}

var activeBulk atomic.Int32

type bulkResult struct {
	Direction      string  `json:"direction"`
	Bytes          int64   `json:"bytes"`
	Seconds        float64 `json:"seconds"`
	Mbps           float64 `json:"mbps"`
	HashOK         bool    `json:"hash_ok"`
	Error          string  `json:"error,omitempty"`
	RequestedBytes int64   `json:"requested_bytes"`
}

func bulk(s session, dir string, n int64) bulkResult {
	r := bulkResult{Direction: dir, RequestedBytes: n}
	start := time.Now()
	c, e := s.Open()
	if e != nil {
		r.Error = e.Error()
		return r
	}
	defer c.Close()
	c.SetDeadline(time.Now().Add(12 * time.Minute))
	m := byte(2)
	if dir == "upload" {
		m = 3
	}
	if e = header(c, m, n); e != nil {
		r.Error = e.Error()
		return r
	}
	h := sha256.New()
	if m == 2 {
		r.Bytes, e = io.CopyN(h, c, n)
	} else {
		r.Bytes, e = io.CopyN(io.MultiWriter(c, h), payload(), n)
	}
	var got [32]byte
	if e == nil {
		_, e = io.ReadFull(c, got[:])
	}
	r.Seconds = time.Since(start).Seconds()
	r.HashOK = e == nil && hex.EncodeToString(got[:]) == hex.EncodeToString(h.Sum(nil))
	if r.HashOK {
		r.Mbps = float64(r.Bytes) * 8 / r.Seconds / 1e6
	}
	if e != nil {
		r.Error = e.Error()
	}
	return r
}
func echo(s session, phase string, d time.Duration) []sample {
	c, e := s.Open()
	if e != nil {
		return []sample{{Phase: phase, OK: false}}
	}
	defer c.Close()
	header(c, 1, 0)
	var out []sample
	end := time.Now().Add(d)
	for time.Now().Before(end) || (*echoBulkAll && phase != "idle" && activeBulk.Load() > 0) {
		var b [32]byte
		rand.Read(b[:])
		start := time.Now()
		active := activeBulk.Load() > 0
		c.SetDeadline(start.Add(10 * time.Second))
		_, e = c.Write(b[:])
		var got [32]byte
		if e == nil {
			_, e = io.ReadFull(c, got[:])
		}
		out = append(out, sample{phase, float64(time.Since(start).Microseconds()) / 1000, e == nil && b == got, start.UTC().Format(time.RFC3339Nano), active})
		if e != nil {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	return out
}
func main() {
	flag.Parse()
	log.SetFlags(log.LstdFlags | log.LUTC)
	if *mode == "cert" {
		makeCert()
		return
	}
	if *mode == "business" {
		business()
		return
	}
	if *mode == "security" {
		security()
		return
	}
	if *mode == "slow" {
		slow()
		return
	}
	if *mode == "compete" {
		compete()
		return
	}
	if *mode == "halfclose" {
		s, e := dial(*proto)
		if e != nil {
			log.Fatal(e)
		}
		defer s.Close()
		c, e := s.Open()
		if e != nil {
			log.Fatal(e)
		}
		defer c.Close()
		c.SetDeadline(time.Now().Add(8 * time.Second))
		header(c, 6, 0)
		h := sha256.New()
		_, e = io.CopyN(io.MultiWriter(c, h), payload(), 65536)
		if e == nil {
			if cw, ok := c.(interface{ CloseWrite() error }); ok {
				e = cw.CloseWrite()
			} else {
				e = c.Close()
			}
		}
		var got [32]byte
		if e == nil {
			_, e = io.ReadFull(c, got[:])
		}
		r := map[string]any{"proto": *proto, "half_close_response_ok": e == nil && hex.EncodeToString(got[:]) == hex.EncodeToString(h.Sum(nil))}
		if e != nil {
			r["error"] = e.Error()
		}
		json.NewEncoder(os.Stdout).Encode(r)
		return
	}
	if *mode == "bulk" {
		s, e := dial(*proto)
		if e != nil {
			log.Fatal(e)
		}
		defer s.Close()
		json.NewEncoder(os.Stdout).Encode(bulk(s, *direction, *size))
		return
	}
	if *mode == "gateway" {
		gateway(*portOverride, false)
		select {}
	}
	if *mode == "server" {
		go func() {
			l, e := net.Listen("tcp", "127.0.0.1:18454")
			if e != nil {
				log.Fatal(e)
			}
			for {
				c, e := l.Accept()
				if e != nil {
					return
				}
				go handle(nil, c)
			}
		}()
		go gateway(18451, false)
		go gateway(18452, true)
		for p := range ports {
			go serve(p)
		}
		select {}
	}
	if *mode == "host" {
		for i := 0; i < *pool; i++ {
			s, e := dial(*proto)
			if e != nil {
				log.Fatal(e)
			}
			c, e := s.Open()
			if e != nil {
				log.Fatal(e)
			}
			header(c, 5, int64(i))
			var ack [1]byte
			if _, e = io.ReadFull(c, ack[:]); e != nil {
				log.Fatal(e)
			}
			go runSession(s)
		}
		log.Print("authenticated reverse host ready")
		select {}
	}
	var sessions []session
	var handshakes []float64
	for i := 0; i < *pool; i++ {
		start := time.Now()
		s, e := dial(*proto)
		if e != nil {
			log.Fatal(e)
		}
		c, e := s.Open()
		if e == nil {
			header(c, 1, 0)
			c.SetDeadline(time.Now().Add(15 * time.Second))
			var b [32]byte
			c.Write(b[:])
			_, e = io.ReadFull(c, b[:])
			c.Close()
		}
		if e != nil {
			log.Fatal(e)
		}
		handshakes = append(handshakes, float64(time.Since(start).Microseconds())/1000)
		sessions = append(sessions, s)
		defer s.Close()
	}
	all := echo(sessions[0], "idle", time.Duration(*seconds)*time.Second)
	var transfers []bulkResult
	for _, dir := range []string{"download", "upload"} {
		var wg sync.WaitGroup
		var mu sync.Mutex
		bulkSessions := sessions
		if len(sessions) > 1 {
			bulkSessions = sessions[1:]
		}
		for _, s := range bulkSessions {
			wg.Add(1)
			activeBulk.Add(1)
			go func(s session) {
				defer wg.Done()
				defer activeBulk.Add(-1)
				r := bulk(s, dir, *size/int64(len(bulkSessions)))
				mu.Lock()
				transfers = append(transfers, r)
				mu.Unlock()
			}(s)
		}
		all = append(all, echo(sessions[0], dir, time.Duration(*seconds)*time.Second)...)
		wg.Wait()
	}
	summary := map[string]any{}
	for _, phase := range []string{"idle", "download", "upload"} {
		var v []float64
		fails := 0
		for _, s := range all {
			if s.Phase == phase && (phase == "idle" || s.BulkActive) {
				if s.OK {
					v = append(v, s.MS)
				} else {
					fails++
				}
			}
		}
		sort.Float64s(v)
		m := map[string]any{"n": len(v), "failures": fails}
		if len(v) > 0 {
			for _, q := range []struct {
				name string
				p    float64
			}{{"p50", .50}, {"p95", .95}, {"p99", .99}} {
				m[q.name] = v[int(float64(len(v)-1)*q.p)]
			}
		}
		summary[phase] = m
	}
	result := map[string]any{"time": time.Now().UTC().Format(time.RFC3339), "proto": *proto, "pool": *pool, "target": *addr, "bytes": *size, "phase_seconds": *seconds, "handshake_ms": handshakes, "summary": summary, "bulk": transfers, "samples": all, "kcp_nc": *kcpNoCC, "kcp_window": *kcpWindow, "self": platformMetrics()}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	enc.Encode(result)
}
