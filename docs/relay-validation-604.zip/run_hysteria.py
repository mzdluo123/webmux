from suite_helpers import *
import psutil
remote('cd /root/relay-validation\nkill "$(cat ns-hysteria.pid)"\nnohup ip netns exec relay604 ./hysteria-linux server -c hysteria-server.yaml > hysteria-ns.log 2>&1 < /dev/null &\necho $! > ns-hysteria.pid\nsleep 1\nhead -4 hysteria-ns.log','restart-hysteria')
for variant in ['bbr','5mbps','20mbps','50mbps']:
    print('HYSTERIA',variant,flush=True)
    log=(ROOT/'results'/f'hysteria-{variant}-client.log').open('w')
    p=subprocess.Popen([str(ROOT/'tools'/'hysteria.exe'),'client','-c',f'hysteria-{variant}.yaml'],cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT)
    try:
        start=time.monotonic()
        while time.monotonic()-start<15:
            if 'connected to server' in (ROOT/'results'/f'hysteria-{variant}-client.log').read_text():break
            if p.poll() is not None:break
            time.sleep(.05)
        (ROOT/'results'/f'hysteria-{variant}-startup.json').write_text(json.dumps({'ready_s':time.monotonic()-start,'pid':p.pid}))
        if p.poll() is not None:raise RuntimeError('hysteria exited: '+variant)
        matrix('hysteria-'+variant,'sidecar',pools='1',rounds=2,size=16*1024*1024,seconds=12,addr='127.0.0.1',port=19443,observe_pid=p.pid)
    finally:p.terminate();p.wait(timeout=10);log.close()
