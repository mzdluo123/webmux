package main

import (
	"golang.org/x/sys/unix"
	"syscall"
)

func tcpControl(network, address string, raw syscall.RawConn) error {
	var inner error
	if err := raw.Control(func(fd uintptr) { inner = unix.SetsockoptString(int(fd), unix.IPPROTO_TCP, unix.TCP_CONGESTION, "bbr") }); err != nil {
		return err
	}
	return inner
}
func platformMetrics() map[string]any {
	var r unix.Rusage
	if e := unix.Getrusage(unix.RUSAGE_SELF, &r); e != nil {
		return map[string]any{"error": e.Error()}
	}
	return map[string]any{"peak_rss": r.Maxrss * 1024, "cpu_seconds": float64(r.Utime.Sec+r.Stime.Sec) + float64(r.Utime.Usec+r.Stime.Usec)/1e6}
}
