from run_terminal_matrix import *
try:
 for repetition in [1,2]:
  profiles=['clean','loss3'] if repetition==1 else ['loss3','clean']
  for profile in profiles:
   order=CANDIDATES if repetition==1 else list(reversed(CANDIDATES))
   for proto,pool in order:
    run(f'light8192-{profile}-r{repetition}-{proto}-p{pool}',proto,pool,profile,loads=False,client='relay-terminal-light.exe',self_rate=8192,idle=30)
 # A higher TUI redraw rate is a stress boundary, separate from the main 8 KiB/s workload.
 for proto,pool in CANDIDATES:
  run(f'light32768-loss3-r1-{proto}-p{pool}',proto,pool,'loss3',loads=False,client='relay-terminal-light.exe',self_rate=32768,idle=30)
 for proto,pool in [('wss-smux',2),('quic1200',1),('quic1200',2)]:
  run(f'light8192-burst-r1-{proto}-p{pool}',proto,pool,'burst',loads=False,client='relay-terminal-light.exe',self_rate=8192,idle=30)
 # Fill the second WSS stress repetition if the previous batch was paused before it.
 run('loss3-r2-wss-smux-p2','wss-smux',2,'loss3')
 for repetition in [1,2]:run(f'loss3-r{repetition}-kcp-fec-p2','kcp-fec',2,'loss3')
 for proto,pool in [('wss-smux',2),('quic1200',1),('quic1200',2),('kcp',2)]:
  run(f'light8192-restart-loss3-{proto}-p{pool}',proto,pool,'loss3',loads=False,hook=True,client='relay-terminal-light.exe',self_rate=8192,idle=10)
finally:
 setprofile('clean')
(OUT/'terminal-priority-finished.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
