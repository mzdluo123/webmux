#!/bin/bash
set -euo pipefail
cd /root/relay-validation
profile=${1:-clean}
scope=${2:-b}
tc qdisc del dev r604-host root 2>/dev/null || true
ip netns exec relay604 tc qdisc del dev r604-peer root 2>/dev/null || true
case "$profile" in
 clean) args=() ;;
 loss1) args=(loss random 1% rate 20mbit) ;;
 loss3) args=(loss random 3% rate 5mbit) ;;
 burst) args=(loss gemodel 1% 25% 80% 0.1% rate 5mbit) ;;
 *) exit 1 ;;
esac
if test "$profile" != clean; then
 for side in host peer; do
  if test "$side" = host; then prefix=(); dev=r604-host; field=dport; seed=1604; else prefix=(ip netns exec relay604);dev=r604-peer;field=sport;seed=1605;fi
  "${prefix[@]}" tc qdisc add dev "$dev" root handle 1: prio bands 3 priomap 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
  "${prefix[@]}" tc qdisc add dev "$dev" parent 1:3 handle 30: netem limit 1000 "${args[@]}" seed "$seed"
  tcp_ports=(18443 18444 18445 18446 18457 18458)
  if test "$scope" = both; then tcp_ports+=(18452);fi
  for p in "${tcp_ports[@]}";do "${prefix[@]}" tc filter add dev "$dev" protocol ip parent 1: pref 1 u32 match ip protocol 6 0xff match ip "$field" "$p" 0xffff flowid 1:3;done
  for p in 18447 18448 18449 18459 18460 19003;do "${prefix[@]}" tc filter add dev "$dev" protocol ip parent 1: pref 2 u32 match ip protocol 17 0xff match ip "$field" "$p" 0xffff flowid 1:3;done
 done
fi
date -u
printf 'profile=%s scope=%s\n' "$profile" "$scope"
tc -s qdisc show dev r604-host
ip netns exec relay604 tc -s qdisc show dev r604-peer
