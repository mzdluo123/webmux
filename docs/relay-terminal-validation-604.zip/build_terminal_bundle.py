from pathlib import Path
import hashlib,json,subprocess,sys,platform,zipfile,re,gzip,ipaddress
R=Path(__file__).resolve().parent
names=['relay-terminal.exe','relay-terminal-light.exe','relay-terminal-hy.exe','relay-business-server-v2-linux','relay-server-linux','relay-terminal-hy-linux','webmux-linux','tools/hysteria-linux']
info={'python':sys.version,'platform':platform.platform(),'scope':'fixed binary fingerprints; final source includes hy-smux adapter and self-output mode','binaries':[]}
for name in names:
 p=R/name
 if p.exists():info['binaries'].append({'file':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'go_build_info':subprocess.check_output(['go','version','-m',str(p)],text=True)})
(R/'terminal-build-info.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
allowed=['main.go','business.go','forward_business.go','security.go','slow.go','compete.go','terminal.go','tcp_linux.go','tcp_windows.go','cmd/httpfixture/main.go','go.mod','go.sum','prepare.py','suite_helpers.py','ssh_worker.py','monitor.py','monitor_host.py','udp_probe.py','reproduce-server.sh','terminal-profile.sh','terminal-launch-host.sh','run_terminal_matrix.py','run_terminal_priority.py','run_terminal_supplement.py','run_terminal_restarts.py','terminal_fault_hook.py','analyze_terminal.py','analyze_terminal_resources.py','collect_terminal.py','collect-terminal-wsl.sh','terminal-build-info.json','build_terminal_bundle.py','make_terminal_report.py','TERMINAL.template.md','terminal-editorial.json']
entries={'README.md':(R/'TERMINAL-REPRODUCE.md').read_bytes(),'LICENSE':(R.parent/'webmux-validation/LICENSE').read_bytes()}
for name in allowed:
 data=(R/name).read_bytes()
 if name.endswith('.sh'):data=data.decode('utf-8-sig').replace('\r\n','\n').encode()
 entries[name]=data
for p in sorted((R/'terminal-results').iterdir()):
 if p.is_file() and p.suffix in ['.json','.csv','.txt','.gz','.log']:
  entries['terminal-results/'+p.name]=p.read_bytes()
secret=json.loads((R/'secrets.json').read_text())
for name,data in entries.items():
 plain=gzip.decompress(data) if name.endswith('.gz') else data
 if any(v.encode() in plain for v in secret.values()):raise ValueError('secret in '+name)
 if re.search(rb'-----BEGIN [^-]*PRIVATE KEY-----',plain):raise ValueError('private key in '+name)
 for value in re.findall(rb'(?<![\w.])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?![\w.])',plain):
  try:ip=ipaddress.ip_address(value.decode())
  except ValueError:continue
  if ip.is_global and str(ip)!='172.233.136.221':raise ValueError('unapproved public address in '+name)
manifest={'scope':'terminal-first supplementary experiments; raw failures and calibration retained','files':[{'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(entries.items())]}
entries['MANIFEST.json']=json.dumps(manifest,indent=2).encode()
p=R/'relay-terminal-validation-604.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,d in sorted(entries.items()):z.writestr(n,d)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256'] for x in manifest['files'])
info={'file':p.name,'bytes':p.stat().st_size,'files':len(entries),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(R/'terminal-bundle-info.json').write_text(json.dumps(info,indent=2))
for repo in ['webmux-validation','webmux-planning']:(R.parent/repo/'docs'/p.name).write_bytes(p.read_bytes())
print(json.dumps(info))
