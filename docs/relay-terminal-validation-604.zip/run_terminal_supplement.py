import os
os.environ['R604_SERVER_BINARY']='relay-terminal-hy-linux'
from run_terminal_matrix import *
try:
 candidates=[('hy-smux',2),('wss-smux',2),('quic1200',1)]
 for repetition in [1,2]:
  for profile in (['clean','loss3'] if repetition==1 else ['loss3','clean']):
   for proto,pool in (candidates if repetition==1 else list(reversed(candidates))):
    run(f'paired8192-{profile}-r{repetition}-{proto}-p{pool}',proto,pool,profile,loads=False,client='relay-terminal-hy.exe',self_rate=8192,idle=30)
 run('hy-heavy-loss3-r1','hy-smux',2,'loss3',client='relay-terminal-hy.exe')
 # Remaining boundary tests are intentionally separate from primary 8 KiB/s comparison.
 for proto,pool in CANDIDATES:
  run(f'light32768-loss3-r1-{proto}-p{pool}',proto,pool,'loss3',loads=False,client='relay-terminal-hy.exe',self_rate=32768,idle=30)
 for proto,pool in [('wss-smux',2),('quic1200',1),('quic1200',2)]:
  run(f'light8192-burst-r1-{proto}-p{pool}',proto,pool,'burst',loads=False,client='relay-terminal-hy.exe',self_rate=8192,idle=30)
 run('loss3-r2-wss-smux-p2','wss-smux',2,'loss3',client='relay-terminal-hy.exe')
 for repetition in [1,2]:run(f'loss3-r{repetition}-kcp-fec-p2','kcp-fec',2,'loss3',client='relay-terminal-hy.exe')
finally:setprofile('clean')
(OUT/'terminal-supplement-finished.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
