from suite_helpers import *
import psutil,traceback
OUT=ROOT/'terminal-results';OUT.mkdir(exist_ok=True)
CANDIDATES=[('wss-smux',2),('quic1200',1),('quic1200',2),('kcp',2)]
def setprofile(profile,scope='b'):
 text=remote(f'cd /root/relay-validation\nbash terminal-profile.sh {profile} {scope}','terminal-profile-'+profile)
 (OUT/f'profile-{profile}-{scope}-{time.time_ns()}.txt').write_text(text,encoding='utf-8');time.sleep(1)
def reset():
 program=os.environ.get('R604_SERVER_BINARY','relay-server-linux')
 remote(('''cd /root/relay-validation
kill "$(cat ns-server.pid)" 2>/dev/null || true
nohup ip netns exec relay604 ./relay-server-linux -mode server -kcp-no-cc 1 -kcp-window 1024 > server-terminal.log 2>&1 < /dev/null &
echo $! > ns-server.pid
sleep 0.5
kill -0 "$(cat ns-server.pid)"
''').replace('./relay-server-linux','./'+program),'terminal-reset-relay')
def run(label,proto,pool,profile='clean',scope='b',loads=True,port=18452,hook=False,client='relay-terminal.exe',self_rate=0,idle=15):
 target=OUT/(label+'.json');meta=OUT/(label+'.meta.json')
 if meta.exists():return
 reset();setprofile(profile,scope);started=time.time();ready_s=None
 if port==18452:
  with (OUT/(label+'-host.log')).open('w') as f:
   r=subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','/mnt/d/604/relay-validation/terminal-launch-host.sh',proto,str(pool)],env=ENV,stdout=f,stderr=subprocess.STDOUT)
  ready_s=time.time()-started
  if r.returncode:
   target.write_text(json.dumps({'setup_error':'host_not_ready','proto':proto,'pool':pool}),encoding='utf-8');meta.write_text(json.dumps({'start':started,'profile':profile,'scope':scope,'host_ready_s':ready_s,'exit_code':'host_setup_failed','proxy_disabled':True}),encoding='utf-8');print(label,'HOST_SETUP_FAILED',flush=True);return
 cmd=[str(ROOT/client),'-mode','terminal','-proto',proto,'-pool',str(pool),'-port',str(port),'-terminal-idle',str(idle),'-seconds','20']
 if not loads:cmd+=['-terminal-loads=false']
 if self_rate:cmd+=['-terminal-self-output-rate',str(self_rate)]
 if hook:cmd+=['-terminal-hook',str(ROOT/'terminal_fault_hook.py')]
 rss=cpu=0;t=time.time()
 with target.open('w') as f,(OUT/(label+'.log')).open('w') as err:
  p=subprocess.Popen(cmd,cwd=ROOT,env=ENV,stdout=f,stderr=err);observed=psutil.Process(p.pid)
  while p.poll() is None:
   try:rss=max(rss,observed.memory_info().rss);c=observed.cpu_times();cpu=c.user+c.system
   except psutil.Error:pass
   if time.time()-t>270:p.kill();break
   time.sleep(.2)
  p.wait()
 meta.write_text(json.dumps({'start':t,'elapsed_s':time.time()-t,'profile':profile,'scope':scope,'proto':proto,'pool':pool,'host_ready_s':ready_s,'client_peak_rss':rss,'client_cpu_seconds':cpu,'exit_code':p.returncode,'proxy_disabled':True,'command':cmd},indent=2),encoding='utf-8')
 try:
  d=json.loads(target.read_text());sm=d.get('summary',{});line={x:{'sent':v['sent'],'deadline8':v['deadline_8s_failures'],'p95':v['deadline_capped_latency_ms'].get('p95')} for x,v in sm.items() if x in ['idle','other-terminal-output','bulk-download']};print(label,round(time.time()-t,1),line,'output_complete',d.get('loads',{}).get('output_complete'),flush=True)
 except ValueError:print(label,'INVALID_JSON',p.returncode,flush=True)
def probe(label,profile):
 setprofile(profile)
 with (OUT/('probe-'+label+'.json')).open('w') as f:subprocess.run(['python','udp_probe.py'],cwd=ROOT,env=ENV,stdout=f,check=True)
if __name__=='__main__':
 completed=False
 (OUT/'matrix-finished.txt').unlink(missing_ok=True)
 try:
  run('A-idle-control','wss-smux',2,loads=False,port=18451)
  for repetition in [1,2]:
   profiles=['clean','loss3'] if repetition==1 else ['loss3','clean']
   for profile in profiles:
    if repetition==1:probe(profile,profile)
    order=CANDIDATES if repetition==1 else list(reversed(CANDIDATES))
    for proto,pool in order:run(f'{profile}-r{repetition}-{proto}-p{pool}',proto,pool,profile)
  for profile in ['loss1','burst']:
   probe(profile,profile)
   for proto,pool in CANDIDATES[1:]+CANDIDATES[:1]:run(f'{profile}-r1-{proto}-p{pool}',proto,pool,profile)
  for repetition in [1,2]:run(f'loss3-r{repetition}-kcp-fec-p2','kcp-fec',2,'loss3')
  for proto,pool in [('wss-smux',2),('quic1200',1)]:run(f'both-loss3-r1-{proto}-p{pool}',proto,pool,'loss3','both')
  for proto,pool in [('wss-smux',2),('quic1200',1),('quic1200',2),('kcp',2)]:run(f'restart-loss3-{proto}-p{pool}',proto,pool,'loss3',loads=False,hook=True)
  completed=True
 finally:
  setprofile('clean')
  if completed:(OUT/'matrix-finished.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
