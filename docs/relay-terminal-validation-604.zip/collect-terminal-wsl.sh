#!/bin/bash
set -euo pipefail
cd /tmp/webmux-relay-604
kill "$(cat monitor-host.pid)" 2>/dev/null || true
gzip -c metrics-host-terminal.jsonl > /mnt/d/604/relay-validation/terminal-results/terminal-metrics-host.jsonl.gz
{
 date -u
 uname -sr
 getconf CLK_TCK
 sysctl net.ipv4.tcp_congestion_control net.core.rmem_max net.core.wmem_max
 sha256sum bench-business bench-hy webmux hysteria
} > /mnt/d/604/relay-validation/terminal-results/terminal-environment-host.txt
