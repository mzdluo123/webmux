package main

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/coder/websocket"
	"io"
	"net"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"os/exec"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

var termIdle = flag.Int("terminal-idle", 20, "idle PTY phase seconds")
var termInterval = flag.Int("terminal-interval", 250, "scheduled input interval milliseconds")
var termRate = flag.Int("terminal-output-rate", 262144, "other PTY producer bytes/second")
var termLoads = flag.Bool("terminal-loads", true, "include other-terminal output and timed bulk phases")
var termHook = flag.String("terminal-hook", "", "optional operator-orchestrated restart hook")
var termSelfRate = flag.Int("terminal-self-output-rate", 0, "continuous output in the SAME PTY while accepting test input")
var termCountRE = regexp.MustCompile(`r604count:([0-9]{16})z`)

type termProbe struct {
	ID         uint32  `json:"id"`
	Phase      string  `json:"phase"`
	At         string  `json:"scheduled_at"`
	Ack        bool    `json:"acked"`
	MS         float64 `json:"ack_ms,omitempty"`
	WriteError bool    `json:"write_error,omitempty"`
	sent       time.Time
}
type termPTY struct {
	conn              *websocket.Conn
	mu                sync.Mutex
	probes            []termProbe
	prefix            string
	generation        string
	offset            uint64
	ackGaps           []float64
	lastAck           time.Time
	pending           int
	readerError       string
	readDone          chan struct{}
	closing           atomic.Bool
	outputBytes       atomic.Int64
	exitAt            atomic.Int64
	producerBytes     atomic.Int64
	producerCountSeen atomic.Bool
}

func (s *termPTY) startReader() {
	go func() {
		defer close(s.readDone)
		var scan []byte
		for {
			_, p, e := s.conn.Read(context.Background())
			if e != nil {
				if !s.closing.Load() {
					s.mu.Lock()
					s.readerError = e.Error()
					s.mu.Unlock()
				}
				return
			}
			if len(p) == 0 {
				continue
			}
			if p[0] == 3 {
				s.exitAt.Store(time.Now().UnixNano())
				continue
			}
			if p[0] != 0 && p[0] != 1 {
				continue
			}
			p = p[1:]
			s.outputBytes.Add(int64(len(p)))
			s.mu.Lock()
			s.offset += uint64(len(p))
			s.mu.Unlock()
			scan = append(scan, p...)
			if m := termCountRE.FindSubmatch(scan); m != nil {
				if n, err := strconv.ParseInt(string(m[1]), 10, 64); err == nil {
					s.producerBytes.Store(n)
					s.producerCountSeen.Store(true)
				}
			}
			for {
				i := bytes.Index(scan, []byte(s.prefix))
				if i < 0 {
					keep := len(s.prefix) - 1
					if keep < 64 {
						keep = 64
					}
					if len(scan) > keep {
						scan = append([]byte(nil), scan[len(scan)-keep:]...)
					}
					break
				}
				n := len(s.prefix) + 8 + 1
				if len(scan) < i+n {
					scan = append([]byte(nil), scan[i:]...)
					break
				}
				token := scan[i+len(s.prefix) : i+len(s.prefix)+8]
				id, e := strconv.ParseUint(string(token), 16, 32)
				if e == nil && scan[i+n-1] == 'z' {
					now := time.Now()
					s.mu.Lock()
					if int(id) < len(s.probes) && !s.probes[id].Ack {
						q := &s.probes[id]
						q.Ack = true
						q.MS = float64(now.Sub(q.sent).Microseconds()) / 1000
						if s.pending > 0 && !s.lastAck.IsZero() {
							s.ackGaps = append(s.ackGaps, float64(now.Sub(s.lastAck).Microseconds())/1000)
						}
						s.lastAck = now
						s.pending--
					}
					s.mu.Unlock()
				}
				scan = scan[i+n:]
			}
		}
	}()
}
func (s *termPTY) close() { s.closing.Store(true); s.conn.CloseNow(); <-s.readDone }
func quant(v []float64) map[string]float64 {
	m := map[string]float64{}
	if len(v) == 0 {
		return m
	}
	sort.Float64s(v)
	for _, q := range []int{50, 95, 99} {
		m[fmt.Sprintf("p%d", q)] = v[int(float64(len(v)-1)*float64(q)/100)]
	}
	return m
}
func termSummary(s *termPTY) map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := map[string]any{}
	phases := map[string]bool{}
	for _, q := range s.probes {
		phases[q.Phase] = true
	}
	for phase := range phases {
		var ack, capped []float64
		n, timeout, write, within1, within2, within5 := 0, 0, 0, 0, 0, 0
		for _, q := range s.probes {
			if q.Phase != phase {
				continue
			}
			n++
			v := 8000.0
			if q.Ack {
				ack = append(ack, q.MS)
				if q.MS < 8000 {
					v = q.MS
				}
				if q.MS <= 1000 {
					within1++
				}
				if q.MS <= 2000 {
					within2++
				}
				if q.MS <= 5000 {
					within5++
				}
			}
			if !q.Ack || q.MS > 8000 {
				timeout++
			}
			if q.WriteError {
				write++
			}
			capped = append(capped, v)
		}
		out[phase] = map[string]any{"sent": n, "acked": len(ack), "deadline_8s_failures": timeout, "write_errors": write, "within_1s": within1, "within_2s": within2, "within_5s": within5, "ack_latency_ms": quant(ack), "deadline_capped_latency_ms": quant(capped)}
	}
	return out
}

func terminal() {
	start := time.Now()
	result := map[string]any{"started_at": start.UTC().Format(time.RFC3339Nano), "proto": *proto, "pool": *pool, "input_interval_ms": *termInterval, "requested_output_bps": *termRate, "deadline_ms": 8000, "browser_rendering_measured": false}
	result["same_pty_output_bps"] = *termSelfRate
	var secret map[string]string
	b, e := os.ReadFile("secrets.json")
	if e == nil {
		e = json.Unmarshal(b, &secret)
	}
	if e != nil {
		result["setup_error"] = e.Error()
		json.NewEncoder(os.Stdout).Encode(result)
		return
	}
	origin := fmt.Sprintf("https://%s:%d", *addr, *portOverride)
	if *endpoint != "" {
		origin = *endpoint
	}
	cfg := credentials(false)
	cfg.NextProtos = []string{"http/1.1"}
	jar, _ := cookiejar.New(nil)
	hc := &http.Client{Jar: jar, Transport: &http.Transport{Proxy: nil, TLSClientConfig: cfg, MaxIdleConnsPerHost: 8, DialContext: (&net.Dialer{Timeout: 8 * time.Second, Control: tcpControl}).DialContext}, Timeout: 25 * time.Second}
	request := func(method, path string, body io.Reader, ctype string) (int, []byte, error) {
		r, e := http.NewRequest(method, origin+path, body)
		if e != nil {
			return 0, nil, e
		}
		r.Header.Set("Origin", origin)
		r.Header.Set("Authorization", "Bearer "+secret["webmux"])
		if ctype != "" {
			r.Header.Set("Content-Type", ctype)
		}
		resp, e := hc.Do(r)
		if e != nil {
			return 0, nil, e
		}
		defer resp.Body.Close()
		b, e := io.ReadAll(io.LimitReader(resp.Body, 1024*1024))
		return resp.StatusCode, b, e
	}
	var ids []string
	defer func() {
		for _, id := range ids {
			request("DELETE", "/api/sessions/"+id, nil, "")
		}
	}()
	create := func(cmd []string) (string, error) {
		b, _ := json.Marshal(map[string]any{"cmd": cmd, "cwd": "/tmp", "name": "relay604-terminal-focus", "cols": 80, "rows": 24})
		status, b, e := request("POST", "/api/sessions", bytes.NewReader(b), "application/json")
		if e != nil {
			return "", e
		}
		if status != 201 {
			return "", fmt.Errorf("create status %d", status)
		}
		var d struct {
			Session struct {
				ID string `json:"id"`
			} `json:"session"`
		}
		e = json.Unmarshal(b, &d)
		if e != nil || d.Session.ID == "" {
			return "", fmt.Errorf("invalid create response")
		}
		ids = append(ids, d.Session.ID)
		return d.Session.ID, nil
	}
	open := func(id, query string) (*websocket.Conn, string, uint64, error) {
		h := http.Header{}
		h.Set("Authorization", "Bearer "+secret["webmux"])
		h.Set("Origin", origin)
		ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()
		c, _, e := websocket.Dial(ctx, strings.Replace(origin, "https://", "wss://", 1)+"/ws/s/"+id+"?client=relay604terminal&label=terminal-focus"+query, &websocket.DialOptions{HTTPClient: hc, HTTPHeader: h})
		if e != nil {
			return nil, "", 0, e
		}
		c.SetReadLimit(8 * 1024 * 1024)
		var gen string
		var offset uint64
		var positionSeen bool
		var controlSeen bool
		for !positionSeen || !controlSeen {
			_, p, e := c.Read(ctx)
			if e != nil {
				c.CloseNow()
				return nil, "", 0, e
			}
			if len(p) == 0 {
				continue
			}
			if p[0] == 4 {
				var pos struct {
					Generation string `json:"generation"`
					Start      uint64 `json:"start"`
				}
				json.Unmarshal(p[1:], &pos)
				gen = pos.Generation
				offset = pos.Start
				positionSeen = true
				if query != "" {
					return c, gen, offset, nil
				}
			}
			if p[0] == 0 || p[0] == 1 {
				offset += uint64(len(p) - 1)
			}
			if p[0] == 2 {
				controlSeen = true
			}
		}
		return c, gen, offset, nil
	}
	cmd := []string{"/bin/sh", "-c", "stty -echo -icanon min 1 time 0; exec cat"}
	if *termSelfRate > 0 {
		chunk := *termSelfRate / 50
		if chunk < 64 {
			chunk = 64
		}
		if chunk > 4096 {
			chunk = 4096
		}
		script := fmt.Sprintf("import os,threading,time,tty\ntty.setraw(0)\nlock=threading.Lock()\ndef put(d):\n with lock:\n  i=0\n  while i<len(d):\n   i+=os.write(1,d[i:])\ndef pump():\n b=b'o'*%d\n while True:\n  put(b)\n  time.sleep(%d/%d)\nthreading.Thread(target=pump,daemon=True).start()\nwhile True:\n d=os.read(0,4096)\n if not d:break\n put(d)\n", chunk, chunk, *termSelfRate)
		cmd = []string{"python3", "-u", "-c", script}
	}
	id, e := create(cmd)
	if e != nil {
		result["setup_error"] = e.Error()
		json.NewEncoder(os.Stdout).Encode(result)
		return
	}
	c, gen, offset, e := open(id, "")
	if e != nil {
		result["setup_error"] = e.Error()
		json.NewEncoder(os.Stdout).Encode(result)
		return
	}
	nonce := make([]byte, 4)
	rand.Read(nonce)
	prefix := "r604t" + hex.EncodeToString(nonce) + "-"
	s := &termPTY{conn: c, prefix: prefix, generation: gen, offset: offset, readDone: make(chan struct{}), lastAck: time.Now()}
	s.startReader()
	var phase atomic.Value
	phase.Store("idle")
	queue := make(chan uint32, 128)
	scheduleDone := make(chan struct{})
	stopSchedule := make(chan struct{})
	writeDone := make(chan struct{})
	go func() {
		defer close(writeDone)
		dead := false
		for n := range queue {
			if dead {
				s.mu.Lock()
				s.probes[n].WriteError = true
				s.mu.Unlock()
				continue
			}
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			e := c.Write(ctx, websocket.MessageBinary, append([]byte{0}, []byte(fmt.Sprintf("%s%08xz", prefix, n))...))
			cancel()
			if e != nil {
				s.mu.Lock()
				s.probes[n].WriteError = true
				s.mu.Unlock()
				dead = true
			}
		}
	}()
	go func() {
		defer close(scheduleDone)
		defer close(queue)
		tick := time.NewTicker(time.Duration(*termInterval) * time.Millisecond)
		defer tick.Stop()
		for {
			select {
			case <-stopSchedule:
				return
			case t := <-tick.C:
				s.mu.Lock()
				n := uint32(len(s.probes))
				s.probes = append(s.probes, termProbe{ID: n, Phase: phase.Load().(string), At: t.UTC().Format(time.RFC3339Nano), sent: t})
				if s.pending == 0 {
					s.lastAck = t
				}
				s.pending++
				s.mu.Unlock()
				select {
				case queue <- n:
				default:
					s.mu.Lock()
					s.probes[n].WriteError = true
					s.mu.Unlock()
				}
			}
		}
	}()
	phaseTimes := []map[string]any{}
	waitPhase := func(name string, d time.Duration) {
		phase.Store(name)
		t := time.Now()
		time.Sleep(d)
		phaseTimes = append(phaseTimes, map[string]any{"phase": name, "start": t.UTC().Format(time.RFC3339Nano), "seconds": time.Since(t).Seconds()})
	}
	waitPhase("idle", time.Duration(*termIdle)*time.Second)
	s.mu.Lock()
	if len(s.probes) > 0 && s.probes[0].Ack {
		result["first_operable_ms"] = float64(s.probes[0].sent.Sub(start).Microseconds())/1000 + s.probes[0].MS
	}
	s.mu.Unlock()
	loads := map[string]any{}
	if *termLoads {
		phase.Store("setup-output")
		script := fmt.Sprintf("import os,time,tty\ntty.setcbreak(0)\nos.read(0,1)\nb=b'o'*4096\nn=0\ntry:\n while True:\n  n+=os.write(1,b)\n  time.sleep(4096/%d)\nexcept KeyboardInterrupt:\n pass\nfinally:\n os.write(1,('r604count:%%016dz'%%n).encode())\n", *termRate)
		fid, err := create([]string{"python3", "-u", "-c", script})
		if err != nil {
			loads["output_error"] = err.Error()
		} else {
			fc, fg, fo, err := open(fid, "")
			if err != nil {
				loads["output_error"] = err.Error()
			} else {
				f := &termPTY{conn: fc, prefix: "never-a-marker", generation: fg, offset: fo, readDone: make(chan struct{})}
				f.startReader()
				ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
				err = fc.Write(ctx, websocket.MessageBinary, []byte{0, 'g'})
				cancel()
				readyBy := time.Now().Add(12 * time.Second)
				for err == nil && f.outputBytes.Load() == 0 && time.Now().Before(readyBy) {
					time.Sleep(20 * time.Millisecond)
				}
				loads["output_first_byte_received"] = f.outputBytes.Load() > 0
				if f.outputBytes.Load() > 0 {
					waitPhase("other-terminal-output", time.Duration(*seconds)*time.Second)
				}
				phase.Store("interrupt-output")
				interruptStart := time.Now()
				ctx, cancel = context.WithTimeout(context.Background(), 8*time.Second)
				err = fc.Write(ctx, websocket.MessageBinary, []byte{0, 3})
				cancel()
				loads["interrupt_write_ok"] = err == nil
				until := time.Now().Add(12 * time.Second)
				for f.exitAt.Load() == 0 && time.Now().Before(until) {
					time.Sleep(20 * time.Millisecond)
				}
				loads["interrupt_exit_observed"] = f.exitAt.Load() > 0
				if f.exitAt.Load() > 0 {
					loads["interrupt_ms"] = float64(f.exitAt.Load()-interruptStart.UnixNano()) / 1e6
				}
				phase.Store("teardown-output")
				f.close()
				loads["output_bytes_received"] = f.outputBytes.Load()
				loads["output_producer_count_received"] = f.producerCountSeen.Load()
				loads["output_producer_bytes"] = f.producerBytes.Load()
				loads["output_complete"] = f.producerCountSeen.Load() && f.outputBytes.Load() == f.producerBytes.Load()+27
				loads["output_reader_error"] = f.readerError
			}
			status, _, err := request("DELETE", "/api/sessions/"+fid, nil, "")
			loads["output_cleanup_status"] = status
			if err != nil {
				loads["output_cleanup_error"] = err.Error()
			}
		}
		waitPhase("after-output", 3*time.Second)
		phase.Store("setup-bulk")
		request("DELETE", "/api/forwards/17683", nil, "")
		status, _, err := request("POST", "/api/forwards", strings.NewReader(`{"port":17683,"label":"relay604-terminal-load","options":{"prefix":"strip","rewriteHost":false,"rewriteOrigin":false,"forwardedHeaders":false,"rewriteResponse":false}}`), "application/json")
		loads["bulk_registration_status"] = status
		if err == nil && status == 201 {
			status, b, err := request("POST", "/api/forwards/tickets", strings.NewReader("{}"), "application/json")
			var ticket struct {
				Code string `json:"code"`
			}
			json.Unmarshal(b, &ticket)
			if err == nil && status == 201 {
				form := url.Values{"code": {ticket.Code}, "next": {"/forward/17683/"}}.Encode()
				req, _ := http.NewRequest("POST", origin+"/forward/_auth", strings.NewReader(form))
				req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
				req.Header.Set("Origin", origin)
				redeemer := *hc
				redeemer.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
				resp, err := redeemer.Do(req)
				if err == nil {
					io.Copy(io.Discard, resp.Body)
					resp.Body.Close()
				}
				if err == nil && resp.StatusCode == 303 {
					ctx, cancel := context.WithCancel(context.Background())
					ready := make(chan bool, 1)
					done := make(chan struct{})
					var count atomic.Int64
					var good atomic.Bool
					good.Store(true)
					var bulkErr string
					go func() {
						defer close(done)
						req, _ := http.NewRequestWithContext(ctx, "GET", origin+"/forward/17683/bulk/download?bytes=1073741824", nil)
						req.Header.Set("Origin", origin)
						client := *hc
						client.Timeout = 0
						resp, err := client.Do(req)
						if err != nil {
							bulkErr = err.Error()
							ready <- false
							return
						}
						defer resp.Body.Close()
						if resp.StatusCode != 200 {
							bulkErr = fmt.Sprintf("bulk status %d", resp.StatusCode)
							ready <- false
							return
						}
						buf := make([]byte, 32768)
						expected := make([]byte, len(buf))
						source := payload()
						notified := false
						for {
							n, e := resp.Body.Read(buf)
							if n > 0 {
								_, ee := io.ReadFull(source, expected[:n])
								if ee != nil || !bytes.Equal(buf[:n], expected[:n]) {
									good.Store(false)
								}
								count.Add(int64(n))
								if !notified {
									ready <- true
									notified = true
								}
							}
							if e != nil {
								if !notified {
									ready <- false
								}
								if ctx.Err() == nil {
									bulkErr = e.Error()
								}
								return
							}
						}
					}()
					select {
					case ok := <-ready:
						loads["bulk_first_byte_received"] = ok
						if ok {
							waitPhase("bulk-download", time.Duration(*seconds)*time.Second)
						}
					case <-time.After(25 * time.Second):
						loads["bulk_first_byte_received"] = false
					}
					phase.Store("teardown-bulk")
					cancel()
					<-done
					loads["bulk_delivered_prefix_bytes"] = count.Load()
					loads["bulk_prefix_verified"] = good.Load()
					loads["bulk_intentionally_cancelled"] = true
					if bulkErr != "" {
						loads["bulk_error"] = bulkErr
					}
				} else {
					loads["bulk_auth_error"] = "ticket redemption failed"
				}
			} else {
				loads["bulk_auth_error"] = "ticket issuance failed"
			}
			request("DELETE", "/api/forwards/17683", nil, "")
		}
		waitPhase("after-bulk", 3*time.Second)
	}
	close(stopSchedule)
	<-scheduleDone
	time.Sleep(8 * time.Second)
	s.close()
	<-writeDone
	result["phase_times"] = phaseTimes
	result["loads"] = loads
	result["summary"] = termSummary(s)
	s.mu.Lock()
	result["samples"] = s.probes
	result["reader_error"] = s.readerError
	result["received_echo_bytes"] = s.offset - offset
	resumeOffset := s.offset
	gaps := append([]float64(nil), s.ackGaps...)
	if s.pending > 0 {
		gaps = append(gaps, float64(time.Since(s.lastAck).Microseconds())/1000)
	}
	s.mu.Unlock()
	result["ack_gap_ms"] = quant(gaps)
	if len(gaps) > 0 {
		sort.Float64s(gaps)
		result["max_ack_gap_ms"] = gaps[len(gaps)-1]
	}
	marker := []byte(fmt.Sprintf("offline-r604-%016x", time.Now().UnixNano()))
	body, _ := json.Marshal(map[string]any{"clientRequestId": fmt.Sprintf("terminal-r604-%016x", time.Now().UnixNano()), "text": string(marker)})
	restartStart := time.Now()
	recovery := map[string]any{}
	if *termHook != "" {
		b, err := exec.Command("python", *termHook, id, string(marker), *proto, strconv.Itoa(*pool)).Output()
		if err != nil {
			recovery["hook_error"] = err.Error()
		} else {
			var d map[string]any
			json.Unmarshal(b, &d)
			recovery["orchestration"] = d
		}
	} else {
		status, _, err := request("POST", "/api/sessions/"+id+"/input", bytes.NewReader(body), "application/json")
		recovery["offline_input_acknowledged"] = err == nil && status == 200
		time.Sleep(time.Second)
	}
	resumed, resumedGen, resumedOffset, err := open(id, fmt.Sprintf("&generation=%s&offset=%d", url.QueryEscape(gen), resumeOffset))
	recovery["opened"] = err == nil
	recovery["offset_matches"] = err == nil && resumedOffset == resumeOffset
	recovery["generation_matches"] = err == nil && resumedGen == gen
	if err != nil {
		recovery["error"] = err.Error()
	} else {
		ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
		var tail []byte
		for !bytes.Contains(tail, marker) {
			_, p, e := resumed.Read(ctx)
			if e != nil {
				recovery["read_error"] = e.Error()
				break
			}
			if len(p) > 0 && (p[0] == 0 || p[0] == 1) {
				tail = append(tail, p[1:]...)
			}
		}
		recovery["offline_marker_once"] = bytes.Count(tail, marker) == 1
		recovery["recovery_ms"] = float64(time.Since(restartStart).Microseconds()) / 1000
		readyMarker := []byte(fmt.Sprintf("ready-r604-%016x", time.Now().UnixNano()))
		readyStart := time.Now()
		err = resumed.Write(ctx, websocket.MessageBinary, append([]byte{0}, readyMarker...))
		var fresh []byte
		for err == nil && !bytes.Contains(fresh, readyMarker) {
			_, p, e := resumed.Read(ctx)
			if e != nil {
				err = e
				break
			}
			if len(p) > 0 && (p[0] == 0 || p[0] == 1) {
				fresh = append(fresh, p[1:]...)
			}
		}
		recovery["post_resume_echo_ok"] = err == nil && bytes.Contains(fresh, readyMarker)
		recovery["post_resume_echo_ms"] = float64(time.Since(readyStart).Microseconds()) / 1000
		recovery["total_to_operable_ms"] = float64(time.Since(restartStart).Microseconds()) / 1000
		cancel()
		resumed.CloseNow()
	}
	result["recovery"] = recovery
	result["wall_seconds"] = time.Since(start).Seconds()
	json.NewEncoder(os.Stdout).Encode(result)
}
