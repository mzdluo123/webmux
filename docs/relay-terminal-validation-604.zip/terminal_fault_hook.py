from suite_helpers import *
import sys,urllib.request,uuid,socket
sid,marker,proto,pool=sys.argv[1:5];t=time.monotonic()
remote('cd /root/relay-validation\nkill "$(cat ns-server.pid)"','terminal-fault-stop')
secret=json.loads((ROOT/'secrets.json').read_text())['webmux'];data=json.dumps({'clientRequestId':uuid.uuid4().hex,'text':marker}).encode()
req=urllib.request.Request('http://127.0.0.1:17681/api/sessions/'+sid+'/input',data=data,headers={'Authorization':'Bearer '+secret,'Origin':'http://127.0.0.1:17681','Content-Type':'application/json'})
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open(req,timeout=10) as resp:ack=resp.status==200;resp.read()
time.sleep(3)
remote('''cd /root/relay-validation
nohup ip netns exec relay604 ./relay-server-linux -mode server -kcp-no-cc 1 -kcp-window 1024 > server-terminal.log 2>&1 < /dev/null &
echo $! > ns-server.pid
sleep 0.5
'''.replace('./relay-server-linux','./'+os.environ.get('R604_SERVER_BINARY','relay-server-linux')),'terminal-fault-start')
subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','/mnt/d/604/relay-validation/terminal-launch-host.sh',proto,pool],env=ENV,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
print(json.dumps({'manual_orchestrated':True,'scheduled_down_s':3,'offline_input_acknowledged':ack,'host_ready_s':time.monotonic()-t}))
