from pathlib import Path
import json,collections,math,csv
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'terminal-results'
def percentile(values,q):
 values=sorted(values);return round(values[int((len(values)-1)*q)],3) if values else None
def analyze():
 groups=collections.defaultdict(list);runs=[]
 for p in sorted(OUT.glob('*.meta.json')):
  if p.name.startswith(('A-','light-smoke','smoke-')):continue
  data=p.with_name(p.name.replace('.meta.json','.json'))
  m=json.loads(p.read_text(encoding='utf-8-sig'))
  try:d=json.loads(data.read_text(encoding='utf-8-sig'))
  except (ValueError,FileNotFoundError):d={'proto':m.get('proto'),'pool':m.get('pool'),'setup_error':'invalid_or_missing_result_json'}
  if m.get('exit_code')!=0 and 'setup_error' not in d:d['setup_error']='client_exit_'+str(m.get('exit_code'))
  light=d.get('same_pty_output_bps',0)
  if not light and p.name.startswith('light'):light=int(p.name.split('-')[0].replace('light',''))
  if not light and p.name.startswith('paired8192'):light=8192
  kind='same-pty-'+str(light) if light else 'mixed-load'
  if 'restart-' in p.name:kind='manual-restart'
  if p.name.startswith('paired'):kind='paired-'+kind
  if data.stem=='light8192-burst-r1-wss-smux-p2':kind='environment-interrupted'
  stage='night' if m['start']<1794708000 else 'morning'
  key=(stage,m['profile'],m['scope'],d.get('proto',m.get('proto')),d.get('pool',m.get('pool')),kind)
  groups[key].append((p.stem.replace('.meta',''),d,m))
  runs.append({'case':data.stem,'stage':stage,'profile':m['profile'],'scope':m['scope'],'proto':d.get('proto'),'pool':d.get('pool'),'same_pty_output_bps':light,'comparison_eligible':kind!='environment-interrupted','setup_error':d.get('setup_error'),'first_operable_ms':d.get('first_operable_ms'),'host_ready_s':m.get('host_ready_s'),'max_ack_gap_ms':d.get('max_ack_gap_ms'),'output_complete':d.get('loads',{}).get('output_complete'),'interrupt_ms':d.get('loads',{}).get('interrupt_ms'),'recovery':d.get('recovery'),'summary':d.get('summary')})
 rows=[]
 for (stage,profile,scope,proto,pool,kind),cases in sorted(groups.items(),key=lambda x: (0 if x[0][0]=='night' else 1,x[0][1:])):
  phases=sorted({q['phase'] for _,d,_ in cases for q in d.get('samples',[])})
  for phase in phases:
   samples=[q for _,d,_ in cases for q in d.get('samples',[]) if q['phase']==phase];n=len(samples)
   ack=[q['ack_ms'] for q in samples if q.get('acked')];capped=[min(q.get('ack_ms',8000),8000) if q.get('acked') else 8000 for q in samples]
   cold=[d['first_operable_ms']+1000*(m.get('host_ready_s') or 0) for _,d,m in cases if 'first_operable_ms' in d and (m.get('host_ready_s') or 0)<270]
   row={'stage':stage,'profile':profile,'scope':scope,'proto':proto,'pool':pool,'workload':kind,'phase':phase,'attempts':len(cases),'setup_failures':sum('setup_error' in d for _,d,_ in cases),'sent':n,'acked':len(ack),'deadline_8s_failures':sum(not q.get('acked') or q.get('ack_ms',9000)>8000 for q in samples),'within_1s_pct':round(sum(q.get('acked') and q.get('ack_ms',9000)<=1000 for q in samples)*100/n,2),'within_2s_pct':round(sum(q.get('acked') and q.get('ack_ms',9000)<=2000 for q in samples)*100/n,2),'ack_p50_ms':percentile(ack,.5),'ack_p95_ms':percentile(ack,.95),'ack_p99_ms':percentile(ack,.99),'capped_p50_ms':percentile(capped,.5),'capped_p95_ms':percentile(capped,.95),'capped_p99_ms':percentile(capped,.99),'max_ack_gap_ms':max((d.get('max_ack_gap_ms',0) for _,d,_ in cases),default=0),'cold_operable_mean_ms':sum(cold)/len(cold) if cold else None,'output_complete_cases':sum(d.get('loads',{}).get('output_complete') is True for _,d,_ in cases)}
   rows.append(row)
 (OUT/'summary.json').write_text(json.dumps({'rows':rows,'runs':runs,'setup_failures':[r for r in runs if r['setup_error']]},ensure_ascii=False,indent=2),encoding='utf-8')
 if rows:
  with (OUT/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 return rows
if __name__=='__main__':
 for r in analyze():
  if r['phase'] in ['idle','other-terminal-output','bulk-download']:print(r['profile'],r['proto'],r['pool'],r['workload'],r['phase'],r['sent'],r['within_2s_pct'],r['capped_p95_ms'],r['deadline_8s_failures'])
