from suite_helpers import *
import base64,re
OUT=ROOT/'terminal-results'
while not (OUT/'terminal-all-finished.txt').exists():time.sleep(2)
remote('''cd /root/relay-validation
{
date -u
uname -sr
getconf CLK_TCK
sysctl net.ipv4.tcp_congestion_control net.core.default_qdisc net.core.rmem_max net.core.wmem_max
tc qdisc show dev eth0
ip netns exec relay604 sysctl net.ipv4.tcp_congestion_control
sha256sum relay-server-linux relay-terminal-hy-linux webmux-linux hysteria-linux
} > terminal-environment.txt
kill "$(cat monitor.pid)"
gzip -c metrics.jsonl > terminal-metrics-root.jsonl.gz
''','terminal-collect')
for name in ['terminal-metrics-root.jsonl.gz','terminal-environment.txt','terminal-offloads-before.txt','terminal-offloads-during.txt','terminal-udp-buffers.txt']:
 data=base64.b64decode(remote('cd /root/relay-validation\nbase64 -w76 '+name,'terminal-download'))
 (OUT/name).write_bytes(data);print(name,len(data),flush=True)
subprocess.run(['wsl.exe','-d','Debian','-u','root','--','bash','/mnt/d/604/relay-validation/collect-terminal-wsl.sh'],env=ENV,check=True)
(OUT/'collection-complete.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
