#!/bin/bash
set -euo pipefail
cd /tmp/webmux-relay-604
if test -s host.pid;then pid=$(cat host.pid);if test "$(readlink /proc/$pid/cwd)" = /tmp/webmux-relay-604;then kill "$pid" 2>/dev/null || true;fi;fi
unset HTTP_PROXY HTTPS_PROXY ALL_PROXY PI_PROXY http_proxy https_proxy all_proxy
export NO_PROXY='*' no_proxy='*'
if test -s hysteria.pid;then pid=$(cat hysteria.pid);if test "$(readlink /proc/$pid/cwd)" = /tmp/webmux-relay-604;then kill "$pid" 2>/dev/null || true;fi;fi
if test "$1" = hy-smux;then
 nohup ./hysteria client -c hysteria-terminal.yaml > hysteria-terminal.log 2>&1 < /dev/null &
 echo $! > hysteria.pid
 for i in $(seq 1 100);do
  if grep -q 'connected to server' hysteria-terminal.log;then break;fi
  if ! kill -0 "$(cat hysteria.pid)" 2>/dev/null;then cat hysteria-terminal.log;exit 1;fi
  sleep 0.2
 done
fi
: > host.log
nohup ./bench-hy -mode host -proto "$1" -pool "$2" -kcp-no-cc 1 -kcp-window 1024 > host.log 2>&1 < /dev/null &
echo $! > host.pid
for i in $(seq 1 100); do
 if grep -q 'authenticated reverse host ready' host.log;then exit 0;fi
 if ! kill -0 "$(cat host.pid)" 2>/dev/null;then cat host.log;exit 1;fi
 sleep 0.2
done
cat host.log
exit 1
