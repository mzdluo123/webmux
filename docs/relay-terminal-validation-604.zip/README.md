# issue #604 终端优先补测证据

这是一套独立研究夹具，不是 WebMux 生产 Relay。配套报告是 docs/relay-terminal-validation-604.md；首轮报告/证据单独保留。
`terminal-results` 保留每轮原始输入延迟/正确性统计、失败、smoke 校准、命令元数据、参数和无正文资源采样。
smoke 与 A-only 校准不进入候选排名；primary 与 paired 两阶段分列，mixed-load、32KiB/s、burst、手工重启分别统计。

## 环境和凭据

Windows 管理机使用 Windows OpenSSH；Debian WSL 只运行本机宿主/夹具。服务器为专用 Debian Linux。
工具链与每个二进制 SHA-256 见 build-info.json；依赖由 go.mod/go.sum 固定。真实 WebMux 后端是 488ba406，Go 1.27.4，CGO=0。
复现实验程序需 Go 1.26.3、Python3+psutil、Debian WSL、iproute2/nftables/ethtool、内核 BBR、Hysteria v2.13.0 的 Linux amd64 发布包。
源码不包含编译器/依赖和程序发布二进制。按 tag/构建信息准备，所有下载和构建在性能采样之前完成。
默认目录：Windows D:\604\relay-validation，WSL /tmp/webmux-relay-604，服务器 /root/relay-validation。
修改服务器 IP/接口和目录时，需同步 Go 默认地址、Python、shell 与 Origin 白名单。测量子进程删除名称含 proxy 的环境变量。

1. `python prepare.py` 生成新的随机 secrets.json 与私密 TOML/YAML，不能复制他人凭据。
2. `go run . -mode cert` 生成新的测试 CA/leaf 证书和私钥（校验名 relay-bench）；权限私钥0600，不启用 skipVerify。
3. Windows `CGO_ENABLED=0 go build -o relay-terminal-hy.exe .`；交叉构建 GOOS=linux，输出 relay-terminal-hy-linux 与 bench-hy。
4. 构建真实 WebMux 后端及 cmd/httpfixture。测试 WebMux TOML 用127.0.0.1:17681、独立state_dir、测试Token和明确Origin。
5. 将程序、证书、配置复制到服务器和本机 WSL 指定目录；Windows ssh/scp 显式禁用 ProxyCommand/ProxyJump。
6. Linux socket 指定 BBR，服务端 namespace 默认 BBR；不修改 WSL 全局默认，不接入用户现有服务。
7. 服务器把新程序另复制为 relay-server-linux，真实 WebMux 命名 webmux-linux；`reproduce-server.sh` 建立 namespace/veth/DNAT 并启动 Go 服务、WebMux 和 root 监控。
8. 服务器在 `/root/relay-validation` 启动 `nohup ip netns exec relay604 ./hysteria-linux server -c hysteria-server.yaml > hysteria-terminal.log 2>&1 &`，将 PID 保存为 ns-hysteria.pid。
9. WSL 新程序命名 bench-hy，WebMux 命名 webmux，Hysteria 命名 hysteria；复制 cert.pem/key.pem、webmux-local.toml 和 hysteria-bbr.yaml，后者改名 hysteria-terminal.yaml。
10. WSL 在自己的目录运行 `./webmux -config webmux-local.toml`、`./httpfixture`，分别保存 webmux.pid/httpfixture.pid；将 monitor_host.py 启动为 python3 -u，输出 metrics-host-terminal.jsonl 并保存 monitor-host.pid。监听端口应为自己的 17681/17683，若占用先换实验端口，不能连接用户服务。

## offload 与损伤

先保存 `ethtool -k eth0` 原值，再对 eth0 和实验 veth 关闭 GRO/GSO/TSO；所有本批候选保持一致。
物理队列保留 mq/fq_codel。UDP max 缓冲记录在 terminal-udp-buffers.txt，没有单候选调大。
`terminal-profile.sh clean|loss3|burst b` 仅对 B 端口注入损伤；人工loss配置叠加真实公网。
Hysteria UDP19003也必须进入过滤器；A18452不注入，管理SSH不注入。
自然路径和采样时间不会精确复现；clean不等于零丢包，不能合并首轮不同offload/网络时段的数据。

## 启动终端矩阵

Windows `python ssh_worker.py` 建立持久管理连接。`suite_helpers.remote` 经私密 ssh-jobs 队列下发脚本；队列不发布。
`terminal-launch-host.sh` 仅按本实验PID及cwd终止旧宿主，Hysteria每轮新建客户端连接；ready后才运行输入采样。
`run_terminal_priority.py` 第一部分为四候选两轮同PTY8KiB/s；后续边界需与下一脚本串行，实际第一阶段在16轮后暂停。
`run_terminal_supplement.py` 使用新二进制做Hysteria/WSS/原生QUIC两轮配对，然后重输出、32KiB/s、burst、FEC边界。
`run_terminal_restarts.py` 等前一批完成再执行手动Relay/连接器重启。所有性能case顺序执行，不能与构建/其他测试并行。
可用 `run_terminal_matrix.run` 选单case，正式结果存在meta时跳过，不覆盖已有原始数据；使用新label重测。

每250ms独立安排按键；同PTY脚本输出8KiB/s或32KiB/s，真实PTY回显随机标记，8秒未确认计失败。
重负载256KiB/s另终端检查计数帧/退出/全部输出，Ctrl-C等待12秒；下载只校验20秒已读前缀，故意取消。
每轮关闭/续接generation+offset、离线写一次标记并确认一次，随后新输入确认可操作。
`terminal_fault_hook.py` 是手动编排恢复，不是生产自动重连；包含3秒等待及Windows SSH管理开销。
不运行真实Vim、CLI agent或浏览器渲染，也不调用付费模型API；这是网络部分的业务夹具。

## 汇总、资源和清理

`python analyze_terminal.py` 生成summary.csv/json；所有输入进分母，8秒封顶CDF；setup_failures独立保留。
`collect_terminal.py` 在所有case完成后封存两端资源；`analyze_terminal_resources.py` 按case客户端时间窗口计算PID累计CPU差和采样RSS峰。
resource CPU不含宿主初始化开销，不能当成每连接全部成本；无完整覆盖的窗口不得冒充资源结论。
`build_terminal_bundle.py` 用允许清单打包并校验无私钥/凭据/客户端地址，MANIFEST记录每文件大小和SHA-256。
night/morning 两批分开（原始metadata时间戳对应新加坡时间10:00分界1794708000；实际恢复10:36），首个burst/WSS准备阶段跨越环境中断，完整原始记录保留而排除排名；重测另用label。
旧relay-terminal.exe与relay-terminal-light.exe的固定哈希也保留；本包源码为最终复现夹具（新增self-output flag与hy-smux适配），并非保证旧二进制逐字节重建。

测试后按已保存值恢复eth0 GRO/GSO/TSO；只关闭本实验cwd/PID的程序，删除relay604 namespace/nft表/veth，关闭本轮开启的ip_forward。
保留服务器持久BBR；不触及用户SSH密钥或其他服务。生成的私钥/Token/配置不放入版本库/报告/证据。
原始输入输出正文不记录，源代码中的固定生成脚本不是真实用户终端内容。
