import os
os.environ['R604_SERVER_BINARY']='relay-terminal-hy-linux'
from run_terminal_matrix import *
while not (OUT/'terminal-supplement-finished.txt').exists():time.sleep(2)
try:
 probe('morning-clean','clean')
 probe('morning-loss3','loss3')
 run('morning8192-burst-repeat-wss-smux-p2','wss-smux',2,'burst',loads=False,client='relay-terminal-hy.exe',self_rate=8192,idle=30)
 run('morning-heavy-loss3-quic1200-p1','quic1200',1,'loss3',client='relay-terminal-hy.exe')
 for proto,pool in [('wss-smux',2),('quic1200',1)]:
  run(f'morning32768-loss3-{proto}-p{pool}',proto,pool,'loss3',loads=False,client='relay-terminal-hy.exe',self_rate=32768,idle=30)
 run('hy-heavy-loss3-r2','hy-smux',2,'loss3',client='relay-terminal-hy.exe')
 run('light32768-loss3-r1-hy-smux-p2','hy-smux',2,'loss3',loads=False,client='relay-terminal-hy.exe',self_rate=32768,idle=30)
 for proto,pool in [('wss-smux',2),('quic1200',1),('quic1200',2),('kcp',2),('hy-smux',2)]:
  run(f'light8192-restart-loss3-{proto}-p{pool}',proto,pool,'loss3',loads=False,hook=True,client='relay-terminal-hy.exe',self_rate=8192,idle=10)
finally:setprofile('clean')
(OUT/'terminal-all-finished.txt').write_text(time.strftime('%Y-%m-%dT%H:%M:%S%z'))
