from pathlib import Path
import json,statistics
R=Path(__file__).resolve().parent;O=R/'terminal-results'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def fmt(x):return '—' if x is None else f'{x:.0f}'
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def name(r):return {'wss-smux':'WSS/smux','quic1200':'QUIC Reno','kcp':'KCP nc=1','kcp-fec':'KCP FEC10+3','hy-smux':'Hysteria BBR/smux'}.get(r['proto'],r['proto'])+f" p{r['pool']}"
def latency(rows):return table(['候选','批次','档位','输出 KiB/s','输入数','p50','p95','p99','≤2 s','>8 s/未确认'],[[name(r),r['stage'],r['profile'],'32' if '32768' in r['workload'] else '8',r['sent'],fmt(r['capped_p50_ms']),fmt(r['capped_p95_ms']),fmt(r['capped_p99_ms']),str(r['within_2s_pct'])+'%',r['deadline_8s_failures']] for r in rows])
def span(v):
 v=[x for x in v if isinstance(x,(int,float))]
 return f'{min(v):.0f}–{max(v):.0f}' if v else '—'
def main():
 s=load(O/'summary.json');rows=s['rows'];runs=s['runs'];formal=[r for r in runs if r['workload']!='calibration'] if runs and 'workload' in runs[0] else runs
 d={};t=(R/'TERMINAL.template.md').read_text(encoding='utf-8-sig')
 d['PRIMARY_TABLE']=latency([r for r in rows if r['workload']=='same-pty-8192' and r['profile'] in ['clean','loss3'] and r['phase']=='idle'])
 d['PAIRED_TABLE']=latency([r for r in rows if r['workload']=='paired-same-pty-8192' and r['phase']=='idle'])
 d['BOUNDARY_TABLE']=latency([r for r in rows if (r['workload']=='same-pty-32768' or (r['workload']=='same-pty-8192' and r['profile']=='burst')) and r['phase']=='idle'])
 heavy=[]
 for r in rows:
  if r['workload']!='mixed-load' or r['phase']!='other-terminal-output':continue
  matches=[q for q in rows if all(q[k]==r[k] for k in ['stage','profile','scope','proto','pool','workload']) and q['phase']=='bulk-download'];bulk=matches[0] if matches else {}
  cases=[q for q in runs if q['same_pty_output_bps']==0 and q['stage']==r['stage'] and q['profile']==r['profile'] and q['proto']==r['proto'] and q['pool']==r['pool'] and 'restart' not in q['case']]
  heavy.append([name(r),r['stage'],r['profile'],r['attempts'],fmt(r['capped_p95_ms']),fmt(bulk.get('capped_p95_ms')),f"{r['output_complete_cases']}/{r['attempts']}",span([q['interrupt_ms'] for q in cases])])
 d['HEAVY_TABLE']=table(['候选','批次','档位','轮数','另终端输出时 p95','下载时 p95','输出完成轮数','Ctrl-C ms范围'],heavy)
 def flag(rec,k):return rec.get(k,rec.get('orchestration',{}).get(k))
 flags=['opened','generation_matches','offset_matches','offline_input_acknowledged','offline_marker_once','post_resume_echo_ok']
 bad=[{'case':r['case'],'failed_flags':[k for k in flags if not flag(r.get('recovery') or {},k)]} for r in runs if any(not flag(r.get('recovery') or {},k) for k in flags)]
 d['RECOVERY']=f"正式尝试 {len(runs)} 轮（{sum(r.get("comparison_eligible",True) for r in runs)} 轮入性能对照，1 轮环境中断排除）；"+(f"全部 {len(runs)} 轮通过打开、generation/offset、离线标记一次和恢复后新输入回显检查。" if not bad else f"以下未全部通过：`{json.dumps(bad,ensure_ascii=False)}`。")+f"\n初始化失败 {len(s.get('setup_failures',[]))} 次，逐项见 summary.json。"
 restart=[r for r in runs if 'restart' in r['case']]
 d['RESTART_TABLE']=table(['候选','手动恢复至可操作 ms','续接后新输入 ms','完整检查'],[[name(r),fmt((r.get('recovery') or {}).get('total_to_operable_ms')),fmt((r.get('recovery') or {}).get('post_resume_echo_ms')),'通过' if all(flag(r.get('recovery') or {},k) for k in flags) else '失败'] for r in restart])
 resources=load(O/'resources.json')['cases'];rr=[]
 for proto in ['wss-smux','quic1200','hy-smux']:
  cases=[x for x in resources if x['case'].startswith('paired8192') and proto in x['case']]
  def peak(label):return max((x['resources'].get(label,{}).get('peak_rss_mib',0) for x in cases),default=0)
  rr.append([proto,f"{max((x['client_peak_rss_mib'] for x in cases),default=0):.1f}",f"{peak('relay'):.1f}",f"{peak('host'):.1f}",f"{peak('hy-server'):.1f}/{peak('hy-client'):.1f}" if proto=='hy-smux' else '—'])
 d['RESOURCES']=table(['配对候选','Windows MiB','Relay Go MiB','宿主 Go MiB','额外 Hy server/client MiB'],rr)+'\n\n'+table(['配对候选','连接器 ready ms范围','首次会话可操作 ms范围'],[[proto,span([r['host_ready_s']*1000 for r in runs if r['case'].startswith('paired8192') and r['proto']==proto and r['host_ready_s'] is not None]),span([r['first_operable_ms'] for r in runs if r['case'].startswith('paired8192') and r['proto']==proto])] for proto in ['wss-smux','quic1200','hy-smux']])
 b=load(R/'terminal-bundle-info.json');d['BUNDLE']=f"下载[终端补测源码与原始统计](relay-terminal-validation-604.zip)，{b['files']} 个文件、{b['bytes']} bytes。\n\nSHA-256：`{b['sha256']}`。"
 d.update(load(R/'terminal-editorial.json'))
 for key,value in d.items():t=t.replace('@@'+key+'@@',value)
 assert '@@' not in t
 for repo in ['webmux-validation','webmux-planning']:(R.parent/repo/'docs/relay-terminal-validation-604.md').write_text(t,encoding='utf-8')
 print('Report lines',len(t.splitlines()),'formal runs',len(runs),'recovery failures',len(bad))
if __name__=='__main__':main()
