from pathlib import Path
import json,gzip,collections
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'terminal-results'
def lines(name):
 p=OUT/name
 if not p.exists():return []
 with gzip.open(p,'rt') as f:return [json.loads(s) for s in f if s.strip()]
def analyze():
 root=lines('terminal-metrics-root.jsonl.gz');host=lines('terminal-metrics-host.jsonl.gz');rows=[]
 for p in sorted(OUT.glob('*.meta.json')):
  if p.name.startswith(('A-','smoke','light-smoke')):continue
  m=json.loads(p.read_text());a=m['start'];b=a+m.get('elapsed_s',0)
  record={'case':p.name.replace('.meta.json',''),'wall_s':b-a,'client_peak_rss_mib':m.get('client_peak_rss',0)/1048576,'client_cpu_s':m.get('client_cpu_seconds'),'resources':{}}
  for label,series,field,accept in [('relay',root,'name',lambda n:n.startswith('relay-')),('remote-webmux',root,'name',lambda n:n.startswith('webmux')),('hy-server',root,'name',lambda n:n.startswith('hysteria')),('host',host,'label',lambda n:n=='host'),('host-webmux',host,'label',lambda n:n=='webmux'),('hy-client',host,'label',lambda n:n=='hysteria')]:
   if label.startswith('hy-') and m.get('proto')!='hy-smux':continue
   chosen=[(x['time'],v) for x in series if a<=x['time']<=b for v in x['processes'] if accept(v[field])]
   if not chosen:continue
   cpu=0
   for pid in {v['pid'] for _,v in chosen}:
    points=[(t,v['cpu_ticks']) for t,v in chosen if v['pid']==pid];cpu+=(points[-1][1]-points[0][1])/100
   record['resources'][label]={'peak_rss_mib':max(v['rss'] for _,v in chosen)/1048576,'observed_cpu_s':round(cpu,3),'samples':len(chosen)}
  rows.append(record)
 (OUT/'resources.json').write_text(json.dumps({'cpu_ticks_per_second':100,'window':'client benchmark lifetime, excluding host initialization','cases':rows},indent=2))
 print('resource cases',len(rows),'root samples',len(root),'host samples',len(host))
if __name__=='__main__':analyze()
